package com.newcolor.qixinginfo.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.newcolor.qixinginfo.model.MsgContactVO;
import com.newcolor.qixinginfo.model.OtherGongQiuVO;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;
import com.nostra13.universalimageloader.core.listener.SimpleImageLoadingListener;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

/**
 * 供求详情中，其他供求的adapter
 *
 * Created by baolei.si on 2015/8/10.
 */
public class OtherGongQiuAdapter extends BaseAdapter{
    private Context mContext;
    //xml转View对象
    private LayoutInflater mInflater;
    //单行的布局
    private int mResource;
    //列表展现的数据
    private List mData;
    //view的id
    private int[] mTo;

    public OtherGongQiuAdapter(Context context, List data,
                               int resource, int[] to){
        this.mContext = context;
        this.mData = data;
        this.mResource = resource;
        this.mTo = to;
        //用于将xml转为View
        this.mInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public Object getItem(int position) {
        return mData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        OtherGongQiuViewHolder holder;
        if(convertView == null){
            //使用自定义的list_items作为Layout
            convertView = mInflater.inflate(mResource, parent, false);

            holder = new OtherGongQiuViewHolder();
            holder.title_TV=(TextView)convertView.findViewById(mTo[0]);
            holder.num_TV = (TextView) convertView.findViewById(mTo[1]);
            holder.price_TV = (TextView) convertView.findViewById(mTo[2]);
            convertView.setTag(holder);
        }else {
            holder = (OtherGongQiuViewHolder) convertView.getTag();
        }

        //获取该行的数据
        final OtherGongQiuVO vo = (OtherGongQiuVO)mData.get(position);
        holder.title_TV.setText(vo.getTitle());
        holder.num_TV.setText(vo.getNum()+"吨");
        holder.price_TV.setText(vo.getPrice()+"元");

        return convertView;
    }


    static class OtherGongQiuViewHolder {
        TextView title_TV;
        TextView num_TV;
        TextView price_TV;

    }
}
