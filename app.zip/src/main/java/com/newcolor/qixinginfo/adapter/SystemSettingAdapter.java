package com.newcolor.qixinginfo.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;

import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.model.SystemSettingVO;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;

/**
 * 系统设置界面的adapter
 *
 * Created by Administrator on 2015/10/10.
 */
public class SystemSettingAdapter extends BaseAdapter implements View.OnClickListener {
    private static final int TYPE_ITEM = 0;
    private static final int TYPE_SEPARATOR = 1;
    private static final int TYPE_MAX_COUNT = TYPE_SEPARATOR + 1;

    private Context mContext;
    //xml转View对象
    private LayoutInflater mInflater;
    //列表展现的数据
    private List mData;
    private Callback callback;

    private TreeSet mSeparatorsSet = new TreeSet();


    public SystemSettingAdapter(Context context, List data,Callback callback) {
        mData=new ArrayList();
        this.callback=callback;

        this.mContext = context;
        SystemSettingVO vo;
        for (int i = 0; i < data.size(); i++) {
            vo=(SystemSettingVO) data.get(i);
            if(vo.getName().equals("separator")){
                this.addSeparatorItem(vo);
            }else {
                this.addItem(vo);
            }

        }
        //用于将xml转为View
        this.mInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);


        notifyDataSetChanged();
    }

    private void addItem(final SystemSettingVO item) {
        mData.add(item);
    }

    private void addSeparatorItem(final SystemSettingVO item) {
        mData.add(item);
        // save separator position
        mSeparatorsSet.add(mData.size() - 1);
    }

    @Override
    public int getItemViewType(int position) {
        return mSeparatorsSet.contains(position) ? TYPE_SEPARATOR : TYPE_ITEM;
    }

    @Override
    public int getViewTypeCount() {
        return TYPE_MAX_COUNT;
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public Object getItem(int position) {
        return mData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        int type = getItemViewType(position);
        MeViewHolder holder;
        if(convertView == null){
            //使用自定义的list_items作为Layout
//            convertView = mInflater.inflate(mResource, parent, false);

            holder = new MeViewHolder();
            switch (type) {
                case TYPE_ITEM:
                    convertView = mInflater.inflate(R.layout.item_list_system_setting, null);
                    holder.name_TV = (TextView) convertView.findViewById(R.id.name_TV);
                    holder.desc_TV = (TextView) convertView.findViewById(R.id.desc_TV);
                    holder.ctrBtn = (Switch) convertView.findViewById(R.id.ctrlBtn);
                    break;
                case TYPE_SEPARATOR:
                    convertView = mInflater.inflate(R.layout.item_me_separator, null);
//                    holder.textView = (TextView)convertView.findViewById(R.id.textSeparator);
                    break;
            }

            convertView.setTag(holder);
        }else {
            holder = (MeViewHolder) convertView.getTag();
        }

        if(type==TYPE_ITEM) {
            //获取该行的数据
            final SystemSettingVO vo = (SystemSettingVO) mData.get(position);
            holder.name_TV.setText(vo.getName());
            holder.desc_TV.setText(vo.getDesc());
            if(vo.getPosition()==7){
                holder.ctrBtn.setVisibility(View.GONE);
            }else {
                holder.ctrBtn.setChecked(vo.getState() == 1 ? true : false);
                holder.ctrBtn.setOnClickListener(this);
                holder.ctrBtn.setTag(vo);
            }
        }
        return convertView;
    }

    @Override
    public void onClick(View v) {
        callback.click(v);
    }

    static class MeViewHolder {
        TextView name_TV;
        TextView desc_TV;
        Switch ctrBtn;

    }

    /**
     * 自定义接口，用于回调按钮点击事件到Activity
     * @author Ivan Xu
     * 2014-11-26
     */
    public interface Callback {
        public void click(View v);
    }

}
