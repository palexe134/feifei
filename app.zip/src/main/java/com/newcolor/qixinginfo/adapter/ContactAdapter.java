package com.newcolor.qixinginfo.adapter;

import android.content.Context;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.newcolor.qixinginfo.activity.ContactListActivity;
import com.newcolor.qixinginfo.model.AppVO;
import com.newcolor.qixinginfo.model.ContactVO;

import java.util.List;

/**
 * 联系人列表的adapter
 *
 * Created by Administrator on 2015/10/10.
 */
public class ContactAdapter extends BaseAdapter {
    private Context mContext;
    //xml转View对象
    private LayoutInflater mInflater;
    //单行的布局
    private int mResource;
    //列表展现的数据
    private List mData;
    //view的id
    private int[] mTo;
    private int type;


    public ContactAdapter(Context context, List data,
                          int resource, int[] to,int type) {

        this.mContext = context;
        this.mData = data;
        this.mResource = resource;
        this.mTo = to;
        this.type=type;
        //用于将xml转为View
        this.mInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public Object getItem(int position) {
        return mData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        SubscribeViewHolder holder;
        if(convertView == null){
            //使用自定义的list_items作为Layout
            convertView = mInflater.inflate(mResource, parent, false);

            holder = new SubscribeViewHolder();
            holder.name_TV=(TextView)convertView.findViewById(mTo[0]);
            holder.phone_TV = (TextView) convertView.findViewById(mTo[1]);
            holder.address_TV = (TextView) convertView.findViewById(mTo[2]);
            holder.editor_IV = (ImageView) convertView.findViewById(mTo[3]);
            convertView.setTag(holder);
        }else {
            holder = (SubscribeViewHolder) convertView.getTag();
        }

        //获取该行的数据
        final ContactVO vo = (ContactVO)mData.get(position);

        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);

        holder.name_TV.setText(vo.getName());
        holder.phone_TV.setText(vo.getPhone());
        if(vo.isDefault()==1) {
            holder.address_TV.setText( Html.fromHtml("<font color='#ff0000'>[默认]</font>"+vo.getSureAddress()));
        }else{
            holder.address_TV.setText(vo.getSureAddress());
        }
        if(type== ContactListActivity.RELEASE_OPEN){
            holder.editor_IV.setVisibility(View.GONE);
        }else{
            holder.editor_IV.setVisibility(View.VISIBLE);
        }

        return convertView;
    }

    static class SubscribeViewHolder {
        TextView phone_TV;
        TextView name_TV;
        TextView address_TV;
        ImageView editor_IV;
    }

}
