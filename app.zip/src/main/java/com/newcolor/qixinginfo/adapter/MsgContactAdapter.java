package com.newcolor.qixinginfo.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.global.Constant;
import com.newcolor.qixinginfo.model.MsgContactVO;
import com.newcolor.qixinginfo.util.Tools;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;
import com.nostra13.universalimageloader.core.listener.SimpleImageLoadingListener;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

/**
 * 谁看过我列表的adapter
 *
 * Created by baolei.si on 2015/8/10.
 */
public class MsgContactAdapter extends BaseAdapter implements View.OnClickListener {
    private Context mContext;
    //xml转View对象
    private LayoutInflater mInflater;
    //单行的布局
    private int mResource;
    //列表展现的数据
    private List mData;
    //view的id
    private int[] mTo;
    private Callback callback;
    private ImageLoadingListener animateFirstListener = new AnimateFirstDisplayListener();



    public MsgContactAdapter(Context context, List data,
                             int resource, int[] to,Callback callback){
        this.mContext = context;
        this.mData = data;
        this.mResource = resource;
        this.mTo = to;
        this.callback=callback;
        //用于将xml转为View
        this.mInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public Object getItem(int position) {
        return mData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        MsgViewHolder holder;
        if(convertView == null){
            //使用自定义的list_items作为Layout
            convertView = mInflater.inflate(mResource, parent, false);

            holder = new MsgViewHolder();
            holder.itemsIcon=(ImageView)convertView.findViewById(mTo[0]);
            holder.name_TV = (TextView) convertView.findViewById(mTo[1]);
            holder.phone_TV = (TextView) convertView.findViewById(mTo[2]);
            holder.phoneBtn = (ImageButton) convertView.findViewById(mTo[3]);
            convertView.setTag(holder);
        }else {
            holder = (MsgViewHolder) convertView.getTag();
        }

        //获取该行的数据
        final MsgContactVO vo = (MsgContactVO)mData.get(position);
        Tools.loadImg(mContext, vo.getHeadImg(), holder.itemsIcon, Constant.headOptions, animateFirstListener, R.mipmap.defaulthead);
        holder.name_TV.setText(vo.getName());
        holder.phone_TV.setText(vo.getPhone());
        holder.phoneBtn.setOnClickListener(this);
        holder.phoneBtn.setTag(vo);

        return convertView;
    }

    @Override
    public void onClick(View v) {
        callback.click(v);
    }

    private static class AnimateFirstDisplayListener extends SimpleImageLoadingListener {

        static final List<String> displayedImages = Collections.synchronizedList(new LinkedList<String>());

        @Override
        public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
            if (loadedImage != null) {
                ImageView imageView = (ImageView) view;
                imageView.setImageBitmap(loadedImage);
                boolean firstDisplay = !displayedImages.contains(imageUri);
                if (firstDisplay) {
//                    FadeInBitmapDisplayer.animate(imageView, 500);
                    displayedImages.add(imageUri);
                }
            }
        }
    }

    static class MsgViewHolder {
        ImageView itemsIcon;
        TextView name_TV;
        TextView phone_TV;
        ImageButton phoneBtn;

    }

    /**
     * 自定义接口，用于回调按钮点击事件到Activity
     * @author Ivan Xu
     * 2014-11-26
     */
    public interface Callback {
        public void click(View v);
    }
}
