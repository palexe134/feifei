package com.newcolor.qixinginfo.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.newcolor.qixinginfo.global.Constant;
import com.newcolor.qixinginfo.view.AddImageView;
import com.nostra13.universalimageloader.core.ImageLoader;

import java.util.List;

/**
 * 图片上传的adapter
 *
 * Created by Administrator on 2015/10/19.
 */
public class ImageAdapter extends BaseAdapter  implements View.OnClickListener {
    private Context mContext;
    //xml转View对象
    private LayoutInflater mInflater;
    //单行的布局
    private int mResource;
    //列表展现的数据
    private List mData;
    //view的id
    private int[] mTo;
    private Callback callback;


    public ImageAdapter(Context context, List data,int resource, int[] to,Callback callback) {

        this.mContext = context;
        this.mData = data;
        this.mResource = resource;
        this.mTo = to;
        this.callback=callback;
        //用于将xml转为View
        this.mInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public Object getItem(int position) {
        return mData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ImageHolder holder;
        if(convertView == null){
            //使用自定义的list_items作为Layout
            convertView = mInflater.inflate(mResource, parent, false);

            holder = new ImageHolder();
            holder.icon_IV=(ImageView)convertView.findViewById(mTo[0]);
            holder.delet_TV=(TextView)convertView.findViewById(mTo[1]);
            convertView.setTag(holder);
        }else {
            holder = (ImageHolder) convertView.getTag();
        }

        //获取该行的数据
        final String url = (String)mData.get(position);

        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        ImageLoader.getInstance().displayImage(url, holder.icon_IV, Constant.addImgOptions);
//        Tools.loadImg(mContext, url, holder.icon_IV, Constant.headOptions, null, R.mipmap.defaulthead);

        holder.icon_IV.setOnClickListener(this);
        holder.icon_IV.setTag(position);
        if(url.equals(AddImageView.defaultUrl)){
            holder.delet_TV.setVisibility(View.GONE);
        }else {
            holder.delet_TV.setVisibility(View.VISIBLE);
            holder.delet_TV.setOnClickListener(this);
            holder.delet_TV.setTag(position);
        }
        return convertView;
    }

    @Override
    public void onClick(View v) {
        callback.click(v);
    }

    static class ImageHolder {
        ImageView icon_IV;
        TextView delet_TV;

    }

    /**
     * 自定义接口，用于回调按钮点击事件到Activity
     * @author Ivan Xu
     * 2014-11-26
     */
    public interface Callback {
        public void click(View v);
    }
}
