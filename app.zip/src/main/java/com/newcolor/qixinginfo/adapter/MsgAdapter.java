package com.newcolor.qixinginfo.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.model.Msg;
import com.newcolor.qixinginfo.ui.badge.BadgeView;

import java.util.List;

/**
 * 消息的adapter
 *
 * Created by baolei.si on 2015/8/14.
 */
public class MsgAdapter extends BaseAdapter {
    private Context mContext;
    //xml转View对象
    private LayoutInflater mInflater;
    //单行的布局
    private int mResource;
    //列表展现的数据
    private List mData;
    //view的id
    private int[] mTo;

    private int iconId;


    public MsgAdapter(Context context, List data,
                      int resource, int[] to, int iconId){
        this.mContext = context;
        this.mData = data;
        this.mResource = resource;
        this.mTo = to;
        this.iconId=iconId;
        //用于将xml转为View
        this.mInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public Object getItem(int position) {
        return mData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        MsgListViewHolder holder;
        if(convertView == null){
            //使用自定义的list_items作为Layout
            convertView = mInflater.inflate(mResource, parent, false);

            holder = new MsgListViewHolder();
            holder.itemImage=(ImageView)convertView.findViewById(mTo[0]);
            holder.itemTitle = (TextView) convertView.findViewById(mTo[1]);
            holder.listItemContent = (TextView) convertView.findViewById(mTo[2]);
//            holder.badge = new BadgeView(mContext);
//            holder.badge.setTargetView(holder.itemsTitle);
//            holder.badge.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.ITALIC));
//            holder.badge.setShadowLayer(2, -1, -1, Color.GREEN);
//            holder.badge.setBadgeGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
//            holder.badge.setBadgeMargin(0, 0, 8, 0);
            convertView.setTag(holder);
        }else {
            holder = (MsgListViewHolder) convertView.getTag();
        }

        //获取该行的数据
        final Msg msg = (Msg)mData.get(position);
        if(msg.getMsgState().equals("2")) {
            holder.itemImage.setImageResource(R.mipmap.ic_gong_gao);
        }else{
            holder.itemImage.setImageResource(R.mipmap.ic_new_gong_gao);
        }
        holder.itemTitle.setText(msg.getTitle());
        holder.listItemContent.setText(msg.getContent());
//        holder.badge.setBadgeCount(18);


        return convertView;
    }

    static class MsgListViewHolder {
        ImageView itemImage;
        TextView itemTitle;
        TextView listItemContent;
        BadgeView badge;

    }
}
