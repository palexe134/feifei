package com.newcolor.qixinginfo.adapter;

import android.content.Context;
import android.text.Html;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.model.Msg;
import com.newcolor.qixinginfo.util.StrUtil;

import java.util.List;

/**
 *订阅消息列表的adapter
 *
 * Created by Administrator on 2015/10/10.
 */
public class SubscribeAdapter  extends BaseAdapter implements View.OnClickListener {
    private Context mContext;
    //xml转View对象
    private LayoutInflater mInflater;
    //单行的布局
    private int mResource;
    //列表展现的数据
    private List mData;
    //view的id
    private int[] mTo;
    private Callback callback;


    public SubscribeAdapter(Context context, List data,
                              int resource, int[] to,Callback callback) {

        this.mContext = context;
        this.mData = data;
        this.mResource = resource;
        this.mTo = to;
        this.callback=callback;
        //用于将xml转为View
        this.mInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public Object getItem(int position) {
        return mData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        SubscribeViewHolder holder;
        if(convertView == null){
            //使用自定义的list_items作为Layout
            convertView = mInflater.inflate(mResource, parent, false);

            holder = new SubscribeViewHolder();
            holder.timeTV=(TextView)convertView.findViewById(mTo[0]);
            holder.contentTV = (TextView) convertView.findViewById(mTo[1]);
            holder.select_CB = (CheckBox) convertView.findViewById(mTo[2]);
            holder.bg_RL = (RelativeLayout) convertView.findViewById(mTo[3]);
            convertView.setTag(holder);
        }else {
            holder = (SubscribeViewHolder) convertView.getTag();
        }

        //获取该行的数据
        final Msg vo = (Msg)mData.get(position);

        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
//        layoutParams.topMargin=30;
//        layoutParams.addRule(RelativeLayout.BELOW, R.id.tv_time);
        layoutParams.setMargins(5,5,5,5);
//        layoutParams.(5,5,5,5);

        if(vo.getFlag()==0){
            holder.bg_RL.setBackgroundResource(R.drawable.chat_bg_1);
//            layoutParams.addRule(RelativeLayout.ALIGN_PARENT_LEFT, RelativeLayout.TRUE);
        }else{
            holder.bg_RL.setBackgroundResource(R.drawable.chat_bg);
//            layoutParams.addRule(RelativeLayout.ALIGN_PARENT_RIGHT, RelativeLayout.TRUE);
//            holder.contentTV.setLayoutParams(layoutParams);
        }
        holder.bg_RL.setLayoutParams(layoutParams);
        holder.timeTV.setText(vo.getMTime());
        holder.contentTV.setText(Html.fromHtml(StrUtil.ToDBC(vo.getContent())));
        holder.select_CB.setChecked(vo.isSelected());
        holder.select_CB.setOnClickListener(this);
        holder.select_CB.setTag(vo);
        holder.select_CB.setVisibility(vo.isShow()?View.VISIBLE:View.GONE);

        return convertView;
    }

    @Override
    public void onClick(View v) {
        this.callback.onSelectChange(v);
    }

    static class SubscribeViewHolder {
        TextView timeTV;
        TextView contentTV;
        CheckBox select_CB;
        RelativeLayout bg_RL;

    }


    /**
     * 自定义接口，用于回调按钮点击事件到Activity
     * @author Ivan Xu
     * 2014-11-26
     */
    public interface Callback {
        public void onSelectChange(View v);
    }

}
