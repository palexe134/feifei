package com.newcolor.qixinginfo.adapter;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.model.Msg;
import com.newcolor.qixinginfo.model.PayInfoVO;
import com.newcolor.qixinginfo.ui.badge.BadgeView;
import com.newcolor.qixinginfo.util.HttpUtil;
import com.newcolor.qixinginfo.util.StrUtil;
import com.newcolor.qixinginfo.util.ToastUtil;
import com.newcolor.qixinginfo.util.Tools;

import java.util.List;

/**
 * 支付方式的adapter
 *
 * Created by baolei.si on 2015/8/14.
 */
public class PayInfoAdapter extends BaseAdapter implements View.OnClickListener {
    private Context mContext;
    //xml转View对象
    private LayoutInflater mInflater;
    //单行的布局
    private int mResource;
    //列表展现的数据
    private List mData;
    //view的id
    private int[] mTo;


    public PayInfoAdapter(Context context, List data,
                          int resource, int[] to){
        this.mContext = context;
        this.mData = data;
        this.mResource = resource;
        this.mTo = to;
        //用于将xml转为View
        this.mInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public Object getItem(int position) {
        return mData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        MsgListViewHolder holder;
        if(convertView == null){
            //使用自定义的list_items作为Layout
            convertView = mInflater.inflate(mResource, parent, false);

            holder = new MsgListViewHolder();
            holder.pay_IV=(ImageView)convertView.findViewById(mTo[0]);
            holder.pay_type_TV = (TextView) convertView.findViewById(mTo[1]);
            holder.pay_account_TV = (TextView) convertView.findViewById(mTo[2]);
            holder.pay_owner_TV = (TextView) convertView.findViewById(mTo[3]);
            holder.copy_TV = (TextView) convertView.findViewById(mTo[4]);
//            holder.badge = new BadgeView(mContext);
//            holder.badge.setTargetView(holder.itemsTitle);
//            holder.badge.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.ITALIC));
//            holder.badge.setShadowLayer(2, -1, -1, Color.GREEN);
//            holder.badge.setBadgeGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
//            holder.badge.setBadgeMargin(0, 0, 8, 0);
            convertView.setTag(holder);
        }else {
            holder = (MsgListViewHolder) convertView.getTag();
        }

        //获取该行的数据
        final PayInfoVO vo = (PayInfoVO)mData.get(position);
        holder.pay_IV.setImageResource(vo.getIcon());
        holder.pay_type_TV.setText("支持：" + vo.getPayType());
        holder.pay_account_TV.setText(StrUtil.ToDBC("账号：" + vo.getPayAccount()));
        holder.pay_owner_TV.setText("持卡人："+vo.getPayOwner());
        holder.copy_TV.setText(Html.fromHtml("<u>复制</u>"));
        holder.copy_TV.setOnClickListener(this);
        holder.copy_TV.setTag(vo);
//        holder.badge.setBadgeCount(18);


        return convertView;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.copy_TV:
                PayInfoVO vo= (PayInfoVO) v.getTag();
                // 得到剪贴板管理器
                ClipboardManager cmb = (ClipboardManager)mContext.getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData myClip = ClipData.newPlainText("text", vo.getPayAccount());
                cmb.setPrimaryClip(myClip);
                ToastUtil.showToast(mContext,"复制成功");
                break;
        }

    }

    static class MsgListViewHolder {
        ImageView pay_IV;
        TextView pay_type_TV;
        TextView pay_account_TV;
        TextView pay_owner_TV;
        TextView copy_TV;

    }
}
