package com.newcolor.qixinginfo.adapter;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.newcolor.qixinginfo.model.AppVO;
import com.newcolor.qixinginfo.model.ZiXunVO;
import com.newcolor.qixinginfo.ui.badge.BadgeView;
import com.newcolor.qixinginfo.util.DateUtils;

import java.util.List;

/**
 *
 * 资讯列表的adapter
 *
 * Created by Administrator on 2015/10/10.
 */
public class ZiXunAdapter extends BaseAdapter {
    private Context mContext;
    //xml转View对象
    private LayoutInflater mInflater;
    //单行的布局
    private int mResource;
    //列表展现的数据
    private List mData;
    //view的id
    private int[] mTo;


    public ZiXunAdapter(Context context, List data,
                        int resource, int[] to) {

        this.mContext = context;
        this.mData = data;
        this.mResource = resource;
        this.mTo = to;
        //用于将xml转为View
        this.mInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public Object getItem(int position) {
        return mData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        SubscribeViewHolder holder;
        if(convertView == null){
            //使用自定义的list_items作为Layout
            convertView = mInflater.inflate(mResource, parent, false);

            holder = new SubscribeViewHolder();
            holder.title_TV=(TextView)convertView.findViewById(mTo[0]);
            holder.time_TV = (TextView) convertView.findViewById(mTo[1]);
            convertView.setTag(holder);
        }else {
            holder = (SubscribeViewHolder) convertView.getTag();
        }

        //获取该行的数据
        final ZiXunVO vo = (ZiXunVO)mData.get(position);

        holder.title_TV.setText(vo.getTitle());
        holder.time_TV.setText(DateUtils.formatSimpleDateTime(vo.getAddtime() * 1000));
        return convertView;
    }

    static class SubscribeViewHolder {
        TextView title_TV;
        TextView time_TV;

    }

}
