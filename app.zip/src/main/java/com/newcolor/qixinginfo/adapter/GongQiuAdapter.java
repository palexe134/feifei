package com.newcolor.qixinginfo.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.global.Constant;
import com.newcolor.qixinginfo.model.GongHuoVO;
import com.newcolor.qixinginfo.util.DateUtils;
import com.newcolor.qixinginfo.util.Tools;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;
import com.nostra13.universalimageloader.core.listener.SimpleImageLoadingListener;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

/**
 * 供求列表的adapter
 *
 * Created by Administrator on 2015/10/13.
 */
public class GongQiuAdapter extends BaseAdapter implements View.OnClickListener {
    private Context mContext;
    //xml转View对象
    private LayoutInflater mInflater;
    //单行的布局
    private int mResource;
    //列表展现的数据
    private List mData;
    //view的id
    private int[] mTo;
    private Callback callback;

    private ImageLoadingListener animateFirstListener = new AnimateFirstDisplayListener();

//    private static final String[] IMAGE_URLS = Constant.IMAGES;


    public GongQiuAdapter(Context context, List data,
                      int resource, int[] to,Callback callback) {

        this.mContext = context;
        this.mData = data;
        this.mResource = resource;
        this.mTo = to;
        this.callback=callback;
        //用于将xml转为View
        this.mInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public Object getItem(int position) {
        return mData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        SubscribeViewHolder holder;
        if(convertView == null){
            //使用自定义的list_items作为Layout
            convertView = mInflater.inflate(mResource, parent, false);

            holder = new SubscribeViewHolder();
            holder.img_IV=(ImageView)convertView.findViewById(mTo[0]);
            holder.phone_IV = (ImageButton) convertView.findViewById(mTo[1]);
            holder.title_TV = (TextView) convertView.findViewById(mTo[2]);
            holder.address_TV = (TextView) convertView.findViewById(mTo[3]);
            holder.content_TV = (TextView) convertView.findViewById(mTo[4]);
            holder.star_LL = (LinearLayout) convertView.findViewById(mTo[5]);
            holder.time_TV = (TextView) convertView.findViewById(mTo[6]);
            holder.icon_IV = (ImageView) convertView.findViewById(mTo[7]);
            holder.distance_TV = (TextView) convertView.findViewById(mTo[8]);
            holder.content_LL = (LinearLayout) convertView.findViewById(mTo[9]);
            holder.bg_LL = (LinearLayout) convertView.findViewById(mTo[10]);
            if(mTo.length>11) {
                holder.select_CB = (CheckBox) convertView.findViewById(mTo[11]);
            }
            convertView.setTag(holder);
        }else {
            holder = (SubscribeViewHolder) convertView.getTag();
        }

        //获取该行的数据
        final GongHuoVO vo = (GongHuoVO)mData.get(position);

        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);

//        holder.img_IV.setImageResource(vo.getImgUrl());
        String aa=vo.getImgUrl();
        if(!aa.isEmpty()) {
            Tools.loadImg(mContext, vo.getImgUrl(), holder.img_IV, Constant.options, animateFirstListener, R.mipmap.ic_empty);
        }else{
            holder.img_IV.setImageResource(R.mipmap.ic_empty);
        }
        holder.title_TV.setText(vo.getTitle());
        holder.address_TV.setText("地址：" + vo.getAddress());
        if(vo.getContent()==null||vo.getContent().isEmpty()){
            holder.content_TV.setVisibility(View.GONE);
        }else {
            holder.content_TV.setVisibility(View.VISIBLE);
            holder.content_TV.setText(vo.getContent());
        }
        holder.time_TV.setText(DateUtils.formatSimpleDateTime(vo.getmTime() * 1000));
//        holder.img_IV.setOnClickListener(this);
//        holder.img_IV.setTag(vo);
        holder.phone_IV.setOnClickListener(this);
        holder.phone_IV.setTag(vo);
//        holder.content_LL.setOnClickListener(this);
//        holder.content_LL.setTag(vo);
        if(holder.select_CB!=null) {
            holder.select_CB.setChecked(vo.isSelected());
            holder.select_CB.setOnClickListener(this);
            holder.select_CB.setTag(vo);
            holder.select_CB.setVisibility(vo.isShow() ? View.VISIBLE : View.GONE);
        }

        if(vo.getTopId()>0){
            holder.icon_IV.setVisibility(View.VISIBLE);
            holder.title_TV.setTextColor(Color.rgb(0xda,0x30,0x0f));
            holder.bg_LL.setBackgroundResource(R.drawable.shape_orange_border_gong_qiu_bg);
        }else{
            holder.icon_IV.setVisibility(View.GONE);
            holder.title_TV.setTextColor(Color.BLACK);
            holder.bg_LL.setBackgroundResource(R.drawable.shape_gray_border_gong_qiu_bg);
        }

        if(vo.getDistance()>=1000) {
            holder.distance_TV.setText(vo.getDistance() / 1000 + "km");
        }else if(vo.getDistance()<1000&&vo.getDistance()>=0){
            holder.distance_TV.setText(vo.getDistance() + "m");
        }else{
            holder.distance_TV.setText("未知");
        }


        return convertView;
    }

    @Override
    public void onClick(View v) {
        if(callback!=null) {
            callback.click(v);
        }
    }


    static class SubscribeViewHolder {
        ImageView img_IV;
        ImageButton phone_IV;
        TextView title_TV;
        TextView address_TV;
        TextView content_TV;
        LinearLayout star_LL;
        TextView time_TV;
        CheckBox select_CB;
        ImageView icon_IV;
        TextView distance_TV;
        LinearLayout content_LL;
        LinearLayout bg_LL;
    }


    private static class AnimateFirstDisplayListener extends SimpleImageLoadingListener {

        static final List<String> displayedImages = Collections.synchronizedList(new LinkedList<String>());

        @Override
        public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
            if (loadedImage != null) {
                ImageView imageView = (ImageView) view;
                imageView.setImageBitmap(loadedImage);
                boolean firstDisplay = !displayedImages.contains(imageUri);
                if (firstDisplay) {
//                    FadeInBitmapDisplayer.animate(imageView, 500);
                    displayedImages.add(imageUri);
                }
            }
        }
    }


    /**
    * 自定义接口，用于回调按钮点击事件到Activity
    * @author Ivan Xu
    * 2014-11-26
    */
    public interface Callback {
        public void click(View v);
    }
}
