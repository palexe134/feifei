package com.newcolor.qixinginfo.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.global.Constant;
import com.newcolor.qixinginfo.model.BaiDuMapGeoVO;
import com.newcolor.qixinginfo.model.BaiDuMapGongQiuVO;
import com.newcolor.qixinginfo.model.GongHuoVO;
import com.newcolor.qixinginfo.util.DateUtils;
import com.newcolor.qixinginfo.util.Tools;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;
import com.nostra13.universalimageloader.core.listener.SimpleImageLoadingListener;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

/**
 * 百度地图下方显示列表的adapter
 *
 * Created by Administrator on 2015/10/13.
 */
public class BaiduMapGeoAdapter extends BaseAdapter implements View.OnClickListener {
    private Context mContext;
    //xml转View对象
    private LayoutInflater mInflater;
    //单行的布局
    private int mResource;
    //列表展现的数据
    private List mData;
    //view的id
    private int[] mTo;
    private Callback callback;


    public BaiduMapGeoAdapter(Context context, List data,
                              int resource, int[] to, Callback callback) {

        this.mContext = context;
        this.mData = data;
        this.mResource = resource;
        this.mTo = to;
        this.callback=callback;
        //用于将xml转为View
        this.mInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public Object getItem(int position) {
        return mData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        SubscribeViewHolder holder;
        if(convertView == null){
            //使用自定义的list_items作为Layout
            convertView = mInflater.inflate(mResource, parent, false);

            holder = new SubscribeViewHolder();
            holder.title_TV = (TextView) convertView.findViewById(mTo[0]);
            holder.content_TV = (TextView) convertView.findViewById(mTo[1]);
            holder.address_TV = (TextView) convertView.findViewById(mTo[2]);
            holder.phone_IV = (ImageView) convertView.findViewById(mTo[3]);
            convertView.setTag(holder);
        }else {
            holder = (SubscribeViewHolder) convertView.getTag();
        }

        //获取该行的数据
        final BaiDuMapGeoVO vo = (BaiDuMapGeoVO)mData.get(position);

        holder.title_TV.setText(vo.getTitle());
        holder.address_TV.setText("地址：" + vo.getAddress());
        if(vo.getContent()==null||vo.getContent().isEmpty()){
            holder.content_TV.setVisibility(View.GONE);
        }else {
            holder.content_TV.setVisibility(View.VISIBLE);
        }
        if(vo.getType()==1) {
            holder.content_TV.setText(vo.getContent());
            holder.phone_IV.setVisibility(View.VISIBLE);
        }else{
            holder.content_TV.setText("主营：" + vo.getContent());
            holder.phone_IV.setVisibility(View.GONE);
        }
        holder.phone_IV.setOnClickListener(this);
        holder.phone_IV.setTag(vo);

        return convertView;
    }

    @Override
    public void onClick(View v) {
        callback.click(v);
    }


    static class SubscribeViewHolder {
        ImageView phone_IV;
        TextView title_TV;
        TextView address_TV;
        TextView content_TV;

    }

    /**
    * 自定义接口，用于回调按钮点击事件到Activity
    * @author Ivan Xu
    * 2014-11-26
    */
    public interface Callback {
        public void click(View v);
    }
}
