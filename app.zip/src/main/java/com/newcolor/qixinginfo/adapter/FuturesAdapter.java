package com.newcolor.qixinginfo.adapter;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.entity.FutruesEntity;
import com.newcolor.qixinginfo.global.Constant;
import com.newcolor.qixinginfo.view.AddImageView;
import com.nostra13.universalimageloader.core.ImageLoader;

import java.text.DecimalFormat;
import java.util.List;

/**
 * 期货列表的adapter
 *
 * Created by Administrator on 2015/10/19.
 */
public class FuturesAdapter extends BaseAdapter  implements View.OnClickListener {
    private Context mContext;
    //xml转View对象
    private LayoutInflater mInflater;
    //列表展现的数据
    private List mData;
    //view的id
    private int[] mTo;
    private Callback callback;


    public FuturesAdapter(Context context, List data, Callback callback) {

        this.mContext = context;
        this.mData = data;
        this.callback=callback;
        //用于将xml转为View
        this.mInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public Object getItem(int position) {
        return mData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ImageHolder holder;
        if(convertView == null){
            //使用自定义的list_items作为Layout
            convertView = mInflater.inflate(R.layout.item_list_future, parent, false);

            holder = new ImageHolder();
            holder.name_TV=(TextView)convertView.findViewById(R.id.futrue_name_TV);
            holder.now_price_TV=(TextView)convertView.findViewById(R.id.now_price_TV);
            holder.zhang_die_TV=(TextView)convertView.findViewById(R.id.zhang_die_TV);
            holder.zhang_die_fu_TV=(TextView)convertView.findViewById(R.id.zhang_die_fu_TV);
            holder.kai_pan_TV=(TextView)convertView.findViewById(R.id.kai_pan_TV);
            convertView.setTag(holder);
        }else {
            holder = (ImageHolder) convertView.getTag();
        }

        //获取该行的数据
        final FutruesEntity vo = (FutruesEntity)mData.get(position);

        holder.name_TV.setText(vo.getName());
        if(vo.getChangeAmount()>0) {
            holder.now_price_TV.setTextColor(Color.RED);
            holder.zhang_die_TV.setTextColor(Color.RED);
            holder.zhang_die_fu_TV.setTextColor(Color.RED);
        }else if(vo.getChangeAmount()==0){
            holder.now_price_TV.setTextColor(Color.WHITE);
            holder.zhang_die_TV.setTextColor(Color.WHITE);
            holder.zhang_die_fu_TV.setTextColor(Color.WHITE);
        }else{
            holder.now_price_TV.setTextColor(Color.GREEN);
            holder.zhang_die_TV.setTextColor(Color.GREEN);
            holder.zhang_die_fu_TV.setTextColor(Color.GREEN);
        }
        DecimalFormat df=new DecimalFormat("#.##");
        holder.name_TV.setText(vo.getName());
        holder.now_price_TV.setText(String.valueOf(vo.getPrice()));
        holder.zhang_die_TV.setText(String.valueOf(df.format(vo.getChangeAmount())));
        holder.zhang_die_fu_TV.setText(String.valueOf(df.format(vo.getChangeRate()))+"%");
        holder.kai_pan_TV.setText(String.valueOf(df.format(vo.getOpen())));
        return convertView;
    }

    @Override
    public void onClick(View v) {
        callback.click(v);
    }

    static class ImageHolder {
        TextView name_TV;
        TextView kai_pan_TV;
        TextView zhang_die_fu_TV;
        TextView zhang_die_TV;
        TextView now_price_TV;

    }

    /**
     * 自定义接口，用于回调按钮点击事件到Activity
     * @author Ivan Xu
     * 2014-11-26
     */
    public interface Callback {
        public void click(View v);
    }
}
