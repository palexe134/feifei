package com.newcolor.qixinginfo.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.newcolor.qixinginfo.model.Msg;

import java.util.List;

/**
 * 锁屏提示窗的adapter
 *
 * Created by Administrator on 2015/10/25.
 */
public class AlarmItemAdapter extends BaseAdapter {
    private Context mContext;
    //xml转View对象
    private LayoutInflater mInflater;
    //单行的布局
    private int mResource;
    //列表展现的数据
    private List mData;
    //view的id
    private int[] mTo;


    public AlarmItemAdapter(Context context, List data,
                      int resource, int[] to) {

        this.mContext = context;
        this.mData = data;
        this.mResource = resource;
        this.mTo = to;
        //用于将xml转为View
        this.mInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public Object getItem(int position) {
        return mData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        AlarmViewHolder holder;
        if(convertView == null){
            //使用自定义的list_items作为Layout
            convertView = mInflater.inflate(mResource, parent, false);

            holder = new AlarmViewHolder();
            holder.content_TV=(TextView)convertView.findViewById(mTo[0]);
            holder.time_TV = (TextView) convertView.findViewById(mTo[1]);
            convertView.setTag(holder);
        }else {
            holder = (AlarmViewHolder) convertView.getTag();
        }

        //获取该行的数据
        final Msg vo = (Msg)mData.get(position);

        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);

        holder.content_TV.setText(vo.getContent());
        holder.time_TV.setText(vo.getMTime());

        return convertView;
    }

    static class AlarmViewHolder {
        TextView content_TV;
        TextView time_TV;

    }

}
