package com.newcolor.qixinginfo.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.model.AppVO;
import com.newcolor.qixinginfo.model.MeVO;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;

/**
 * 我的下方列表的adapter
 *
 * Created by Administrator on 2015/10/10.
 */
public class MeAdapter extends BaseAdapter {
    private static final int TYPE_ITEM = 0;
    private static final int TYPE_SEPARATOR = 1;
    private static final int TYPE_MAX_COUNT = TYPE_SEPARATOR + 1;

    private Context mContext;
    //xml转View对象
    private LayoutInflater mInflater;
    //列表展现的数据
    private List mData;
    //view的id
    private int[] mTo;

    private TreeSet mSeparatorsSet = new TreeSet();


    public MeAdapter(Context context, List data, int[] to) {
        mData=new ArrayList();

        this.mContext = context;
        MeVO vo;
        for (int i = 0; i < data.size(); i++) {
            vo=(MeVO) data.get(i);
            if(vo.getName().equals("separator")){
                this.addSeparatorItem(vo);
            }else {
                this.addItem(vo);
            }

        }
        this.mTo = to;
        //用于将xml转为View
        this.mInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);


        notifyDataSetChanged();
    }

    private void addItem(final MeVO item) {
        mData.add(item);
    }

    private void addSeparatorItem(final MeVO item) {
        mData.add(item);
        // save separator position
        mSeparatorsSet.add(mData.size() - 1);
    }

    @Override
    public int getItemViewType(int position) {
        return mSeparatorsSet.contains(position) ? TYPE_SEPARATOR : TYPE_ITEM;
    }

    @Override
    public int getViewTypeCount() {
        return TYPE_MAX_COUNT;
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public Object getItem(int position) {
        return mData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        int type = getItemViewType(position);
        MeViewHolder holder;
        if(convertView == null){
            //使用自定义的list_items作为Layout
//            convertView = mInflater.inflate(mResource, parent, false);

            holder = new MeViewHolder();
            switch (type) {
                case TYPE_ITEM:
                    convertView = mInflater.inflate(R.layout.item_list_me, null);
                    holder.img_IV = (ImageView) convertView.findViewById(mTo[0]);
                    holder.name_TV = (TextView) convertView.findViewById(mTo[1]);
                    break;
                case TYPE_SEPARATOR:
                    convertView = mInflater.inflate(R.layout.item_me_separator, null);
//                    holder.textView = (TextView)convertView.findViewById(R.id.textSeparator);
                    break;
            }

            convertView.setTag(holder);
        }else {
            holder = (MeViewHolder) convertView.getTag();
        }

        if(type==TYPE_ITEM) {
            //获取该行的数据
            final MeVO vo = (MeVO) mData.get(position);
            holder.name_TV.setText(vo.getName());
            holder.img_IV.setImageResource(vo.getIconId());
        }


        return convertView;
    }

    static class MeViewHolder {
        ImageView img_IV;
        TextView name_TV;

    }

}
