package com.newcolor.qixinginfo.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.global.Constant;
import com.newcolor.qixinginfo.model.GongHuoVO;
import com.newcolor.qixinginfo.util.Tools;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;
import com.nostra13.universalimageloader.core.listener.SimpleImageLoadingListener;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

/**
 * 首页下方推荐列表的adapter
 *
 * Created by baolei.si on 2015/8/10.
 */
public class HomePageAdapter extends BaseAdapter{
    private Context mContext;
    //xml转View对象
    private LayoutInflater mInflater;
    //单行的布局
    private int mResource;
    //列表展现的数据
    private List mData;
    //view的id
    private int[] mTo;

    private int type;

    private ImageLoadingListener animateFirstListener = new AnimateFirstDisplayListener();

    public HomePageAdapter(Context context, List data,
                           int resource, int[] to,int type){
        this.mContext = context;
        this.mData = data;
        this.mResource = resource;
        this.mTo = to;
        this.type=type;
        //用于将xml转为View
        this.mInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public Object getItem(int position) {
        return mData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        HomePageViewHolder holder;
        if(convertView == null){
            //使用自定义的list_items作为Layout
            convertView = mInflater.inflate(mResource, parent, false);

            holder = new HomePageViewHolder();
            holder.title_TV=(TextView)convertView.findViewById(mTo[0]);
            holder.img_IV=(ImageView)convertView.findViewById(mTo[1]);
            holder.icon_IV=(ImageView)convertView.findViewById(mTo[2]);
            holder.price_TV=(TextView)convertView.findViewById(mTo[3]);
            holder.num_TV=(TextView)convertView.findViewById(mTo[4]);
            convertView.setTag(holder);
        }else {
            holder = (HomePageViewHolder) convertView.getTag();
        }

        //获取该行的数据
        final GongHuoVO vo = (GongHuoVO)mData.get(position);
        holder.title_TV.setText(vo.getTitle());
        holder.price_TV.setText(vo.getPrice()+"元/吨");
        holder.num_TV.setText(vo.getNum()+"吨");
        if(!vo.getImgUrl().isEmpty()) {
            Tools.loadImg(mContext, vo.getImgUrl(), holder.img_IV, Constant.getSimpleDisplayImage(R.mipmap.default_home_page_tui_jian),
                    animateFirstListener, R.mipmap.default_home_page_tui_jian);
        }else{
            holder.img_IV.setImageResource(R.mipmap.default_home_page_tui_jian);
        }

        holder.icon_IV.setImageResource(0);

        if(vo.getTopId()>0){

        }

        return convertView;
    }



    private static class AnimateFirstDisplayListener extends SimpleImageLoadingListener {

        static final List<String> displayedImages = Collections.synchronizedList(new LinkedList<String>());

        @Override
        public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
            if (loadedImage != null) {
                ImageView imageView = (ImageView) view;
                imageView.setImageBitmap(loadedImage);
                boolean firstDisplay = !displayedImages.contains(imageUri);
                if (firstDisplay) {
//                    FadeInBitmapDisplayer.animate(imageView, 500);
                    displayedImages.add(imageUri);
                }
            }
        }
    }


    static class HomePageViewHolder {
        TextView title_TV;
        TextView price_TV;
        TextView num_TV;
        ImageView img_IV;
        ImageView icon_IV;
    }
}
