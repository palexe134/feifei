package com.newcolor.qixinginfo.adapter;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;


import com.newcolor.qixinginfo.ui.badge.BadgeView;

import java.util.List;
import java.util.Map;

/**
 * 消息列表的adapter
 *
 * Created by baolei.si on 2015/8/10.
 */
public class FragmentMsgAdapter extends BaseAdapter{
    private Context mContext;
    //xml转View对象
    private LayoutInflater mInflater;
    //单行的布局
    private int mResource;
    //列表展现的数据
    private List mData;
    //Map中的key
    private String[] mFrom;
    //view的id
    private int[] mTo;


    public FragmentMsgAdapter(Context context, List data,
                              int resource, String[] from, int[] to){
        this.mContext = context;
        this.mData = data;
        this.mResource = resource;
        this.mFrom = from;
        this.mTo = to;
        //用于将xml转为View
        this.mInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public Object getItem(int position) {
        return mData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        MsgViewHolder holder;
        if(convertView == null){
            //使用自定义的list_items作为Layout
            convertView = mInflater.inflate(mResource, parent, false);

            holder = new MsgViewHolder();
            holder.itemsIcon=(ImageView)convertView.findViewById(mTo[0]);
            holder.itemsTitle = (TextView) convertView.findViewById(mTo[1]);
            holder.badge = new BadgeView(mContext);
            holder.badge.setTargetView(holder.itemsTitle);
            holder.badge.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.ITALIC));
            holder.badge.setShadowLayer(2, -1, -1, Color.GREEN);
            holder.badge.setBadgeGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
            holder.badge.setBadgeMargin(0, 0, 8, 0);
            convertView.setTag(holder);
        }else {
            holder = (MsgViewHolder) convertView.getTag();
        }

        //获取该行的数据
        final Map<String, Object> obj = (Map<String, Object>)mData.get(position);
        holder.itemsIcon.setImageResource((Integer) obj.get("itemIcon"));
        holder.itemsTitle.setText((Integer) obj.get("itemTitle"));
        holder.badge.setBadgeCount((Integer) obj.get("count"));

//        if(badgeView==null){
//            badgeView = new BadgeView(this.mContext);
//            badgeView.setBadgeCount(18);
//            badgeView.setTargetView(itemsIcon);
//            badgeView.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.ITALIC));
//            badgeView.setShadowLayer(2, -1, -1, Color.GREEN);
//        }

        return convertView;
    }

    static class MsgViewHolder {
        ImageView itemsIcon;
        TextView itemsTitle;
        BadgeView badge;

    }
}
