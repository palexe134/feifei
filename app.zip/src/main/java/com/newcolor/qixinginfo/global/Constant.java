package com.newcolor.qixinginfo.global;


import android.content.Context;
import android.os.Environment;

import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.util.Tools;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.display.RoundedBitmapDisplayer;
import com.nostra13.universalimageloader.core.display.SimpleBitmapDisplayer;

public class Constant {
	//老            FF:6E:80:5A:58:BE:0D:6C:23:A6:C8:52:4A:49:C6:6E:84:65:FC:EE
	//2016-4-14     B0:17:D7:1C:19:61:17:31:30:20:4F:EE:E3:E3:B3:5D:AF:F5:8C:D1

	//数字签名     307b4b0408330005d50711d440143397

	public static final boolean DEBUG = true;
	public static final String sharePath = "qixing_share";
	public static final String config = "config";
    public static final String USERSID = "user";
    public static final String USERNAMECOOKIE = "USERNAMECOOKIE";
    public static final String USERPASSWORDCOOKIE = "USERPASSWORDCOOKIE";
    public static final String ISFIRSTSTART = "ISFIRSTSTART";
    public static final String TOKEN = "TOKEN";//令牌
    public static final String ISSAVEPHONECONTACT = "ISSAVEPHONECONTACT";//保存用户联系人列表

    // 连接超时
 	public static final int timeOut = 12000;
 	// 建立连接
 	public static final int connectOut = 12000;
 	// 获取数据
 	public static final int getOut = 60000;
 	
 	//1表示已下载完成
 	public static final int downloadComplete = 1;
 	//1表示未开始下载
 	public static final int undownLoad = 0;
 	//2表示已开始下载
 	public static final int downInProgress = 2;
 	//3表示下载暂停
 	public static final int downLoadPause = 3;

 	public static final String BASEURL = "http://service.aaaly.com/f/index.php/home/index/";
// 	public static final String BASEURL = "http://service.aaaly.com/test/index.php/home/index/";
// 	public static final String BASEURL = "http://192.168.0.109:9096/interface/index.php/home/index/";
// 	public static final String BASEURL = "http://192.168.0.150:9096/interface/index.php/home/index/";
// 	public static final String BASEURL = "http://192.168.0.66/service.aaaly.com/f/index.php/home/index/";


 	//应用的key
 	//1512528
 	public final static String APPID = "1512528";
 	//jfa97P4HIhjxrAgfUdq1NoKC
 	public final static String APIKEY = "jfa97P4HIhjxrAgfUdq1NoKC";
	/* 在多少天内不检查升级 */
	public final static int defaultMinUpdateDay = 50;

	public static boolean isAppFirst=true;


	public static class Config {
		public static final boolean DEVELOPER_MODE = false;
	}


	// 拍照的照片存储位置
	public static final String PHOTO_DIR = Environment.getExternalStorageDirectory()+ "/DCIM/Camera";


	public static DisplayImageOptions options = new DisplayImageOptions.Builder()
				.showImageOnLoading(R.mipmap.ic_empty)
				.showImageForEmptyUri(R.mipmap.ic_empty)
				.showImageOnFail(R.mipmap.ic_empty)
				.cacheInMemory(true)
				.cacheOnDisk(true)
				.considerExifParams(true)
				.displayer(new RoundedBitmapDisplayer(20))
				.build();

	public static DisplayImageOptions getCircleHeadOptions (Context mContext){
		return new DisplayImageOptions.Builder()
				.showImageOnLoading(R.mipmap.defaulthead)
				.showImageForEmptyUri(R.mipmap.defaulthead)
				.showImageOnFail(R.mipmap.defaulthead)
				.cacheInMemory(true)
				.cacheOnDisk(true)
				.considerExifParams(true)
				.displayer(new RoundedBitmapDisplayer(Tools.dp2px(mContext, 50)))
				.build();
	}



	public static  DisplayImageOptions getSimpleDisplayImage(int id){
		return new DisplayImageOptions.Builder()
			.showImageOnLoading(id)
			.showImageForEmptyUri(id)
			.showImageOnFail(id)
			.cacheInMemory(true)
			.cacheOnDisk(true)
			.considerExifParams(true)
			.displayer(new SimpleBitmapDisplayer())
			.build();
	}

	public static DisplayImageOptions headOptions = new DisplayImageOptions.Builder()
			.showImageOnLoading(R.mipmap.defaulthead)
			.showImageForEmptyUri(R.mipmap.defaulthead)
			.showImageOnFail(R.mipmap.defaulthead)
			.cacheInMemory(true)
			.cacheOnDisk(true)
			.considerExifParams(true)
			.displayer(new RoundedBitmapDisplayer(20))
			.build();



	public static DisplayImageOptions addImgOptions = new DisplayImageOptions.Builder()
			.showImageOnLoading(R.mipmap.ic_add_img)
			.showImageForEmptyUri(R.mipmap.ic_add_img)
			.showImageOnFail(R.mipmap.ic_add_img)
			.cacheInMemory(true)
			.cacheOnDisk(true)
			.considerExifParams(true)
			.displayer(new SimpleBitmapDisplayer())
			.build();

}
