package com.newcolor.qixinginfo.global;

/**
 * 所有协议
 *
 * Created by Administrator on 2015/10/23.
 */
public class Config {
    //登录
    public static String userLogin="userLogin";
    //找回密码
    public static String findPassWord="findPassWord";
    //用户注册
    public static String userRegister="userRegister";
    //获取验证码
    public static String getAuthCode="getAuthCode";
    //添加联系人
    public static String addContactInfo="addContactInfo";
    //获取联系人列表
    public static String GetContactList="GetContactList";
    //获取供求列表
    public static String GetGongQiuList="GetGongQiuList";
    //删除联系人
    public static String DeletContactInfo="DeletContactInfo";
    //获取供求信息
    public static String GetGongQiuInfo="GetGongQiuInfo";
    //发布供求信息
    public static String ReleaseGongQiuInfo="ReleaseGongQiuInfo";
    //我的供求
    public static String MyGongQiuList="MyGongQiuList";
    //我的关注详情
    public static String AddMyAttention="AddMyAttention";
    //我的关注列表
    public static String MyAttentionList="MyAttentionList";
    //我的足迹
    public static String myFootprintList="myFootprintList";
    //获取我的界面信息
    public static String GetMeInfo="GetMeInfo";
    //用户反馈
    public static String userOpinion="userOpinion";
    //谁看过我列表
    public static String whoSeenMeList="whoSeenMeList";
    //供求搜索
    public static String searchInfoList="searchInfoList";
    //获取订阅消息
    public static String GetSubscribeMsgList="GetSubscribeMsgList";
    //获取消息列表
    public static String GetMsgList="GetMsgList";
    //获取消息详情
    public static String getMsgInfo="getMsgInfo";
    //获取未读消息数量
    public static String GetUnReadMsgCount="GetUnReadMsgCount";
    //获取系统设置
    public static String SystemSetting="SystemSetting";
    //修改个人信息
    public static String EditorMeInfo="EditorMeInfo";
    //获取版本信息
    public static String GetVersionInfo="GetVersionInfo";
    //更新版本信息
    public static String UpdateVersionInfo="UpdateVersionInfo";
    //删除我的供求信息
    public static String deleteMySDInfo="deleteMySDInfo";
    //删除我的足迹
    public static String deleteMyFoot="deleteMyFoot";
    //删除我的关注
    public static String deleteMyAtte="deleteMyAtte";
    //删除订阅信息
    public static String deleteSubInfo="deleteSubInfo";
    //(废弃)
    public static String getHomePageInfo="getHomePageInfo";
    //获取首页宣传图片
    public static String getHomePageImgs="getHomePageImgs";
    //获取买家卖家推荐信息列表
    public static String getHotchooseList="getHotchooseList";
    //获取推荐供求列表
    public static String getHotGongQiuList="getHotGongQiuList";
    //供求添加推广
    public static String addHotchooseInfo="addHotchooseInfo";
    //欢迎界面引导图
    public static String getWelcomeUrls="getWelcomeUrls";
    //获取分类信息
    public static String getClassification="getClassification";
    //获取附近供求
    public static String getNearbyGongQiu="getNearbyGongQiu";
    //刷新供求
    public static String refreshGongQiu="refreshGongQiu";
    //获取分类详情
    public static String getClassificationVo="getClassificationVo";
    //获取首页推荐列表
    public static String getHomePageTuiJianList="getHomePageTuiJianList";
    //获取首页资讯列表
    public static String getHomePageZiXunList="getHomePageZiXunList";
    //获取首页资讯详情
    public static String getHomePageZiXunInfo="getHomePageZiXunInfo";
    //获取指定区域回收站
    public static String getNearByRecycle="getNearByRecycle";
    //保存用户手机内的联系人列表
    public static String savePhoneContacts="savePhoneContacts";
}
