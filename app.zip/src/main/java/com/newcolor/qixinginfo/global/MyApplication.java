package com.newcolor.qixinginfo.global;

import android.content.Context;
import android.os.Build;
import android.os.StrictMode;

import com.activeandroid.ActiveAndroid;
import com.baidu.mapapi.SDKInitializer;
import com.newcolor.qixinginfo.bug.CrashHandler;
import com.newcolor.qixinginfo.model.Msg;
import com.newcolor.qixinginfo.model.UserVO;
import com.newcolor.qixinginfo.util.SharedUtil;
import com.newcolor.qixinginfo.util.Tools;
import com.nostra13.universalimageloader.cache.disc.naming.Md5FileNameGenerator;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.QueueProcessingType;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import cn.jpush.android.api.JPushInterface;
import cn.jpush.android.api.TagAliasCallback;

/**
 * Created by Administrator on 2015/10/8.
 */
public class MyApplication extends com.activeandroid.app.Application{
    private String userId="-1";
    private ArrayList<Msg> subscribeList=new ArrayList<Msg>();
    private UserVO curUserVo;
    private static MyApplication instance;
    public static MyApplication getInstance(){
        return instance;
    }

    public ArrayList<Msg> getSubscribeList() {
        return subscribeList;
    }

    public void setSubscribeList(ArrayList<Msg> subscribeList) {
        this.subscribeList = subscribeList;
    }



    public UserVO getCurUserVo() {
        if(curUserVo==null){
            curUserVo=new UserVO();
        }
        return curUserVo;
    }

    public void setCurUserVo(UserVO curUserVo) {
        this.curUserVo = curUserVo;
    }


    public void setUserId(String userId) {
        this.userId = userId;
        SharedUtil.putString(this, "userId", userId);
        Set<String> tags=new HashSet<String>();
        tags.add(userId);
        JPushInterface.setAliasAndTags(MyApplication.getInstance().getApplicationContext(), userId, tags, new TagAliasCallback() {
            @Override
            public void gotResult(int arg0, String arg1, Set<String> arg2) {
                // TODO Auto-generated method stub
                if (arg0 == 0) {
                    System.out.print("设置标签成功");
                }
            }
        });
    }

    public String getUserId(Context context) {
        return userId;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance=this;

        SDKInitializer.initialize(getApplicationContext());
        initImageLoader(getApplicationContext());

        CrashHandler crashHandler = CrashHandler.getInstance();
        // 注册crashHandler
        crashHandler.init(getApplicationContext());

        JPushInterface.setDebugMode(true); 	// 设置开启日志,发布时请关闭日志
        JPushInterface.init(this);     		// 初始化 JPush

        Tools.settingHandler(this);

        if(SharedUtil.getConfigBoolean(this, Constant.ISFIRSTSTART,true)){
            SharedUtil.putConfigString(this, Constant.TOKEN, "-1");
            SharedUtil.putConfigBoolean(this, Constant.ISFIRSTSTART, false);
        }


        if (Constant.Config.DEVELOPER_MODE && Build.VERSION.SDK_INT >= Build.VERSION_CODES.GINGERBREAD) {
            StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder().detectAll().penaltyDialog().build());
            StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().detectAll().penaltyDeath().build());
        }

        if(SharedUtil.getInt(this, "newYingYongNum")==-1) {
            SharedUtil.putInt(this, "newYingYongNum", 0);
        }

        if(SharedUtil.getInt(this, "isGetMsgNotification")==-1){
            SharedUtil.putInt(this, "isGetMsgNotification", 1);
            SharedUtil.putInt(this, "isShowNotification", 1);
            SharedUtil.putInt(this, "isNotificationSound", 1);
            SharedUtil.putInt(this, "isNotificationVibrate", 1);
            SharedUtil.putInt(this, "isNotiToggle", 1);
        }

    }




    public static void initImageLoader(Context context) {
        // This configuration tuning is custom. You can tune every option, you may tune some of them,
        // or you can create default configuration by
        //  ImageLoaderConfiguration.createDefault(this);
        // method.
        ImageLoaderConfiguration.Builder config = new ImageLoaderConfiguration.Builder(context);
        config.threadPriority(Thread.NORM_PRIORITY - 2);
        config.denyCacheImageMultipleSizesInMemory();
        config.diskCacheFileNameGenerator(new Md5FileNameGenerator());
        config.diskCacheSize(50 * 1024 * 1024); // 50 MiB
        config.tasksProcessingOrder(QueueProcessingType.LIFO);
        config.writeDebugLogs(); // Remove for release app

        // Initialize ImageLoader with configuration.
        ImageLoader.getInstance().init(config.build());
    }


    @Override
    public void onTerminate() {
        super.onTerminate();
        ActiveAndroid.dispose();
    }
}
