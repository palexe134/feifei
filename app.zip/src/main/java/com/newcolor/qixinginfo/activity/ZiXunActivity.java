package com.newcolor.qixinginfo.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.adapter.MsgContactAdapter;
import com.newcolor.qixinginfo.adapter.ZiXunAdapter;
import com.newcolor.qixinginfo.global.Config;
import com.newcolor.qixinginfo.global.MyApplication;
import com.newcolor.qixinginfo.http.AsyncHttpResponseHandler;
import com.newcolor.qixinginfo.http.RequestParams;
import com.newcolor.qixinginfo.model.ZiXunVO;
import com.newcolor.qixinginfo.ui.pullrefresh.PullToRefreshBase;
import com.newcolor.qixinginfo.ui.pullrefresh.PullToRefreshListView;
import com.newcolor.qixinginfo.util.DateUtils;
import com.newcolor.qixinginfo.util.HttpUtil;

import java.util.ArrayList;

/**
 * 资讯界面
 *
 * Created by Administrator on 2015/10/26.
 */
public class ZiXunActivity extends Activity implements View.OnClickListener, AdapterView.OnItemClickListener, MsgContactAdapter.Callback {
    private TextView tv;
    private FrameLayout title;
    private MyApplication application;

    private ListView mListView;
    private PullToRefreshListView mPullListView;
    private ZiXunAdapter ziXUnAdapter;
    private ArrayList<ZiXunVO> ziXunVOs;
    private int mCurIndex = 0;
    private static final int mLoadDataCount = 20;
    private ImageButton backBtn;
    private boolean isChange=false;
    private static final int[] ziXunViewIdArr={R.id.title_TV, R.id.time_TV};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        application = (MyApplication)this.getApplication();
        setContentView(R.layout.activity_zi_xun_list);

        title=(FrameLayout) this.findViewById(R.id.title);

        tv = (TextView) title.findViewById(R.id.titleTv);
        tv.setText("精彩资讯");
        backBtn = (ImageButton) title.findViewById(R.id.backBtn);
        backBtn.setOnClickListener(this);

        //定义下拉刷新
        mPullListView=(PullToRefreshListView) this.findViewById(R.id.ziXunPullListView);
        mPullListView.setPullLoadEnabled(false);
        mPullListView.setScrollLoadEnabled(true);

        ziXunVOs = new ArrayList<ZiXunVO>();

        ziXUnAdapter= new ZiXunAdapter(this,ziXunVOs, R.layout.item_list_zi_xun,ziXunViewIdArr);
        mListView = mPullListView.getRefreshableView();
        mListView.setAdapter(ziXUnAdapter);
        mListView.setOnItemClickListener(this);

        mPullListView.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener<ListView>() {
            @Override
            public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {
                initData();
            }

            @Override
            public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {
                initData();
            }
        });
        setLastUpdateTime();
    }

    @Override
    public void onResume() {
        super.onResume();
        this.flushData(true);
    }

    public void flushData(boolean isChange){
        this.isChange=isChange;
        mCurIndex=0;
        mPullListView.doPullRefreshing(true, 500);
    }

    /**
     * 初始化数据
     */
    private void initData(){
        RequestParams params=new RequestParams();
        params.put("curSize",String.valueOf(mCurIndex));
        params.put("count",String.valueOf(mLoadDataCount));
        HttpUtil.get(Config.getHomePageZiXunList, params, new AsyncHttpResponseHandler() {
            Boolean isHasMore = false;

            @Override
            public void onFailure(Throwable error, String content) {
                super.onFailure(error, content);
            }

            @Override
            public void onSuccess(String content) {
                super.onSuccess(content);
                ArrayList<ZiXunVO> arrayList = (ArrayList<ZiXunVO>) JSON.parseArray(content,ZiXunVO.class);

                if (isChange) {
                    ziXunVOs.clear();
                    isChange = false;
                }

                if (arrayList != null) {
                    ziXunVOs.addAll(arrayList);
                    mCurIndex++;
                    if (arrayList.size() < mLoadDataCount) {
                        isHasMore = false;
                    } else {
                        isHasMore = true;
                    }
                }

                ziXUnAdapter.notifyDataSetChanged();
                mPullListView.onPullDownRefreshComplete();
                mPullListView.onPullUpRefreshComplete();
                mPullListView.setHasMoreData(isHasMore);
                setLastUpdateTime();
            }
        });
    }

    private void setLastUpdateTime() {
        String text = DateUtils.formatSimpleDateTime(System.currentTimeMillis());
        mPullListView.setLastUpdatedLabel(text);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.backBtn:
                this.finish();
                break;
        }
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        ListView listView= (ListView) parent;
        ZiXunVO vo= (ZiXunVO) listView.getItemAtPosition(position);

        Intent intent =new Intent(this,ZiXunInfoActivity.class);
        intent.putExtra("ziXunVo",vo);
        this.startActivity(intent);
    }

    @Override
    public void click(View v) {

    }
}
