package com.newcolor.qixinginfo.activity;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.adapter.PersonalInfoAdapter;
import com.newcolor.qixinginfo.dialog.ActionSheetDialog;
import com.newcolor.qixinginfo.global.Config;
import com.newcolor.qixinginfo.global.Constant;
import com.newcolor.qixinginfo.global.MyApplication;
import com.newcolor.qixinginfo.http.AsyncHttpResponseHandler;
import com.newcolor.qixinginfo.http.RequestParams;
import com.newcolor.qixinginfo.model.PersonalVO;
import com.newcolor.qixinginfo.model.UserVO;
import com.newcolor.qixinginfo.ui.picher.TimePickerDialog;
import com.newcolor.qixinginfo.upload.HttpMultipartPost;
import com.newcolor.qixinginfo.util.AdressUtil;
import com.newcolor.qixinginfo.util.DateUtils;
import com.newcolor.qixinginfo.util.DealUtil;
import com.newcolor.qixinginfo.util.HttpUtil;
import com.newcolor.qixinginfo.util.LogUtil;
import com.newcolor.qixinginfo.util.PhotoUtil;
import com.newcolor.qixinginfo.util.SharedUtil;
import com.newcolor.qixinginfo.util.ToastUtil;
import com.newcolor.qixinginfo.util.Tools;
import com.newcolor.qixinginfo.view.AddImageView;
import com.nostra13.universalimageloader.core.ImageLoader;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;

/**
 * 个人信息设置界面
 *
 * Created by Administrator on 2015/10/21.
 */
public class PersonalInfoActivity extends Activity implements AdapterView.OnItemClickListener, View.OnClickListener {
    private MyApplication application;
    private TextView tv,saveBtn;
    private FrameLayout msg_title;
    private ImageButton backBtn;

    private static final String[] titleArr1={"账号","Email","性别","昵称","生日","留言","地址"};
    private static final String[] titleArr2={"姓名","身份证号","传真","座机"};
    private static final String[] titleArr3={"公司名称","公司网站","公司简介","宣传图片"};

    private static final String[] hintArr1={"","填写email","选择性别","填写昵称","选择出生日期","填写留言","选择地址"};
    private static final String[] hintArr2={"填写姓名","填写身份证号","填写传真","填写座机"};
    private static final String[] hintArr3={"填写公司名称","填写公司网站","填写公司简介","添加宣传图片"};

    private int type;
    private ArrayList<LinearLayout> itemArr1;
    private ArrayList<LinearLayout> itemArr2;
    private ArrayList<LinearLayout> itemArr3;

    private ArrayList<TextView> valArr1;
    private ArrayList<TextView> allValArr;

    private ImageView head_IV;
    private ActionSheetDialog sexSD;
    private ActionSheetDialog headSD;
    private String[] sexData={"女","男"};
    private String[] photoData={"拍照","从相册选择"};

    //照相机拍照得到的图片
    private File mTempPhotoFile;
    private byte[] contact_icon;
    private Uri imageUri;
    private UserVO curUserVo;
    private AddImageView addImageView;
    private ArrayList<String> urlArr=new ArrayList<String>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editor_me);
        application = (MyApplication) this.getApplication();

        curUserVo=application.getCurUserVo();

        Intent intent=this.getIntent();
        if(intent!=null){
            type=intent.getIntExtra("type", 3);
        }

        msg_title=(FrameLayout) this.findViewById(R.id.msg_title);

        tv = (TextView) msg_title.findViewById(R.id.titleTv);
        tv.setText("个人信息");
        saveBtn=(TextView) msg_title.findViewById(R.id.add_TV);
        saveBtn.setText("保存");
        backBtn=(ImageButton) msg_title.findViewById(R.id.backBtn);
        saveBtn.setOnClickListener(this);
        backBtn.setOnClickListener(this);

        itemArr1=new ArrayList<LinearLayout>();
        for(int i=1;i<8;i++){
            try{
                Field field = R.id.class.getField("basicitem"+i);
                itemArr1.add((LinearLayout) findViewById((Integer) field.getInt(new R.id())));
            }catch(Exception e){
                e.printStackTrace();
            }
        }

        itemArr2=new ArrayList<LinearLayout>();
        for(int i=1;i<5;i++){
            try{
                Field field = R.id.class.getField("detailitem"+i);
                itemArr2.add((LinearLayout) findViewById((Integer) field.getInt(new R.id())));
            }catch(Exception e){
                e.printStackTrace();
            }
        }

        itemArr3=new ArrayList<LinearLayout>();
        for(int i=1;i<5;i++){
            try{
                Field field = R.id.class.getField("companyitem"+i);
                itemArr3.add((LinearLayout) findViewById((Integer) field.getInt(new R.id())));
            }catch(Exception e){
                e.printStackTrace();
            }
        }

        head_IV= (ImageView) this.findViewById(R.id.head_IV);
        head_IV.setOnClickListener(this);
        addImageView= (AddImageView) this.findViewById(R.id.addImageView);

        this.initData();
        addImageView.initView(urlArr);
    }


    private void initData(){
        allValArr=new ArrayList<TextView>();
        valArr1=new ArrayList<TextView>();
        int i=0;
        for(LinearLayout item:itemArr1){
            TextView title_TV= (TextView) item.findViewById(R.id.title_TV);
            TextView val_TV= (TextView) item.findViewById(R.id.val_TV);
            ImageView icon_IV= (ImageView) item.findViewById(R.id.icon_IV);
            valArr1.add(val_TV);

            title_TV.setText(titleArr1[i] + "：");
            val_TV.setHint(hintArr1[i]);
            if(i==0){
                icon_IV.setVisibility(View.GONE);
            }
            if(i==2||i==4||i==6){
                item.setOnClickListener(this);
            }
            allValArr.add(val_TV);
            i++;
        }

        i=0;
        for(LinearLayout item:itemArr2){
            TextView title_TV= (TextView) item.findViewById(R.id.title_TV);
            TextView val_TV= (TextView) item.findViewById(R.id.val_TV);
            ImageView icon_IV= (ImageView) item.findViewById(R.id.icon_IV);

            title_TV.setText(titleArr2[i]+"：");
            val_TV.setHint(hintArr2[i]);
            allValArr.add(val_TV);
            i++;
        }


        i=0;
        for(LinearLayout item:itemArr3){
            TextView title_TV= (TextView) item.findViewById(R.id.title_TV);
            TextView val_TV= (TextView) item.findViewById(R.id.val_TV);
            ImageView icon_IV= (ImageView) item.findViewById(R.id.icon_IV);

            title_TV.setText(titleArr3[i]+"：");
            val_TV.setHint(hintArr3[i]);
            if(i==3){
                item.setOnClickListener(this);
            }else{
                allValArr.add(val_TV);
            }
            i++;
        }

        String[] dataArr={curUserVo.getPhone(),curUserVo.getEmail(),curUserVo.getGender(),curUserVo.getName(),
                curUserVo.getBirthday(),curUserVo.getLeave_word(),curUserVo.getAddress(),curUserVo.getReal_name(),
                curUserVo.getLd_card(),curUserVo.getFax(),curUserVo.getLandline(),curUserVo.getCompony_name(),
                curUserVo.getCompony_web(),curUserVo.getCompony_cotent()};
        i=0;
        for(TextView val_TV:allValArr){
            val_TV.setText(dataArr[i]);
            i++;
        }

//        ImageLoader.getInstance().displayImage(curUserVo.getHeadImg(), head_IV,Constant.headOptions);
        Tools.loadImg(this, curUserVo.getHeadImg(), head_IV, Constant.getCircleHeadOptions(this), null, R.mipmap.defaulthead);
        urlArr.addAll(curUserVo.getComponyImgsArr());
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        ListView listView = (ListView)parent;
        PersonalVO vo = (PersonalVO) listView.getItemAtPosition(position);
        int ctrType = vo.getType();

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.basicitem3:
                sexSD=new ActionSheetDialog(this);
                sexSD.builder();
                sexSD.setCancelable(false);
                sexSD.setCanceledOnTouchOutside(false);
                for(int i=0;i<sexData.length;i++){
                    sexSD.addSheetItem(sexData[i], ActionSheetDialog.SheetItemColor.Blue, sexSheetItemClick);
                }
                sexSD.show();
                break;
            case R.id.basicitem5:
                this.showMonPicker("1989-2-9", "yyyy-MM-dd");
                break;
            case R.id.basicitem7:
                AdressUtil.getInstance(this).chooseAddress(new AdressUtil.Callback() {
                    @Override
                    public void onCom(String proviceName, String cityName, String areaName) {
                        valArr1.get(6).setText(proviceName + cityName + areaName);
                    }
                });
                break;
            case R.id.companyitem4:
                ToastUtil.showToast(this,"添加公司宣传图片");
                break;
            case R.id.add_TV:
                this.savePersonalInfo();
                break;

            case R.id.backBtn:
                this.finish();
                break;

            case R.id.head_IV:
                headSD=new ActionSheetDialog(PersonalInfoActivity.this);
                headSD.builder();
                headSD.setCancelable(false);
                headSD.setCanceledOnTouchOutside(false);
                for(int i=0;i<photoData.length;i++){
                    headSD.addSheetItem(photoData[i], ActionSheetDialog.SheetItemColor.Blue,photoSheetItemClick);
                }
                headSD.show();
                break;
        }
    }

    /*Phone:电话
    realName真实姓名
    name姓名
    gender性别
    email邮箱
    birthday生日
    address地址
    componyName公司名称
    componyWeb公司网站
    componyCotent公司简介
    leaveWord留言
    fax传真
    landline座机
    ldCard;//身份证*/
    private void savePersonalInfo(){
        curUserVo.setEmail(allValArr.get(1).getText().toString());
        curUserVo.setGender(allValArr.get(2).getText().toString());
        curUserVo.setName(allValArr.get(3).getText().toString());
        curUserVo.setBirthday(allValArr.get(4).getText().toString());
        curUserVo.setLeave_word(allValArr.get(5).getText().toString());
        curUserVo.setAddress(allValArr.get(6).getText().toString());
        curUserVo.setReal_name(allValArr.get(7).getText().toString());
        curUserVo.setLd_card(allValArr.get(8).getText().toString());
        curUserVo.setFax(allValArr.get(9).getText().toString());
        curUserVo.setLandline(allValArr.get(10).getText().toString());
        curUserVo.setCompony_name(allValArr.get(11).getText().toString());
        curUserVo.setCompony_web(allValArr.get(12).getText().toString());
        curUserVo.setCompony_cotent(allValArr.get(13).getText().toString());
        String imgStr="";
        int i=0;
        for (String url:urlArr){
            if(url==AddImageView.defaultUrl){
                continue;
            }
            if(i<urlArr.size()-1) {
                imgStr += url + ",";
            }else{
                imgStr+=url;
            }
            i++;
        }
        curUserVo.setCompanyImgs(imgStr);

        DealUtil.savePersonalInfo(this,curUserVo,this.application.getUserId(this));
    }


    ActionSheetDialog.OnSheetItemClickListener sexSheetItemClick=new ActionSheetDialog.OnSheetItemClickListener() {
        @Override
        public void onClick(int which) {
            curUserVo.setGender(sexData[which-1]);
            valArr1.get(2).setText(sexData[which-1]);
        }
    };


    ActionSheetDialog.OnSheetItemClickListener photoSheetItemClick=new ActionSheetDialog.OnSheetItemClickListener() {
        @Override
        public void onClick(int which) {
            if(which==1){
                imageUri=PhotoUtil.getTempUri();
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);//action is capture
                intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
                startActivityForResult(intent, ReleaseGongQiuActivity.TAKE_CAMERA_PICTURE);//or TAKE_SMALL_PICTURE
            }else{
//                imageUri=Uri.parse(PhotoUtil.IMAGE_FILE_LOCATION);//The Uri to store the big bitmap
                doPickPhotoFromGallery(ReleaseGongQiuActivity.TAKE_SMALL_PICTURE);        // 从图库中去选取图片
            }
        }
    };

    private void doPickPhotoFromGallery(int requestCode){
        Intent intent;
        switch (requestCode) {
            case ReleaseGongQiuActivity.TAKE_BIG_PICTURE:
                intent = PhotoUtil.cropBigImage(imageUri, 640, 480,4,3);
                startActivityForResult(intent, ReleaseGongQiuActivity.CROP_BIG_PICTURE);
                break;
            case ReleaseGongQiuActivity.TAKE_SMALL_PICTURE:
                intent = PhotoUtil.cropSmallImage(80, 80,1,1);
                startActivityForResult(intent, ReleaseGongQiuActivity.CROP_SMALL_PICTURE);
                break;
        }
    }



    /**
     * 调用了Camera和Gallery所以要判断他们各自的返回情况, 他们启动时用的是startActivityForResult
     * @param requestCode 确认返回的数据是从哪个Activity返回的
     * @param resultCode 由子Activity通过其setResult()方法返回
     * @param data 一个Intent对象，带有返回的数据
     */
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        addImageView.onActivityResult(requestCode, resultCode, data);

        if (resultCode != this.RESULT_OK)
            return;
        switch (requestCode) {
            case ReleaseGongQiuActivity.TAKE_CAMERA_PICTURE:
                Intent intent = PhotoUtil.cropImageUri(imageUri, 80, 80,1,1);
                startActivityForResult(intent, ReleaseGongQiuActivity.CROP_BIG_PICTURE);
                break;
            case ReleaseGongQiuActivity.CROP_BIG_PICTURE://from crop_big_picture
                LogUtil.d(this, "CROP_BIG_PICTURE: data = " + data);//it seems to be null
                if(imageUri != null){
                    Bitmap bitmap = PhotoUtil.decodeUriAsBitmap(imageUri,this);
                    setPhotoToView(bitmap);
                }
                break;
            case ReleaseGongQiuActivity.CROP_SMALL_PICTURE:
                if(data != null){
                    Bitmap bitmap = data.getParcelableExtra("data");
                    setPhotoToView(bitmap);
                }else{
                    LogUtil.d(this, "CROP_SMALL_PICTURE: data = " + data);
                }
                break;
            default:
                break;
        }
    }

    private HttpMultipartPost post;
    /**
     * 设置图片为联系人头像
     */
    private void setPhotoToView(Bitmap bitmap) {
        if(bitmap==null)return;
        contact_icon = PhotoUtil.getBitmapByte(this, bitmap);
        head_IV.setImageBitmap(bitmap);

        post = new HttpMultipartPost(this, contact_icon, PhotoUtil.getPhotoFileName(), new HttpMultipartPost.Callback() {
            @Override
            public void onCom(String url) {
                curUserVo.setHeadImg(url);
            }
        });
        post.execute();
    }

    public void showMonPicker(String datestr, final String style) {

        final Calendar localCalendar = Calendar.getInstance();
        datestr=datestr.isEmpty()?valArr1.get(4).getText().toString():datestr;
        localCalendar.setTime(DateUtils.strToDate(style, datestr));

        int day=localCalendar.get(Calendar.DATE);
        int month=localCalendar.get(Calendar.MONTH);


        new TimePickerDialog(this,new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year,int monthOfYear, int dayOfMonth) {
                localCalendar.set(Calendar.YEAR, year);
                localCalendar.set(Calendar.MONTH, monthOfYear);
                localCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                valArr1.get(4).setText(DateUtils.clanderTodatetime(localCalendar, style));

            }

        }, localCalendar.get(Calendar.YEAR), month,day,3).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        itemArr1=itemArr2=itemArr3=null;
        valArr1=allValArr=null;
    }
}
