package com.newcolor.qixinginfo.activity;

import android.app.Activity;
import android.app.Notification;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.adapter.SystemSettingAdapter;
import com.newcolor.qixinginfo.global.Config;
import com.newcolor.qixinginfo.global.MyApplication;
import com.newcolor.qixinginfo.http.AsyncHttpResponseHandler;
import com.newcolor.qixinginfo.http.RequestParams;
import com.newcolor.qixinginfo.manager.ScreenManager;
import com.newcolor.qixinginfo.model.ContactVO;
import com.newcolor.qixinginfo.model.SystemSettingVO;
import com.newcolor.qixinginfo.util.HttpUtil;
import com.newcolor.qixinginfo.util.SharedUtil;
import com.newcolor.qixinginfo.util.ToastUtil;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import cn.jpush.android.api.BasicPushNotificationBuilder;
import cn.jpush.android.api.JPushInterface;

/**
 * 系统设置界面
 *
 * Created by Administrator on 2015/10/17.
 */
public class SystemSettingActivity extends Activity implements View.OnClickListener
        ,AdapterView.OnItemClickListener,SystemSettingAdapter.Callback{
    private MyApplication application;
    private FrameLayout login_title;
    private TextView tv;
    private ImageButton backBtn;
    private ListView mListView;
    private SystemSettingAdapter mAdapter;
    private ArrayList<SystemSettingVO> mListItems;
    private BasicPushNotificationBuilder builder;
    private static final String[] titleArr={"接收新消息通知","通知显示消息详情","separator","声音","震动","separator","隐藏个人信息","勿扰模式"};
    private static final String[] descArr={"","若关闭，当收到微信消息时，通知提示将不显示发信人和内容摘要","","","",""
            ,"若关闭，在你发布的供求信息详情及浏览过的记录中，手机号码及其他个人相关资料将被隐藏","开启后，在设定的时间段内收到新消息时不会响铃或震动。"};
    private static int[] defVal;
//    private int isGetMsgNotification,isShowNotification,isNotificationSound,isNotificationVibrate;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.acitivity_system_setting);
        application = (MyApplication)getApplication();
        ScreenManager.getInstance().pushActivity(this);

        defVal= new int[]{SharedUtil.getInt(this, "isGetMsgNotification"),
                        SharedUtil.getInt(this, "isShowNotification"),
                        0,
                        SharedUtil.getInt(this, "isNotificationSound"),
                        SharedUtil.getInt(this, "isNotificationVibrate"),
                        0,
                        1,
                        SharedUtil.getInt(this, "isNotiToggle")};

        init();
    }



    private void init(){
        login_title=(FrameLayout) this.findViewById(R.id.setting_title);

        tv = (TextView) login_title.findViewById(R.id.titleTv);
        tv.setText("系统设置");
        backBtn= (ImageButton) login_title.findViewById(R.id.backBtn);
        backBtn.setOnClickListener(this);

        this.initData();
        this.initPushBuilder();

        mAdapter=new SystemSettingAdapter(this,mListItems,this);

        mListView= (ListView) this.findViewById(R.id.data_LV);
        mListView.setAdapter(mAdapter);

        mListView.setOnItemClickListener(this);
    }

    private void initPushBuilder(){
        builder = new BasicPushNotificationBuilder(SystemSettingActivity.this);
        builder.statusBarDrawable = R.mipmap.ic_launcher;
        if(SharedUtil.getInt(this, "isNotificationSound")==1){
            builder.notificationDefaults |= Notification.DEFAULT_SOUND;
        }else if(SharedUtil.getInt(this, "isNotificationVibrate")==1){
            builder.notificationDefaults |= Notification.DEFAULT_VIBRATE;
        }
        JPushInterface.setDefaultPushNotificationBuilder(builder);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.registerTxt:
                Intent intent= new Intent(this,RegisterActivity.class);
                intent.putExtra("type", RegisterActivity.RegisterType);
                startActivity(intent);
                break;
            case R.id.backBtn:
                this.finish();
                break;
        }
    }

    private void initData(){
        mListItems=new ArrayList<SystemSettingVO>();
        SystemSettingVO vo;
        for(int i=0;i<titleArr.length;i++){
            vo=new SystemSettingVO();
            vo.setPosition(i);
            vo.setName(titleArr[i]);
            vo.setDesc(descArr[i]);
            vo.setState(defVal[i]);
            mListItems.add(vo);
        }
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        ListView listView = (ListView) parent;
        SystemSettingVO vo = (SystemSettingVO) listView.getItemAtPosition(position);
        if(position==7){
            Intent intent=new Intent(this,NotiToggleActivity.class);
            intent.putExtra("vo",vo);
            startActivity(intent);
        }
    }


    @Override
    public void click(View v) {
        final SystemSettingVO vo = (SystemSettingVO) v.getTag();
        switch (v.getId()) {
            case R.id.ctrlBtn:
                vo.setState(vo.getState()==1?2:1);
                switch (vo.getPosition()) {
                    case 0:
                        if (vo.getState() == 1) {
                            JPushInterface.resumePush(getApplicationContext());
                        } else {
                            JPushInterface.stopPush(getApplicationContext());
                        }
                        SharedUtil.putInt(this, "isGetMsgNotification", vo.getState());
                        break;
                    case 1:
                        if (vo.getState() == 1) {
                            JPushInterface.setPushTime(this, null, 0, 23);
                        } else {
                            JPushInterface.clearAllNotifications(this);
                            JPushInterface.setPushTime(this, new HashSet<Integer>(), 0, 23);
                        }
                        SharedUtil.putInt(this, "isShowNotification", vo.getState());
                        break;
                    case 3:
                        SharedUtil.putInt(this, "isNotificationSound",vo.getState());
                        this.initPushBuilder();
                        break;
                    case 4:
                        SharedUtil.putInt(this, "isNotificationVibrate",vo.getState());
                        this.initPushBuilder();
                        break;
                }
                break;
        }
    }


    private void settingHandler(int type,int state){
        RequestParams params=new RequestParams();
        params.put("userId",application.getUserId(this));
        params.put("type",String.valueOf(type));
        HttpUtil.get(Config.SystemSetting,params,new AsyncHttpResponseHandler(){
            @Override
            public void onFailure(Throwable error, String content) {
                super.onFailure(error, content);
                ToastUtil.showToast(SystemSettingActivity.this,content);
            }

            @Override
            public void onSuccess(String content) {
                super.onSuccess(content);
            }
        });

    }



}
