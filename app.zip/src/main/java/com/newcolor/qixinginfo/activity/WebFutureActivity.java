package com.newcolor.qixinginfo.activity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.TextView;

import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.global.MyApplication;
import com.newcolor.qixinginfo.manager.ScreenManager;
import com.newcolor.qixinginfo.util.StrUtil;

/**
 * 网页版期货界面
 *
 * Created by Administrator on 2015/10/30.
 */
public class WebFutureActivity extends Activity implements View.OnClickListener {
    private MyApplication application;
    private FrameLayout about_title;
    private TextView tv;
    private WebView contentTV;
    private ImageButton backBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_future);
        application = (MyApplication)getApplication();
        ScreenManager.getInstance().pushActivity(this);

        about_title=(FrameLayout) this.findViewById(R.id.about_title);

        tv = (TextView) about_title.findViewById(R.id.titleTv);
        tv.setText("期货行情");
        backBtn= (ImageButton) about_title.findViewById(R.id.backBtn);
        backBtn.setOnClickListener(this);

        contentTV= (WebView) this.findViewById(R.id.content_TV);
        contentTV.loadUrl("http://123.233.249.154:808/index.html");

    }


    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.backBtn:
                this.finish();
                break;
        }
    }


}
