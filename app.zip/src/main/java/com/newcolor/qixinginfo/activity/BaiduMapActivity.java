package com.newcolor.qixinginfo.activity;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.baidu.location.BDLocation;
import com.baidu.location.BDLocationListener;
import com.baidu.location.LocationClient;
import com.baidu.mapapi.SDKInitializer;
import com.baidu.mapapi.map.BaiduMap;
import com.baidu.mapapi.map.BitmapDescriptor;
import com.baidu.mapapi.map.BitmapDescriptorFactory;
import com.baidu.mapapi.map.InfoWindow;
import com.baidu.mapapi.map.MapStatusUpdate;
import com.baidu.mapapi.map.MapStatusUpdateFactory;
import com.baidu.mapapi.map.MapView;
import com.baidu.mapapi.map.Marker;
import com.baidu.mapapi.map.MarkerOptions;
import com.baidu.mapapi.map.MyLocationConfiguration;
import com.baidu.mapapi.map.MyLocationData;
import com.baidu.mapapi.model.LatLng;
import com.baidu.mapapi.search.core.SearchResult;
import com.baidu.mapapi.search.geocode.GeoCodeResult;
import com.baidu.mapapi.search.geocode.GeoCoder;
import com.baidu.mapapi.search.geocode.OnGetGeoCoderResultListener;
import com.baidu.mapapi.search.geocode.ReverseGeoCodeOption;
import com.baidu.mapapi.search.geocode.ReverseGeoCodeResult;
import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.dialog.AlertDialog;
import com.newcolor.qixinginfo.global.MyApplication;
import com.newcolor.qixinginfo.manager.ScreenManager;
import com.newcolor.qixinginfo.model.BaiDuMapGeoVO;
import com.newcolor.qixinginfo.model.BaiDuMapGongQiuVO;
import com.newcolor.qixinginfo.model.BaiDuMapMajorVO;
import com.newcolor.qixinginfo.model.BaiduMapVo;
import com.newcolor.qixinginfo.ui.editortxt.SearchEditText;
import com.newcolor.qixinginfo.util.AnimationUtil;
import com.newcolor.qixinginfo.util.BaiduMapUtil;
import com.newcolor.qixinginfo.util.LogUtil;
import com.newcolor.qixinginfo.util.SharedUtil;
import com.newcolor.qixinginfo.util.ToastUtil;
import com.newcolor.qixinginfo.util.Tools;
import com.newcolor.qixinginfo.view.BaiduMapAlertView;
import com.newcolor.qixinginfo.view.BaiduMapGeoDataView;

import java.util.ArrayList;

/**
 * 百度地图界面
 *
 * Created by Administrator on 2016/1/16.
 */
public class BaiduMapActivity extends Activity implements View.OnClickListener,OnGetGeoCoderResultListener, BaiduMap.OnMarkerClickListener {
    private MyApplication application;
    private FrameLayout title;
    private TextView tv;
    private ImageButton backBtn;
    private LinearLayout info_RL;

    private BaiduMapVo mapVo;
    private BaiDuMapGeoVO curVo;
    GeoCoder mSearch = null; // 搜索模块

    private Button searchBtn;
    private SearchEditText search_contact;
    private int type;//1:正常打开 2:周边搜索
    private BaiduMapGeoDataView baiduGeoDataView;

    private ArrayList<BaiDuMapGeoVO> mMapGongQiuArr;
    private ArrayList<Marker> markerArr;

    private LinearLayout openList_LL;
    private boolean isOpen=true;
    private ImageView ctr1_IV;

    private InfoWindow mInfoWindow;
    MapView mMapView = null;
    public BaiduMap baiduMap=null;
    public LocationClient locationClient=null;
    BitmapDescriptor mCurrentMarker=null;
    boolean isFirstLoc=true;
    public BDLocationListener myListener=new BDLocationListener() {
        @Override
        public void onReceiveLocation(final BDLocation location) {
            if (location == null || mMapView == null) {
                return;
            }

            String address="";
            if (location.getLocType() == BDLocation.TypeGpsLocation){// GPS定位结果
                address=location.getAddrStr();
                ToastUtil.showToast(BaiduMapActivity.this,"gps定位成功");
            } else if (location.getLocType() == BDLocation.TypeNetWorkLocation){// 网络定位结果
                address=location.getAddrStr();
                ToastUtil.showToast(BaiduMapActivity.this,"网络定位成功");
            } else if (location.getLocType() == BDLocation.TypeOffLineLocation) {// 离线定位结果
                ToastUtil.showToast(BaiduMapActivity.this,"离线定位成功，离线定位结果也是有效的");
            } else if (location.getLocType() == BDLocation.TypeServerError) {
                ToastUtil.showToast(BaiduMapActivity.this, "服务端网络定位失败，可以反馈IMEI号和大体定位时间到loc-bugs@baidu.com，会有人追查原因");
            } else if (location.getLocType() == BDLocation.TypeNetWorkException) {
                ToastUtil.showToast(BaiduMapActivity.this,"网络不同导致定位失败，请检查网络是否通畅");
            } else if (location.getLocType() == BDLocation.TypeCriteriaException) {
                ToastUtil.showToast(BaiduMapActivity.this,"无法获取有效定位依据导致定位失败，一般是由于手机的原因，处于飞行模式下一般会造成这种结果，可以试着重启手机");
            }


            MyLocationData locData = new MyLocationData.Builder()
                    .accuracy(location.getRadius())
                    .direction(0).latitude(location.getLatitude())
                    .longitude(location.getLongitude()).build();
            baiduMap.setMyLocationData(locData);

            if (isFirstLoc) {
                isFirstLoc = false;
                BaiduMapVo myVo = new BaiduMapVo();
//                myVo.setCompanyName(mapVo.getCompanyName().isEmpty()?"废废网":mapVo.getCompanyName());
                myVo.setCompanyName("废废网");
                myVo.setCity(location.getCity());
                myVo.setAddrStr(address);
                myVo.setCoordinate(location.getLongitude() + "," + location.getLatitude());
                showInfoWindow(myVo, true);
            }


            InfoWindow.OnInfoWindowClickListener listener = new InfoWindow.OnInfoWindowClickListener() {
                public void onInfoWindowClick() {
                    LatLng llNew = new LatLng(location.getLatitude(),
                            location.getLongitude());
                }
            };
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //在些处添加
        SDKInitializer.initialize(this.getApplication());

        setContentView(R.layout.activity_baidu_map);

        application = (MyApplication)getApplication();
        ScreenManager.getInstance().pushActivity(this);

        mMapGongQiuArr=new ArrayList<BaiDuMapGeoVO>();

        title=(FrameLayout) this.findViewById(R.id.about_title);

        tv = (TextView) title.findViewById(R.id.titleTv);
        tv.setText("商家地址");
        backBtn= (ImageButton) title.findViewById(R.id.backBtn);
        backBtn.setOnClickListener(this);

        info_RL=(LinearLayout) this.findViewById(R.id.info_RL);
        searchBtn=(Button) this.findViewById(R.id.searchBtn);
        search_contact=(SearchEditText) this.findViewById(R.id.search_contact);

        baiduGeoDataView=(BaiduMapGeoDataView) this.findViewById(R.id.baiduGeoDataView);
        info_RL.setOnClickListener(this);
        searchBtn.setOnClickListener(this);

        //获取地图控件引用
        mMapView = (MapView) findViewById(R.id.bmapView);

        baiduMap=mMapView.getMap();
        baiduMap.setMyLocationEnabled(true);
        baiduMap.setOnMarkerClickListener(this);

        mCurrentMarker = BitmapDescriptorFactory.fromResource(R.mipmap.icon_geo);

        openList_LL= (LinearLayout) this.findViewById(R.id.openList_LL);
        openList_LL.setOnClickListener(this);
        ctr1_IV=(ImageView) this.findViewById(R.id.ctr1_IV);

        if(locationClient==null) {
            locationClient = new LocationClient(getApplicationContext());
            locationClient.registerLocationListener(myListener);
            locationClient.setLocOption(BaiduMapUtil.getDefaultLocationOption());   //设置定位参数
        }
        // baiduMap.setMapType(BaiduMap.MAP_TYPE_NORMAL); // 设置为一般地图

        // baiduMap.setMapType(BaiduMap.MAP_TYPE_SATELLITE); //设置为卫星地图
        // baiduMap.setTrafficEnabled(true); //开启交通图

        Intent intent=this.getIntent();
        if(intent!=null){

            mapVo=intent.getParcelableExtra("mapVo");
            if(mapVo==null){
                mapVo=new BaiduMapVo();
            }
            type=intent.getIntExtra("type",1);
            if(type==1||mapVo.getCoordinate()==null||mapVo.getCoordinate().isEmpty()) {
                baiduMap.setMyLocationConfigeration(new MyLocationConfiguration(
                        MyLocationConfiguration.LocationMode.NORMAL, true, mCurrentMarker));
                initMyLocation(mapVo);
//                locationClient.start(); // 开始定位
//                info_RL.setVisibility(View.GONE);
            }else{
                initMyLocation(mapVo);
//                info_RL.setVisibility(View.VISIBLE);
            }


//            if(mapVo.getCoordinate()==null||mapVo.getCoordinate().isEmpty()){
//                if(mapVo.getAddrStr()!=null&&!mapVo.getAddrStr().isEmpty()&&mapVo.getAddrStr().length()>10){
//                    // 初始化搜索模块，注册事件监听
//                    mSearch = GeoCoder.newInstance();
//                    mSearch.setOnGetGeoCodeResultListener(this);
//
//                    mSearch.geocode(new GeoCodeOption()
//                            .city("青岛市")
//                            .address("黄岛区"));
//                }else {
//                    locationClient.start(); // 开始定位
//                }
//            }else{
//                LatLng ll=mapVo.getLatLong();
//                if(ll!=null){
////                    // 初始化搜索模块，注册事件监听
////                    mSearch = GeoCoder.newInstance();
////                    mSearch.setOnGetGeoCodeResultListener(this);
////
////                    this.searchHandlerByGeo(ll);
//                    initMyLocation(mapVo);
//                }else{
//                    locationClient.start(); // 开始定位
//                    ToastUtil.showToast(this, "商家填写的地址不准确，废废已帮您定位到当前位置");
//                }
//            }
        }

        SharedUtil.putInt(this, "newYingYongNum", SharedUtil.getInt(this, "newYingYongNum") - 1);
        int count=SharedUtil.getInt(this, "newYingYongNum");
    }

    private void initMyLocation(BaiduMapVo vo)
    {
//        LatLng ll=vo.getLatLong();
//        baiduMap.setMyLocationEnabled(true);
//        MyLocationData locData = new MyLocationData.Builder()
//                .accuracy(100)// 此处设置开发者获取到的方向信息，顺时针0-360
//                .direction(0f)
//                .latitude(ll.latitude)
//                .longitude(ll.longitude).build();
//
//        //float m = mBaiduMap.getMinZoomLevel();//3.0 最大比例尺
//        baiduMap.setMyLocationData(locData);
//        baiduMap.setMyLocationEnabled(true);

//        MapStatusUpdate u = MapStatusUpdateFactory.newLatLngZoom(ll, 15);//设置缩放比例
//        baiduMap.animateMapStatus(u);
        locationClient.start(); // 开始定位

        if(type==1){
            BaiduMapUtil.getNearByRecycle(this,vo,new BaiduMapUtil.NearByMajorCallBack(){
                @Override
                public void onCom(ArrayList<BaiDuMapMajorVO> arrayList) {
                    addOverlay(arrayList);
                }
            },"","",0,50);
        }else {
            BaiduMapUtil.getNearbyGongQiu(this, vo, new BaiduMapUtil.NearByGongQiuCallBack() {
                @Override
                public void onCom(ArrayList<BaiDuMapGongQiuVO> arrayList) {
                    addOverlay(arrayList);
                }
            });
        }
        //MapStatusUpdate u = MapStatusUpdateFactory.newLatLng(ll,f);
//        this.showInfoWindow(vo);
    }

    private void addOverlay(ArrayList<? extends BaiDuMapGeoVO> arrayList) {
        mMapGongQiuArr.clear();
        mMapGongQiuArr.addAll(arrayList);
        markerArr=new ArrayList<Marker>();
        for (BaiDuMapGeoVO vo:arrayList) {
            MarkerOptions ooA = new MarkerOptions().position(vo.getLatLng()).icon(mCurrentMarker).zIndex(5)
                    .draggable(false);
            Marker mMarker = (Marker) (baiduMap.addOverlay(ooA));
            mMarker.setToTop();
            markerArr.add(mMarker);
        }

        baiduGeoDataView.updateData(mMapGongQiuArr, new BaiduMapGeoDataView.CallBack() {
            @Override
            public void onClickItem(BaiDuMapGeoVO vo,int position) {
                onMarkerClick(markerArr.get(position));
                BaiduMapVo vo1=new BaiduMapVo();
                vo1.setsId(vo.getsId());
                vo1.setCompanyName(vo.getTitle());
                vo1.setCoordinate(vo.getCoordinate());
                vo1.setAddrStr(vo.getAddress());
                showInfoWindow(vo1,true);
            }
        });

        if(markerArr.size()>0) {
            info_RL.setVisibility(View.VISIBLE);
            onMarkerClick(markerArr.get(0));
        }else{
            info_RL.setVisibility(View.GONE);
        }
    }


    private void searchHandlerByGeo(LatLng ptCenter){
        // 反Geo搜索
        mSearch.reverseGeoCode(new ReverseGeoCodeOption().location(ptCenter));
    }


    private void showInfoWindow(BaiduMapVo vo,boolean isShowWindow){
        LatLng ll=vo.getLatLong();

//        baiduMap.setMyLocationConfigeration(new MyLocationConfiguration(
//        MyLocationConfiguration.LocationMode.NORMAL, true, mCurrentMarker));
//        ToastUtil.showToast(this,"执行到这里了"+ll.toString());
//        float f = baiduMap.getMaxZoomLevel()-6;//19.0 最小比例尺
        float f=15;
        if(type==1){
            f=10;
        }else {
            f= BaiduMapUtil.getZoomlevel(vo.getLatLong(), mapVo.getLatLong());
        }
        MapStatusUpdate u = MapStatusUpdateFactory.newLatLngZoom(ll, f);//设置缩放比例
        baiduMap.animateMapStatus(u);

        if(isShowWindow) {
            final BaiduMapAlertView baiduAlertView = new BaiduMapAlertView(BaiduMapActivity.this);
            baiduAlertView.initData(vo);

            mInfoWindow = new InfoWindow(baiduAlertView, ll, -47);
            baiduMap.showInfoWindow(mInfoWindow);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.backBtn:
                this.finish();
                break;
            case R.id.searchBtn:
                baiduMap.clear();
                BaiduMapUtil.getNearbyGongQiu(this, mapVo, new BaiduMapUtil.NearByGongQiuCallBack() {
                    @Override
                    public void onCom(ArrayList<BaiDuMapGongQiuVO> arrayList) {
                        addOverlay(arrayList);
                    }
                }, search_contact.getText().toString(), "");
                break;
//            case R.id.info_RL:
//                Intent intent = new Intent(this, GongQiuInfoActivity.class);
//                intent.putExtra("sId", curVo.getsId());
//                intent.putExtra("type", curVo.getType());
//                startActivity(intent);
//                break;
            case R.id.phone_IV:
                new AlertDialog(this).builder().setTitle("联系商家")
                        .setMsg(curVo.getPhone()+"\n\n废废网竭诚为您服务")
                        .setPositiveButton("确定", new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                phoneHandler();
                            }
                        }).setNegativeButton("取消", new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                    }
                }).show();
                break;
            case R.id.openList_LL:
                if(isOpen) {
                    isOpen=false;
                    AnimationUtil.rotate(ctr1_IV,this,0,180,100,android.R.anim.linear_interpolator,0.5f,0.5f);
                    baiduGeoDataView.setVisibility(View.GONE);
                }else{
                    isOpen=true;
                    AnimationUtil.rotate(ctr1_IV,this,180,0,100,android.R.anim.linear_interpolator,0.5f,0.5f);
                    baiduGeoDataView.setVisibility(View.VISIBLE);
                }
                break;
        }
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();

        //退出时销毁定位
        locationClient.stop();
        baiduMap.setMyLocationEnabled(false);
        // TODO Auto-generated method stub
        super.onDestroy();
        //在activity执行onDestroy时执行mMapView.onDestroy()，实现地图生命周期管理
        mMapView.onDestroy();
        mMapView = null;
    }
    @Override
    protected void onResume() {
        super.onResume();
        //在activity执行onResume时执行mMapView. onResume ()，实现地图生命周期管理
        mMapView.onResume();
    }
    @Override
    protected void onPause() {
        super.onPause();
        //在activity执行onPause时执行mMapView. onPause ()，实现地图生命周期管理
        mMapView.onPause();
    }


    @Override
    public void onGetGeoCodeResult(GeoCodeResult result) {
        if (result == null || result.error != SearchResult.ERRORNO.NO_ERROR) {
            Toast.makeText(this, "抱歉，未能找到结果", Toast.LENGTH_LONG)
                    .show();
            return;
        }
        baiduMap.clear();
        LatLng ll=result.getLocation();
        mapVo.setCoordinate(ll.longitude + "," + ll.latitude);
        this.initMyLocation(mapVo);
    }

    @Override
    public void onGetReverseGeoCodeResult(ReverseGeoCodeResult result) {
        if (result == null || result.error != SearchResult.ERRORNO.NO_ERROR) {
            Toast.makeText(this, "抱歉，未能找到结果", Toast.LENGTH_LONG).show();
            return;
        }
        baiduMap.clear();

//        LatLng ll=result.getLocation();
            mapVo.setAddrStr(result.getAddress());
//        showInfoWindow(mapVo);
    }

    @Override
    public boolean onMarkerClick(Marker marker) {
        this.initMarkerIcon();
        marker.setIcon(BitmapDescriptorFactory.fromResource(R.mipmap.icon_geo_60));
        int index=markerArr.indexOf(marker);
        curVo=mMapGongQiuArr.get(index);
        return false;
    }

    private void initMarkerIcon(){
        for(Marker marker:markerArr){
            marker.setIcon(BitmapDescriptorFactory.fromResource(R.mipmap.icon_geo_40));
        }
    }


    private void phoneHandler(){
        Intent intent = new Intent(Intent.ACTION_CALL);
        Uri data = Uri.parse("tel:" + curVo.getPhone());
        intent.setData(data);
        startActivity(intent);
    }
}
