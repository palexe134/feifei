package com.newcolor.qixinginfo.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.adapter.ContactAdapter;
import com.newcolor.qixinginfo.global.Config;
import com.newcolor.qixinginfo.global.MyApplication;
import com.newcolor.qixinginfo.http.AsyncHttpResponseHandler;
import com.newcolor.qixinginfo.http.RequestParams;
import com.newcolor.qixinginfo.manager.ScreenManager;
import com.newcolor.qixinginfo.model.ContactVO;
import com.newcolor.qixinginfo.util.HttpUtil;
import com.newcolor.qixinginfo.util.LoginUtil;
import com.newcolor.qixinginfo.util.ToastUtil;

import java.util.ArrayList;

/**
 * 联系人列表界面
 *
 * Created by Administrator on 2015/10/17.
 */
public class ContactListActivity extends Activity implements View.OnClickListener,AdapterView.OnItemClickListener {
    private MyApplication application;
    private FrameLayout login_title;
    private TextView tv,addBtn;
    private ImageButton backBtn;

    private ListView mListView;
    private ContactAdapter mAdapter;
    private ArrayList<ContactVO> mListItems;
    private static final int[] viewIdArr={R.id.name_TV,R.id.phone_TV,R.id.address_TV,R.id.editor_IV};

    public static final int RELEASE_GONG_QIU_RESULT_CODE=1;

    //从哪里打开的
    private int type;
    public static final int RELEASE_OPEN=1;//发布供求界面打开
    public static final int ME_OPEN=2;//我的  联系方式中打开

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_contact_list);
        application = (MyApplication)getApplication();
        ScreenManager.getInstance().pushActivity(this);

        init();
    }



    private void init(){
        login_title=(FrameLayout) this.findViewById(R.id.contact_list_title);

        tv = (TextView) login_title.findViewById(R.id.titleTv);
        tv.setText("联系人列表");
        backBtn= (ImageButton) login_title.findViewById(R.id.backBtn);
        addBtn=(TextView) login_title.findViewById(R.id.add_TV);

        backBtn.setOnClickListener(this);
        addBtn.setOnClickListener(this);

        Intent intent=this.getIntent();
        if(intent!=null){
            type=intent.getIntExtra("type",ME_OPEN);
        }

        mListItems=new ArrayList<ContactVO>();

        mAdapter=new ContactAdapter(this,mListItems,R.layout.item_list_contact,viewIdArr,type);

        mListView= (ListView) this.findViewById(R.id.data_LV);
        mListView.setAdapter(mAdapter);

        mListView.setOnItemClickListener(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        this.updateData();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.registerTxt:
                Intent intent= new Intent(this,RegisterActivity.class);
                intent.putExtra("type", RegisterActivity.RegisterType);
                startActivity(intent);
                break;
            case R.id.backBtn:
                this.finish();
                break;

            case R.id.add_TV:
                if(application.getUserId(this).equals("-1")){
                    LoginUtil.gotoLogin(this);
                    return;
                }
                intent=new Intent(this,AddContactActivity.class);
                startActivity(intent);
                break;


        }
    }

    private void updateData(){
        RequestParams params=new RequestParams();
        params.put("userId",application.getUserId(this));
        HttpUtil.get(Config.GetContactList,params,new AsyncHttpResponseHandler(){
            @Override
            public void onFailure(Throwable error, String content) {
                super.onFailure(error, content);
                ToastUtil.showToast(ContactListActivity.this,content);
            }

            @Override
            public void onSuccess(String content) {
                super.onSuccess(content);
                if(!content.isEmpty()) {
                    mListItems.clear();
                    ArrayList<ContactVO> arrayList= (ArrayList<ContactVO>) JSON.parseArray(content,ContactVO.class);
                    if(arrayList!=null) {
                        mListItems.addAll(arrayList);
                        mAdapter.notifyDataSetChanged();
                    }

//                    for(ContactVO vo:arrayList){
//                        vo=new ContactVO();
//                        vo.setIsDefault(1);
//                        vo.setName("asfdaf");
//                        vo.setPhone("15545625442");
//                        vo.setAddress("山东省临沂市罗庄区");
//                        mListItems.add(vo);
//                    }
                }
            }
        });

//        ContactVO vo;
//        for(int i=0;i<5;i++){
//            vo=new ContactVO();
//            vo.setIsDefault(1);
//            vo.setName("asfdaf");
//            vo.setPhone("15545625442");
//            vo.setAddress("山东省临沂市罗庄区");
//            mListItems.add(vo);
//        }
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        ListView listView = (ListView) parent;
        ContactVO vo = (ContactVO) listView.getItemAtPosition(position);
        Intent intent;
        if(type==RELEASE_OPEN && vo.getAddress().length()>6) {
            intent = new Intent();
            intent.putExtra("contactVo", vo);
            setResult(RELEASE_GONG_QIU_RESULT_CODE, intent);
            this.finish();
        }else{
            intent=new Intent(this,AddContactActivity.class);
            intent.putExtra("contactVo",vo);
            startActivity(intent);
        }
    }

}
