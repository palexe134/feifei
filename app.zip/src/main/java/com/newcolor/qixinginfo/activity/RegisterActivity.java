package com.newcolor.qixinginfo.activity;

import android.app.Activity;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.dialog.ActionSheetDialog;
import com.newcolor.qixinginfo.global.Config;
import com.newcolor.qixinginfo.global.Constant;
import com.newcolor.qixinginfo.global.MyApplication;
import com.newcolor.qixinginfo.http.AsyncHttpResponseHandler;
import com.newcolor.qixinginfo.http.RequestParams;
import com.newcolor.qixinginfo.manager.ScreenManager;
import com.newcolor.qixinginfo.receiver.SMSBroadcastReceiver;
import com.newcolor.qixinginfo.util.HttpUtil;
import com.newcolor.qixinginfo.util.IntentUtil;
import com.newcolor.qixinginfo.util.SharedUtil;
import com.newcolor.qixinginfo.util.TimeCountUtil;
import com.newcolor.qixinginfo.util.ToastUtil;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * 注册界面
 *
 * Created by Administrator on 2015/10/9.
 */
public class RegisterActivity extends Activity implements View.OnClickListener,ActionSheetDialog.OnSheetItemClickListener {
    private MyApplication application;

    private EditText et_account,et_auth_code,et_password;
    private FrameLayout login_title;
    private TextView tv,userType_TV,xie_yi_TV;
    private Button loginBtn = null,registerBtn=null,getAuthCodeBtn;
    private ImageButton backBtn;
    private RelativeLayout userType_RL;
    private String userType;
    private int type;
    private ActionSheetDialog userTypeSheet;
    private String[] userTypeArr={"家庭和单位","回收人员","回收站","加工厂"};

    public static final int FindPasswordType=1;
    public static final int RegisterType=2;

    private SMSBroadcastReceiver mSMSBroadcastReceiver;
    private static final String ACTION = "android.provider.Telephony.SMS_RECEIVED";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_register);
        application = (MyApplication)getApplication();
        ScreenManager.getInstance().pushActivity(this);

        Intent intent=this.getIntent();
        if(intent!=null){
            type=intent.getIntExtra("type",2);
        }

        init();
    }

    @Override
    protected void onStart() {
        super.onStart();
        //生成广播处理
        mSMSBroadcastReceiver = new SMSBroadcastReceiver();

        //实例化过滤器并设置要过滤的广播
        IntentFilter intentFilter = new IntentFilter(ACTION);
        intentFilter.setPriority(Integer.MAX_VALUE);
        //注册广播
        this.registerReceiver(mSMSBroadcastReceiver, intentFilter);

        mSMSBroadcastReceiver.setOnReceivedMessageListener(new SMSBroadcastReceiver.MessageListener() {
            @Override
            public void onReceived(String message) {

                et_auth_code.setText(message);

            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        //注销短信监听广播
        this.unregisterReceiver(mSMSBroadcastReceiver);
    }



    private void init(){
        login_title=(FrameLayout) this.findViewById(R.id.login_title);

        tv = (TextView) login_title.findViewById(R.id.titleTv);
        backBtn= (ImageButton) login_title.findViewById(R.id.backBtn);
        userType_RL= (RelativeLayout) this.findViewById(R.id.userType_RL);

        registerBtn= (Button) this.findViewById(R.id.registerBtn);
        getAuthCodeBtn= (Button) this.findViewById(R.id.getAuthCodeBtn);
        et_account= (EditText) this.findViewById(R.id.et_account);
        et_password= (EditText) this.findViewById(R.id.et_password);
        et_auth_code= (EditText) this.findViewById(R.id.et_auth_code);
        userType_TV= (TextView) this.findViewById(R.id.userType_TV);
        xie_yi_TV= (TextView) this.findViewById(R.id.xie_yi_TV);
        xie_yi_TV.setText(Html.fromHtml("我已阅读并同意<font color='#ff0000'>《废废服务协议》</font>"));

        if(type==RegisterType) {
            tv.setText(R.string.register_txt);
            registerBtn.setText(R.string.register_btn_txt);
            userType_RL.setVisibility(View.VISIBLE);
        }else{
            tv.setText(R.string.find_password_txt);
            registerBtn.setText(R.string.submit_txt);
            userType_RL.setVisibility(View.GONE);
        }

        registerBtn.setOnClickListener(this);
        backBtn.setOnClickListener(this);
        userType_RL.setOnClickListener(this);
        getAuthCodeBtn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.registerBtn:
                this.loginHandler();
                break;
            case R.id.backBtn:
                this.finish();
                break;
            case R.id.getAuthCodeBtn:
                this.getAuthCodeHandler();
                break;
            case R.id.userType_RL:
                this.initUserTypeSheet();
                break;
        }
    }

    private void initUserTypeSheet(){
        userTypeSheet=new ActionSheetDialog(this);
        userTypeSheet.builder()
                .setTitle("请选择用户类型")
                .setCancelable(false)
                .setCanceledOnTouchOutside(false);
        for(int i=0;i<userTypeArr.length;i++){
            userTypeSheet.addSheetItem(userTypeArr[i], ActionSheetDialog.SheetItemColor.Blue,this);
        }
        userTypeSheet.show();

    }

    @Override
    public void onClick(int which) {
        userType=String.valueOf(which);
        userType_TV.setText(userTypeArr[which-1]);
    }

    private void getAuthCodeHandler(){
        if(et_account.getText().equals("")){
            ToastUtil.showToast(this,"请先填写注册手机号");
            return;
        }

        TimeCountUtil timeCountUtil = new TimeCountUtil(this, 60000, 1000, getAuthCodeBtn);
        timeCountUtil.start();

        RequestParams params=new RequestParams();
        params.put("phoneNum", et_account.getText().toString());
        HttpUtil.get(Config.getAuthCode, params, new AsyncHttpResponseHandler() {
            @Override
            public void onFailure(Throwable error, String content) {
                super.onFailure(error, content);
            }

            @Override
            public void onSuccess(String content) {
                super.onSuccess(content);

                JSONObject jsonObject= null;
                try {
                    jsonObject = new JSONObject(content);
                    byte isSuc= Byte.parseByte(jsonObject.getString("isSuc"));
                    if(isSuc==0){
                        String msg=jsonObject.getString("msg");
                        ToastUtil.showToast(RegisterActivity.this,msg);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    private void loginHandler(){
        if(et_account.getText().equals("")){
            ToastUtil.showToast(this,"账号不能为空");
            return;
        }
        if(et_auth_code.getText().equals("")){
            ToastUtil.showToast(this,"验证码不能为空");
            return;
        }
        if(et_password.getText().equals("")){
            ToastUtil.showToast(this,"密码不能为空");
            return;
        }

        if(type==RegisterType){
            if(userType_TV.getText().equals("")){
                ToastUtil.showToast(this,"用户类型不能为空");
                return;
            }
        }

        RequestParams params=new RequestParams();

        if(type==FindPasswordType){
            params.put("phoneNum",et_account.getText().toString());
            params.put("authCode",et_auth_code.getText().toString());
            params.put("passWord",et_password.getText().toString());

            HttpUtil.post(Config.findPassWord,params,new AsyncHttpResponseHandler(){
                @Override
                public void onFailure(Throwable error, String content) {
                    super.onFailure(error, content);
                    ToastUtil.showToast(RegisterActivity.this,content);
                }

                @Override
                public void onSuccess(String content) {
                    super.onSuccess(content);

                    JSONObject jsonObject= null;
                    try {
                        jsonObject = new JSONObject(content);
                        byte isSuc= Byte.parseByte(jsonObject.getString("isSuc"));
                        if(isSuc==0){
                            String msg=jsonObject.getString("msg");
                            ToastUtil.showToast(RegisterActivity.this,msg);
                        }else{
                            application.setUserId(jsonObject.getString("userId"));
                            goMainActicity();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }
            });
        }else{
            params.put("phoneNum",et_account.getText().toString());
            params.put("authCode",et_auth_code.getText().toString());
            params.put("passWord",et_password.getText().toString());
            params.put("regiform","1");
            params.put("accountKind",userType);
            params.put("wlanMac",IntentUtil.getWlanMAC(this));


            HttpUtil.get(Config.userRegister,params,new AsyncHttpResponseHandler(){
                @Override
                public void onFailure(Throwable error, String content) {
                    super.onFailure(error, content);
                    ToastUtil.showToast(RegisterActivity.this, content);
                }

                @Override
                public void onSuccess(String content) {
                    super.onSuccess(content);

                    JSONObject jsonObject= null;
                    try {
                        jsonObject = new JSONObject(content);
                        byte isSuc= Byte.parseByte(jsonObject.getString("isSuc"));
                        if(isSuc==0){
                            String msg=jsonObject.getString("msg");
                            ToastUtil.showToast(RegisterActivity.this,msg);
                        }else{
                            application.setUserId(jsonObject.getString("userId"));
                            goMainActicity();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            });
        }
    }


    private void goMainActicity(){
        SharedUtil.putString(this,Constant.USERNAMECOOKIE,et_account.getText().toString());
        SharedUtil.putString(this,Constant.USERPASSWORDCOOKIE,et_password.getText().toString());
        this.finish();
        Intent intent=new Intent(this,MainActivity.class);
        intent.putExtra("index",1);
        startActivity(intent);
        ToastUtil.showToast(RegisterActivity.this, "登录成功");
    }

}
