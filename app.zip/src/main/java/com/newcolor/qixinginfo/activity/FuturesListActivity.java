package com.newcolor.qixinginfo.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.fragment.KChartsFragment;
import com.newcolor.qixinginfo.fragment.LMEQiHuoFragment;
import com.newcolor.qixinginfo.fragment.ShangHaiQiHuoFragment;
import com.newcolor.qixinginfo.fragment.TimesFragment;
import com.newcolor.qixinginfo.fragment.ZiXuanFragment;

import java.util.ArrayList;

/**
 * 期货列表界面
 *
 * Created by Administrator on 2016/1/15.
 */
public class FuturesListActivity extends FragmentActivity implements View.OnClickListener {
    private RadioGroup bottomRg;
    //    private FragmentManager fragmentManager;
//    private FragmentTransaction fragmentTransaction;
    private RadioButton rbOne, rbTwo,rbThree;
    private Boolean isExit = false;
    private int index=0,prevIndex=-1;
    private ArrayList<RadioButton> radioArr;
    private FrameLayout title;
    private ImageButton backBtn;
    private Button otherBtn;
    private TextView tv;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_futures_list);

        title= (FrameLayout) this.findViewById(R.id.title);
        backBtn= (ImageButton) title.findViewById(R.id.backBtn);
        otherBtn= (Button) title.findViewById(R.id.otherBtn);
        otherBtn.setText("预约开户");
        tv= (TextView) title.findViewById(R.id.titleTv);
        tv.setText("期货指数");
        backBtn.setOnClickListener(this);
        otherBtn.setOnClickListener(this);

        bottomRg = (RadioGroup) findViewById(R.id.bottomRg);
        rbOne = (RadioButton) findViewById(R.id.rbOne);
        rbTwo = (RadioButton) findViewById(R.id.rbTwo);
        rbThree = (RadioButton) findViewById(R.id.rbThree);

        radioArr=new ArrayList<RadioButton>();
        radioArr.add(rbOne);
        radioArr.add(rbTwo);
        radioArr.add(rbThree);

        this.init();

    }

    private void init(){
        setFragmentIndicator();
        this.openHandler(index);

    }


    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        index=intent.getIntExtra("index",0);
        this.openHandler(index);
    }

    private void openHandler(int index){
//        fragmentTransaction = fragmentManager.beginTransaction()
//                .hide(mFragments[0]).hide(mFragments[1])
//                .hide(mFragments[2]).hide(mFragments[3]);
//        fragmentTransaction.show(mFragments[index]).commitAllowingStateLoss();
        if(this.prevIndex==index){
            return;
        }

        this.prevIndex=index;
        Fragment df;
        if(index==0) {
            df = new ZiXuanFragment();
        }else if(index==1) {
            df = new LMEQiHuoFragment();
        }else{
            df = new ShangHaiQiHuoFragment();
        }
        //获取FragmentTransaction 实例
        FragmentTransaction ft = this.getSupportFragmentManager().beginTransaction();
        //使用DetailsFragment 的实例
        ft.replace(R.id.detials, df);
        ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
        ft.commitAllowingStateLoss();
        radioArr.get(index).setChecked(true);

    }


    private void setFragmentIndicator() {
        bottomRg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.rbOne:
                        openHandler(0);
                        break;
                    case R.id.rbTwo:
                        openHandler(1);
                        break;
                    case R.id.rbThree:
                        openHandler(2);
                        break;
                }

            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.backBtn:
                this.finish();
                break;
            case R.id.otherBtn:
                Intent intent=new Intent(this, OpinionActivity.class);
                intent.putExtra("type",1);
                startActivity(intent);
                break;
        }
    }
}
