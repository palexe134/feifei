package com.newcolor.qixinginfo.activity;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.adapter.PayInfoAdapter;
import com.newcolor.qixinginfo.dialog.AlertDialog;
import com.newcolor.qixinginfo.global.MyApplication;
import com.newcolor.qixinginfo.manager.ScreenManager;
import com.newcolor.qixinginfo.model.PayInfoVO;

import java.util.ArrayList;

/**
 * 支付方式界面
 *
 * Created by Administrator on 2015/10/30.
 */
public class PayInfoActivity extends Activity implements View.OnClickListener {
    private MyApplication application;
    private FrameLayout title;
    private TextView tv;
    private ImageButton backBtn,phoneBtn,phoneBtn1;
    private LinearLayout other_LL;

    private int type;
    private ListView mListView;
    private PayInfoAdapter mAdapter;
    private ArrayList<PayInfoVO> mListItems;
    private static final int[] viewIdArr={R.id.pay_IV,R.id.pay_type_TV,R.id.pay_account_TV,R.id.pay_owner_TV,R.id.copy_TV};
    private static final int[] iconIdArr={R.mipmap.zhi_fu_bao_bank_icon,R.mipmap.nong_ye_bank_icon,R.mipmap.xin_yong_she_bank_icon
            ,R.mipmap.gong_hang_bank_icon,R.mipmap.jian_she_bank_icon,R.mipmap.you_zheng_bank_icon};
    private static final String[] payTypeArr={"网转","柜台  ATM  网转  电转","柜台  ATM  网转  电转","柜台  ATM  网转  电转","柜台  ATM  网转  电转"
            ,"柜台  ATM  网转  电转"};
    private static final String[] payAccountArr={"sdlzd@126.com","6228461820009965215","9001051602880315","9558881610000117117","4367422298582438189"
            ,"604730008200299806"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pay_info);
        application = (MyApplication)getApplication();
        ScreenManager.getInstance().pushActivity(this);

        title=(FrameLayout) this.findViewById(R.id.title);

        tv = (TextView) title.findViewById(R.id.titleTv);
        backBtn= (ImageButton) title.findViewById(R.id.backBtn);
        backBtn.setOnClickListener(this);

        phoneBtn= (ImageButton) this.findViewById(R.id.phoneBtn);
        phoneBtn.setOnClickListener(this);

        phoneBtn1= (ImageButton) this.findViewById(R.id.phoneBtn1);
        phoneBtn1.setOnClickListener(this);

        Intent intent=this.getIntent();
        if(intent!=null){
            type=intent.getIntExtra("type",1);
        }

        mListItems=new ArrayList<PayInfoVO>();
        this.initData();
        mAdapter=new PayInfoAdapter(this,mListItems,R.layout.item_list_pay_info,viewIdArr);

        mListView= (ListView) this.findViewById(R.id.data_LV);
        mListView.setAdapter(mAdapter);


        other_LL= (LinearLayout) this.findViewById(R.id.other_LL);

        if(type==1){
            other_LL.setVisibility(View.GONE);
            tv.setText("支付方式");
        }else{
            other_LL.setVisibility(View.VISIBLE);
            tv.setText("订阅成功");
        }
    }

    private void initData(){
        PayInfoVO vo;
        for(int i=0;i<iconIdArr.length;i++){
            vo=new PayInfoVO();
            vo.setIcon(iconIdArr[i]);
            vo.setPayAccount(payAccountArr[i]);
            vo.setPayType(payTypeArr[i]);
            vo.setPayOwner("李柱道");
            mListItems.add(vo);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.backBtn:
                this.finish();
                break;
            case R.id.phoneBtn:
                toCall("13345086668");
                break;
            case R.id.phoneBtn1:
                toCall("05393188199");
                break;
        }
    }

    private void toCall(final String phoneNum){
        new AlertDialog(this).builder().setTitle("联系客服")
                .setMsg(phoneNum+"\n\n全天24小时竭诚为您服务")
                .setPositiveButton("确定", new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        phoneHandler(phoneNum);
                    }
                }).setNegativeButton("取消", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        }).show();
    }

    private void phoneHandler(String phoneNum){
        Intent intent = new Intent(Intent.ACTION_CALL);
        Uri data = Uri.parse("tel:" + phoneNum);
        intent.setData(data);
        startActivity(intent);
    }



}
