package com.newcolor.qixinginfo.activity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import com.activeandroid.ActiveAndroid;
import com.alibaba.fastjson.JSON;
import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.adapter.SubscribeAdapter;
import com.newcolor.qixinginfo.global.Config;
import com.newcolor.qixinginfo.global.MyApplication;
import com.newcolor.qixinginfo.http.AsyncHttpResponseHandler;
import com.newcolor.qixinginfo.http.RequestParams;
import com.newcolor.qixinginfo.manager.ScreenManager;
import com.newcolor.qixinginfo.model.Msg;
import com.newcolor.qixinginfo.ui.pullrefresh.PullToRefreshBase;
import com.newcolor.qixinginfo.ui.pullrefresh.PullToRefreshListView;
import com.newcolor.qixinginfo.util.DBUtil;
import com.newcolor.qixinginfo.util.DateUtils;
import com.newcolor.qixinginfo.util.HttpUtil;
import com.newcolor.qixinginfo.util.IntentUtil;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 订阅信息界面（弃用）
 *
 * Created by Administrator on 2015/10/10.
 */
public class SubscribeActivity extends Activity implements View.OnClickListener,AdapterView.OnItemClickListener {
    private MyApplication application;
    private ImageButton backBtn;
    private FrameLayout login_title;
    private TextView tv;
    private PullToRefreshListView scrollView;
    private ArrayList<Msg> mListItems;
    private SubscribeAdapter mAdapter;
    private ListView mListView;
    private boolean isChange=false;
    private int mCurIndex = 0;
    private static final int mLoadDataCount = 20;
    private static final int[] viewIdArr={R.id.tv_time,R.id.tv_content};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subscribe);
        application= (MyApplication) this.getApplication();
        ScreenManager.getInstance().pushActivity(this);

        login_title=(FrameLayout) this.findViewById(R.id.msg_title);

        tv = (TextView) login_title.findViewById(R.id.titleTv);
        backBtn= (ImageButton) login_title.findViewById(R.id.backBtn);

        scrollView= (PullToRefreshListView) this.findViewById(R.id.msgPullListView);

        mListItems = new ArrayList<Msg>();
        mAdapter = new SubscribeAdapter(this, mListItems, R.layout.item_list_subscribe, viewIdArr, new SubscribeAdapter.Callback() {
            @Override
            public void onSelectChange(View v) {

            }
        });
        mListView = scrollView.getRefreshableView();
        mListView.setAdapter(mAdapter);
        mListView.setOnItemClickListener(this);

        scrollView.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener<ListView>() {
            @Override
            public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {
                downHandler();
            }

            @Override
            public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {
                upHandler();
            }
        });
        setLastUpdateTime();

        tv.setText(R.string.msg_subscribe_txt);

        backBtn.setOnClickListener(this);
    }

    @Override
    public void onResume() {
        super.onResume();
        flushData(true);
    }



    public void flushData(boolean isChange){
        this.isChange=isChange;
        mCurIndex=0;
//        mListItems.clear();
        scrollView.doPullRefreshing(true, 500);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.backBtn:
                this.finish();
                break;
        }

    }

    private void upHandler(){

    }

    private void downHandler(){
        if(IntentUtil.isConnect(this)&& !application.getUserId(this).equals("-1")){
            this.getMessageList();
        }else{
            int ps=0;
            if (isChange) {
                mListItems.clear();
            }
            List<Msg> list = DBUtil.getMsgList(1,mCurIndex,mLoadDataCount);
            Collections.reverse(list);
            mListItems.addAll(0, list);
            ps=list.size();
            updateFlag();

            mCurIndex++;

            mAdapter.notifyDataSetChanged();
            scrollView.onPullDownRefreshComplete();
            scrollView.onPullUpRefreshComplete();
            scrollView.setHasMoreData(false);
            setLastUpdateTime();

            if(!isChange){
                ps--;
            }
            isChange=false;
            mListView.setSelection(ps);
        }

//        mListItems.clear();
//        Msg vo = null;
//
//        for (int i = 0; i < 10; i++) {
//            vo=new Msg();
//            vo.setFlag(i%2);
//            vo.setMTime("2015.10.5 下午5点");
//            vo.setContent("...");
//            mListItems.add(0,vo);
//        }
//
//        mAdapter.notifyDataSetChanged();
//        scrollView.onPullDownRefreshComplete();
//        scrollView.onPullUpRefreshComplete();
//        scrollView.setHasMoreData(false);
//        mListView.setSelection(mListView.getBottom());
//        setLastUpdateTime();
    }


    private void getMessageList(){
        RequestParams rParams=new RequestParams();
        rParams.put("userId", application.getUserId(this));
        rParams.put("curSize",String.valueOf(mCurIndex));
        rParams.put("count",String.valueOf(mLoadDataCount));

        HttpUtil.get(Config.GetSubscribeMsgList, rParams, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(String response) {
                super.onSuccess(response);
                boolean hasMoreData = true;

                if (!response.isEmpty()) {
                    ArrayList<Msg> nowMsgList = (ArrayList<Msg>) JSON.parseArray(response,Msg.class);
                    if(nowMsgList!=null) {
                        if (isChange) {
                            mListItems.clear();
                        }
                        mCurIndex ++;
                        if (nowMsgList.size() < mLoadDataCount) {
                            hasMoreData = false;
                        }

                        //新获得的数据添加进数组
                        mListItems.addAll(0,nowMsgList);
                        updateFlag();
                        updateDataBase(nowMsgList);
                    }
                } else {
                    hasMoreData = false;
                    if (isChange) {
                        mListItems.clear();
                    }
                }
                mAdapter.notifyDataSetChanged();
                scrollView.onPullDownRefreshComplete();
                scrollView.onPullUpRefreshComplete();
                scrollView.setHasMoreData(hasMoreData);
                setLastUpdateTime();

                if(isChange){
                    isChange=false;
                    mListView.setSelection(mListView.getBottom());
                }

            }
        });
    }

    private void updateFlag(){
        int i=0;
        for (Msg vo:mListItems) {
            vo.setFlag(i%2);
//            mListItems.add(0,vo);
            i++;
        }
    }

    private void setLastUpdateTime() {
        String text = DateUtils.formatSimpleDateTime(System.currentTimeMillis());
        scrollView.setLastUpdatedLabel(text);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

    }


    private void updateDataBase(ArrayList<Msg> arrayList){
        DBUtil.deletGongQiuByType(1);

        ActiveAndroid.beginTransaction();
        try {
            for (Msg vo:arrayList) {
                vo.save();
            }
            ActiveAndroid.setTransactionSuccessful();
        }
        finally {
            ActiveAndroid.endTransaction();
        }
    }
}
