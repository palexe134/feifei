package com.newcolor.qixinginfo.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.global.Config;
import com.newcolor.qixinginfo.global.MyApplication;
import com.newcolor.qixinginfo.http.AsyncHttpResponseHandler;
import com.newcolor.qixinginfo.http.RequestParams;
import com.newcolor.qixinginfo.manager.ScreenManager;
import com.newcolor.qixinginfo.model.ZiXunVO;
import com.newcolor.qixinginfo.util.DateUtils;
import com.newcolor.qixinginfo.util.HttpUtil;

/**
 * 资讯详情界面
 *
 * Created by Administrator on 2015/10/30.
 */
public class ZiXunInfoActivity extends Activity implements View.OnClickListener {
    private MyApplication application;
    private FrameLayout about_title;
    private TextView tv,title_TV,time_TV;
    private WebView contentTV;
    private ImageButton backBtn;
    private ZiXunVO curVo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_zi_xun_info);
        application = (MyApplication)getApplication();
        ScreenManager.getInstance().pushActivity(this);

        Intent intent=this.getIntent();
        if(intent!=null){
            curVo=intent.getParcelableExtra("ziXunVo");
        }

        about_title=(FrameLayout) this.findViewById(R.id.about_title);

        tv = (TextView) about_title.findViewById(R.id.titleTv);
        tv.setText("资讯详情");
        backBtn= (ImageButton) about_title.findViewById(R.id.backBtn);
        backBtn.setOnClickListener(this);

        contentTV= (WebView) this.findViewById(R.id.content_TV);
        title_TV= (TextView) this.findViewById(R.id.title_TV);
        time_TV= (TextView) this.findViewById(R.id.time_TV);
        this.initData();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.backBtn:
                this.finish();
                break;
        }
    }

    /**
     * 初始化数据
     */
    private void initData(){
        RequestParams params=new RequestParams();
        params.put("id",String.valueOf(curVo.getId()));
        HttpUtil.get(Config.getHomePageZiXunInfo, params, new AsyncHttpResponseHandler() {
            @Override
            public void onFailure(Throwable error, String content) {
                super.onFailure(error, content);
            }

            @Override
            public void onSuccess(String content) {
                super.onSuccess(content);
                ZiXunVO vo = JSON.parseObject(content, ZiXunVO.class);
                title_TV.setText(vo.getTitle());
                contentTV.loadData(vo.getContent(), "text/html; charset=UTF-8", null);
                time_TV.setText(DateUtils.formatYearDateTime(vo.getAddtime()*1000));
            }
        });
    }


}
