package com.newcolor.qixinginfo.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.baidu.location.BDLocation;
import com.baidu.location.BDLocationListener;
import com.baidu.location.LocationClient;
import com.baidu.mapapi.model.LatLng;
import com.baidu.mapapi.search.core.SearchResult;
import com.baidu.mapapi.search.geocode.GeoCodeOption;
import com.baidu.mapapi.search.geocode.GeoCodeResult;
import com.baidu.mapapi.search.geocode.GeoCoder;
import com.baidu.mapapi.search.geocode.OnGetGeoCoderResultListener;
import com.baidu.mapapi.search.geocode.ReverseGeoCodeResult;
import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.dialog.AlertDialog;
import com.newcolor.qixinginfo.global.Config;
import com.newcolor.qixinginfo.global.MyApplication;
import com.newcolor.qixinginfo.http.AsyncHttpResponseHandler;
import com.newcolor.qixinginfo.http.RequestParams;
import com.newcolor.qixinginfo.manager.ScreenManager;
import com.newcolor.qixinginfo.model.ContactVO;
import com.newcolor.qixinginfo.util.AdressUtil;
import com.newcolor.qixinginfo.util.BaiduMapUtil;
import com.newcolor.qixinginfo.util.HttpUtil;
import com.newcolor.qixinginfo.util.ToastUtil;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * 添加联系方式界面
 *
 * Created by Administrator on 2015/10/17.
 */
public class AddContactActivity extends Activity implements View.OnClickListener, OnGetGeoCoderResultListener {
    private MyApplication application;
    private FrameLayout contact_title;
    private TextView tv,address_TV,save_TV,delet_TV;
    private ImageButton backBtn;
    private RelativeLayout address_RL;
    private EditText name_ET,phone_ET,detailAddress_ET;
    private ContactVO contactVO;
    private Button defaultBtn;
    private ImageView positionBtn;
    /**
     * 当前省的名称
     */
    private String mCurrentProviceName="";
    /**
     * 当前市的名称
     */
    private String mCurrentCityName="";
    /**
     * 当前区的名称
     */
    private String mCurrentAreaName ="";

    private String mAddrStr="";

    private LocationClient locationClient;

    public BDLocationListener myListener=new BDLocationListener() {
        @Override
        public void onReceiveLocation(BDLocation location) {
            if(location==null){
                return;
            }

            LatLng ll=new LatLng(location.getLatitude(),
                    location.getLongitude());

            mCurrentProviceName = location.getProvince();
            mCurrentCityName = location.getCity();
            mCurrentAreaName = location.getDistrict();
            mAddrStr=location.getAddrStr();

            ToastUtil.showToast(AddContactActivity.this, "定位成功");
            if(contactVO!=null){
                contactVO.setCoordinate(location.getLongitude()+","+location.getLatitude());
            }

            address_TV.setText(location.getCountry()+location.getProvince()+location.getCity()
                        +location.getDistrict());
            detailAddress_ET.setText(location.getStreet());
        }
    };




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_add_contact);
        application = (MyApplication)getApplication();
        ScreenManager.getInstance().pushActivity(this);

        Intent intent=this.getIntent();
        if(intent!=null){
            contactVO=intent.getParcelableExtra("contactVo");
        }

        init();
        this.initData();
        if(contactVO==null){
            contactVO=new ContactVO();
        }
    }

    private void init() {
        contact_title = (FrameLayout) this.findViewById(R.id.contact_list_title);

        tv = (TextView) contact_title.findViewById(R.id.titleTv);
        tv.setText("添加联系方式");
        backBtn = (ImageButton) contact_title.findViewById(R.id.backBtn);

        address_RL= (RelativeLayout) this.findViewById(R.id.address_RL);
        address_TV= (TextView) this.findViewById(R.id.address_TV);
        save_TV= (TextView) this.findViewById(R.id.add_TV);
        delet_TV= (TextView) this.findViewById(R.id.delet_TV);
        name_ET= (EditText) this.findViewById(R.id.name_ET);
        phone_ET= (EditText) this.findViewById(R.id.phone_ET);
        detailAddress_ET= (EditText) this.findViewById(R.id.detailAddress_ET);
        defaultBtn= (Button) this.findViewById(R.id.defaultBtn);
        positionBtn= (ImageView) this.findViewById(R.id.positionBtn);
        save_TV.setText("保存");

        backBtn.setOnClickListener(this);
        address_RL.setOnClickListener(this);
        save_TV.setOnClickListener(this);
        defaultBtn.setOnClickListener(this);
        delet_TV.setOnClickListener(this);
        positionBtn.setOnClickListener(this);
    }

    private void initData(){
        if(contactVO!=null){
            name_ET.setText(contactVO.getName());
            phone_ET.setText(contactVO.getPhone());
            String address="";
            String[] addressArr=contactVO.getAddress().split(",");
            for (int i=0;i<addressArr.length-1;i++){
                address+=addressArr[i];
                if(i==0){
                    mCurrentProviceName=addressArr[i];
                }else if(i==1){
                    mCurrentCityName=addressArr[i];
                }else if(i==2){
                    mCurrentAreaName=addressArr[i];
                }
            }
            address_TV.setText(address);
            if(addressArr.length>0) {
                detailAddress_ET.setText(addressArr[addressArr.length - 1]);
            }
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.backBtn:
                this.finish();
                break;
            case R.id.address_RL:
                new AlertDialog(this).builder().setTitle("精确定位")
                        .setMsg("你可以通过精确定位获取到当前位置信息！")
                        .setPositiveButton("确定", new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                startPosition();
                            }
                        }).setNegativeButton("取消", new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        AdressUtil.getInstance(AddContactActivity.this).chooseAddress(new AdressUtil.Callback() {
                            @Override
                            public void onCom(String proviceName, String cityName, String areaName) {
                                mCurrentProviceName = proviceName;
                                mCurrentCityName = cityName;
                                mCurrentAreaName = areaName;
                                address_TV.setText(mCurrentProviceName + mCurrentCityName + mCurrentAreaName);
                            }
                        });
                    }
                }).show();


                break;
            case R.id.add_TV:
                this.addContactHandler(0);
                break;
            case R.id.defaultBtn:
                this.addContactHandler(1);
                break;
            case R.id.positionBtn:
                this.startPosition();
                break;
            case R.id.delet_TV:
                new AlertDialog(this).builder().setTitle("确认删除")
                        .setMsg("你确定要删除该联系方式吗？")
                        .setPositiveButton("确定", new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                deletContactHandler();
                            }
                        }).setNegativeButton("取消", new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                    }
                }).show();
                break;

        }
    }


    private void deletContactHandler(){
        if(contactVO.getId()==null||contactVO.getId().isEmpty()){
            ToastUtil.showToast(this, "联系方式中至少有一条默认联系方式");
            return;
        }
        RequestParams params=new RequestParams();
        params.put("userId",application.getUserId(this));
        params.put("contactId", contactVO.getId());
        HttpUtil.get(Config.DeletContactInfo, params, new AsyncHttpResponseHandler() {
            @Override
            public void onFailure(Throwable error, String content) {
                super.onFailure(error, content);
                ToastUtil.showToast(AddContactActivity.this, content);
            }

            @Override
            public void onSuccess(String content) {
                super.onSuccess(content);
                JSONObject jsonObject = null;
                try {
                    jsonObject = new JSONObject(content);
                    byte isSuc = Byte.parseByte(jsonObject.getString("isSuc"));
                    if (isSuc == 0) {
                        String msg = jsonObject.getString("msg");
                        ToastUtil.showToast(AddContactActivity.this, msg);
                    } else {
                        finish();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
    }


    private void addContactHandler(int isDefault){
        if(contactVO==null){
            contactVO=new ContactVO();
        }
        contactVO.setName(name_ET.getText().toString());
        contactVO.setPhone(phone_ET.getText().toString());
        contactVO.setAddress(mCurrentProviceName + "," + mCurrentCityName + "," + mCurrentAreaName + "," + detailAddress_ET.getText().toString());
        contactVO.setIsDefault(contactVO.isDefault() == 1 ? 1 : isDefault);
        if(mCurrentCityName==null||mCurrentCityName.isEmpty()||detailAddress_ET.getText().toString().isEmpty()){
            new AlertDialog(this).builder().setTitle("警告")
                    .setMsg("您的位置信息填写过于简陋，废废网无法帮您匹配客户信息，为了您的利益，建议您填写真实详细地址")
                    .setPositiveButton("帮我定位", new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            startPosition();
                        }
                    }).setNegativeButton("继续添加", new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            toSendAddContact();
                        }
                    }).show();
        }else if(contactVO.getCoordinate()==null||contactVO.getCoordinate().isEmpty()){
            // 初始化搜索模块，注册事件监听
            GeoCoder mSearch = GeoCoder.newInstance();
            mSearch.setOnGetGeoCodeResultListener(this);
            // Geo搜索
            mSearch.geocode(new GeoCodeOption().city(mCurrentCityName).address(detailAddress_ET.getText().toString()));
//            startPosition();
        }else{
            toSendAddContact();
        }
    }

    private void toSendAddContact(){
        if(contactVO.getName()==null||contactVO.getName().isEmpty()){
            ToastUtil.showToast(this,"联系人名称不能为空");
            return;
        }
        if(contactVO.getPhone()==null||contactVO.getPhone().isEmpty()){
            ToastUtil.showToast(this,"联系人电话不能为空");
            return;
        }
        if(contactVO.getAddress()==null||contactVO.getAddress().isEmpty()){
            ToastUtil.showToast(this,"联系人地址不能为空");
            return;
        }
        RequestParams params=new RequestParams();

        params.put("contactId", contactVO.getId());
        params.put("userId",application.getUserId(this));
        params.put("name",contactVO.getName());
        params.put("phone",contactVO.getPhone());
        params.put("address", contactVO.getAddress());
        params.put("coordinate", contactVO.getCoordinate());
        params.put("isDefault", String.valueOf(contactVO.isDefault()));
        HttpUtil.get(Config.addContactInfo, params, new AsyncHttpResponseHandler() {
            @Override
            public void onFailure(Throwable error, String content) {
                super.onFailure(error, content);
                ToastUtil.showToast(AddContactActivity.this, content);
            }

            @Override
            public void onSuccess(String content) {
                super.onSuccess(content);

                JSONObject jsonObject = null;
                try {
                    jsonObject = new JSONObject(content);
                    byte isSuc = Byte.parseByte(jsonObject.getString("isSuc"));
                    if (isSuc == 0) {
                        String msg = jsonObject.getString("msg");
                        ToastUtil.showToast(AddContactActivity.this, msg);
                    } else {
                        ToastUtil.showToast(AddContactActivity.this, "保存联系方式成功");
                        finish();
                    }
                    application.setUserId(jsonObject.getString("userId"));
                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        });
    }

    @Override
    public void onGetGeoCodeResult(GeoCodeResult result) {
        if (result == null || result.error != SearchResult.ERRORNO.NO_ERROR) {
            ToastUtil.showToast(this,"您填写的地址有误，无法帮您定位，废废网可以根据您填写的地址帮您匹配价值客户信息");
            return;
        }

        if(contactVO!=null){
            contactVO.setCoordinate(result.getLocation().longitude+","+result.getLocation().latitude);
        }

        this.toSendAddContact();
    }

    @Override
    public void onGetReverseGeoCodeResult(ReverseGeoCodeResult reverseGeoCodeResult) {

    }

    @Override
    protected void onPause() {
        super.onPause();
        AdressUtil.getInstance(this).destroy();
    }

    private void startPosition(){
        if(locationClient==null) {
            locationClient = new LocationClient(this.getApplicationContext());
            locationClient.registerLocationListener(myListener);
            locationClient.setLocOption(BaiduMapUtil.getDefaultLocationOption());   //设置定位参数
        }
        locationClient.start(); // 开始定位
    }

}
