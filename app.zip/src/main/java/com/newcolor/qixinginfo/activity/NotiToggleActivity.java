package com.newcolor.qixinginfo.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Switch;
import android.widget.TextView;

import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.dialog.TimePickerFragment;
import com.newcolor.qixinginfo.global.MyApplication;
import com.newcolor.qixinginfo.manager.ScreenManager;
import com.newcolor.qixinginfo.model.SystemSettingVO;
import com.newcolor.qixinginfo.util.DateUtils;
import com.newcolor.qixinginfo.util.SharedUtil;

import cn.jpush.android.api.JPushInterface;

/**
 * 系统设置界面，主要针对Jpush的功能开关设计
 *
 * Created by Administrator on 2015/10/30.
 */
public class NotiToggleActivity extends Activity implements View.OnClickListener {
    private MyApplication application;
    private FrameLayout title;
    private TextView tv,start_TV,end_TV,name_TV,desc_TV;
    private ImageButton backBtn;
    private LinearLayout set_LL;
    private RelativeLayout start_LL,end_LL,ctr_box;
    private Switch ctrBtn;
    private SystemSettingVO curVo;
    private int endHours=0;
    private int endminutes=0;
    private int startHours=0;
    private int startminutes=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_noti_toggle);
        application = (MyApplication)getApplication();
        ScreenManager.getInstance().pushActivity(this);

        Intent intent=this.getIntent();
        if(intent!=null){
            curVo=intent.getParcelableExtra("vo");
        }

        title=(FrameLayout) this.findViewById(R.id.about_title);

        tv = (TextView) title.findViewById(R.id.titleTv);
        tv.setText("勿扰模式");
        backBtn= (ImageButton) title.findViewById(R.id.backBtn);
        backBtn.setOnClickListener(this);

        ctr_box= (RelativeLayout) this.findViewById(R.id.ctr_box);
        set_LL= (LinearLayout) this.findViewById(R.id.set_LL);
        start_LL= (RelativeLayout) this.findViewById(R.id.start_LL);
        end_LL= (RelativeLayout) this.findViewById(R.id.end_LL);
        start_TV= (TextView) this.findViewById(R.id.start_TV);
        end_TV= (TextView) this.findViewById(R.id.end_TV);
        ctrBtn = (Switch) ctr_box.findViewById(R.id.ctrlBtn);
        name_TV = (TextView) ctr_box.findViewById(R.id.name_TV);
        desc_TV = (TextView) ctr_box.findViewById(R.id.desc_TV);

        startHours=SharedUtil.getInt(NotiToggleActivity.this,"startHours");
        startminutes=SharedUtil.getInt(NotiToggleActivity.this,"startminutes");
        endHours=SharedUtil.getInt(NotiToggleActivity.this,"endHours");
        endminutes=SharedUtil.getInt(NotiToggleActivity.this,"endminutes");
        setText(start_TV,startHours,startminutes);
        setText(end_TV,endHours,endminutes);

        if(curVo!=null) {
            name_TV.setText(curVo.getName());
            desc_TV.setText(curVo.getDesc());
            ctrBtn.setChecked(curVo.getState() == 1 ? true : false);
        }
        set_LL.setVisibility(ctrBtn.isChecked()?View.VISIBLE:View.GONE);

        start_LL.setOnClickListener(this);
        end_LL.setOnClickListener(this);
        ctrBtn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.backBtn:
                this.finish();
                break;
            case R.id.start_LL:
                this.showTimePickerDialog(start_TV);
                break;
            case R.id.end_LL:
                this.showTimePickerDialog(end_TV);
                break;
            case R.id.ctrlBtn:
                curVo.setState(curVo.getState()==1?2:1);
                SharedUtil.putInt(this, "isNotiToggle", curVo.getState());
                set_LL.setVisibility(ctrBtn.isChecked()?View.VISIBLE:View.GONE);
                break;
        }
    }


    public void showTimePickerDialog(final TextView tv){
        TimePickerFragment  timePicker = new TimePickerFragment();
        timePicker.callback=new TimePickerFragment.Callback() {
            @Override
            public void onCom(int hourOfDay, int minute) {
                setText(tv,hourOfDay,minute);
                if(tv==start_TV){
                    startHours=hourOfDay;
                    startminutes=minute;
                    SharedUtil.putInt(NotiToggleActivity.this,"startHours",startHours);
                    SharedUtil.putInt(NotiToggleActivity.this,"startminutes",startminutes);
                }else{
                    endHours=hourOfDay;
                    endminutes=minute;
                    SharedUtil.putInt(NotiToggleActivity.this,"endHours",endHours);
                    SharedUtil.putInt(NotiToggleActivity.this,"endminutes",endminutes);
                }

                JPushInterface.setSilenceTime(getApplicationContext(), startHours, startminutes, endHours, endminutes);
            }
        };
        timePicker.show(getFragmentManager(), "timePicker");
    }

    private void setText(final TextView tv,int hourOfDay, int minute){
        String hourStr=hourOfDay<10?"0"+hourOfDay:hourOfDay+"";
        String minuteStr=minute<10?"0"+minute:minute+"";
        tv.setText(DateUtils.getShiChenName(hourOfDay)+"  "+hourStr+":"+minuteStr);
    }

}
