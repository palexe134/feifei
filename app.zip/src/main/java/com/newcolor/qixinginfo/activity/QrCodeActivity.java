package com.newcolor.qixinginfo.activity;

import android.app.Activity;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.TextView;

import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.global.MyApplication;
import com.newcolor.qixinginfo.manager.ScreenManager;

/**
 * 二维码界面
 *
 * Created by Administrator on 2015/10/30.
 */
public class QrCodeActivity extends Activity implements View.OnClickListener {
    private MyApplication application;
    private FrameLayout about_title;
    private TextView tv,version2_TV;
    private ImageButton backBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qr_code);
        application = (MyApplication)getApplication();
        ScreenManager.getInstance().pushActivity(this);

        about_title=(FrameLayout) this.findViewById(R.id.title);

        tv = (TextView) about_title.findViewById(R.id.titleTv);
        tv.setText("二维码");

        version2_TV = (TextView) this.findViewById(R.id.version2_TV);
        version2_TV.setText(Html.fromHtml("废废苹果版，在苹果<font color='#ff0000'>safari浏览器中扫描二维码</font>，按照提示创建桌面快捷方式"));

        backBtn= (ImageButton) about_title.findViewById(R.id.backBtn);
        backBtn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.backBtn:
                this.finish();
                break;
        }
    }


}
