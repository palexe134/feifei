package com.newcolor.qixinginfo.activity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.adapter.GongQiuAdapter;
import com.newcolor.qixinginfo.dialog.AlertDialog;
import com.newcolor.qixinginfo.global.Config;
import com.newcolor.qixinginfo.global.MyApplication;
import com.newcolor.qixinginfo.http.AsyncHttpResponseHandler;
import com.newcolor.qixinginfo.http.RequestParams;
import com.newcolor.qixinginfo.model.GongHuoVO;
import com.newcolor.qixinginfo.ui.pullrefresh.PullToRefreshSwipeMenuListView;
import com.newcolor.qixinginfo.ui.pullrefresh.RefreshTime;
import com.newcolor.qixinginfo.ui.pullrefresh.swipemenulistview.SwipeMenu;
import com.newcolor.qixinginfo.ui.pullrefresh.swipemenulistview.SwipeMenuCreator;
import com.newcolor.qixinginfo.ui.pullrefresh.swipemenulistview.SwipeMenuItem;
import com.newcolor.qixinginfo.util.HttpUtil;
import com.newcolor.qixinginfo.util.LoginUtil;
import com.newcolor.qixinginfo.util.ToastUtil;
import com.newcolor.qixinginfo.util.Tools;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

/**
 * 以供求adapter样式显示的供求列表界面
 *
 * Created by Administrator on 2015/10/21.
 */
public class GongQiuAdapterActivity extends Activity implements View.OnClickListener
        ,AdapterView.OnItemClickListener,GongQiuAdapter.Callback,AdapterView.OnItemLongClickListener, PullToRefreshSwipeMenuListView.IXListViewListener, RadioGroup.OnCheckedChangeListener {
    private PullToRefreshSwipeMenuListView mPullListView;
    private GongQiuAdapter mAdapter;
    private ArrayList<GongHuoVO> mListItems;
    private int mCurIndex = 0;
    private static final int mLoadDataCount = 20;
    private static final int[] viewIdArr={R.id.img_IV,R.id.phoneBtn,R.id.title_TV,R.id.address_TV
            ,R.id.content_TV,R.id.star_LL,R.id.time_TV,R.id.icon_IV,R.id.distance_TV
            ,R.id.content_LL,R.id.bg_LL,R.id.select_CB};

    private MyApplication application;
    private FrameLayout gongqiu_title;
    private TextView title_TV;
    private ImageButton backBtn;
    private RelativeLayout ctr_box;
    private Button deletBtn,cancleBtn;
    private CheckBox all_CB;
    private Handler mHandler;
    private RadioGroup title_RG;
    private RadioButton radio1,radio2;

    private ArrayList<GongHuoVO> selectArr;
    //1:我的需求   2:我的供应   3:我的关注    4：我的足迹 5:供求推荐 6：热点推荐 7:我的二手
    private int type;
    private boolean isChange=false;
    //1:供货  2：需求 3:二手
    private int state=1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gong_qiu_adapter);
        application = (MyApplication) this.getApplication();

        Intent intent=this.getIntent();
        if(intent!=null){
            type=intent.getIntExtra("type",1);
            state=intent.getIntExtra("state",1);
        }

        title_TV= (TextView) this.findViewById(R.id.title_TV);
        gongqiu_title=(FrameLayout) this.findViewById(R.id.gongqiu_adapter_title);
        title_RG= (RadioGroup) gongqiu_title.findViewById(R.id.title_RG);
        title_RG.setOnCheckedChangeListener(this);
        radio1= (RadioButton) gongqiu_title.findViewById(R.id.radio1);
        radio2= (RadioButton) gongqiu_title.findViewById(R.id.radio2);
        setTitle();

        backBtn= (ImageButton) gongqiu_title.findViewById(R.id.backBtn);
        backBtn.setOnClickListener(this);

        selectArr=new ArrayList<GongHuoVO>();
        ctr_box= (RelativeLayout) this.findViewById(R.id.ctr_box);
        deletBtn= (Button) this.findViewById(R.id.deletBtn);
        cancleBtn= (Button) this.findViewById(R.id.cancleBtn);
        all_CB= (CheckBox) this.findViewById(R.id.all_CB);
        ctr_box.setVisibility(View.GONE);
        deletBtn.setOnClickListener(this);
        cancleBtn.setOnClickListener(this);
        all_CB.setOnClickListener(this);

        mCurIndex = 0;
        mListItems = new ArrayList<GongHuoVO>();
        mAdapter = new GongQiuAdapter(this,mListItems,R.layout.item_list_gong_qiu,viewIdArr,this);
        //定义下拉刷新
        mPullListView=(PullToRefreshSwipeMenuListView) this.findViewById(R.id.gongQiuPullListView);
        mPullListView.setAdapter(mAdapter);
        mPullListView.setPullRefreshEnable(true);
        mPullListView.setPullLoadEnable(true);
        mPullListView.setXListViewListener(this);
        mPullListView.setOnItemClickListener(this);
        mHandler = new Handler();

        SwipeMenuCreator creator = new SwipeMenuCreator() {
            @Override
            public void create(SwipeMenu menu) {
                SwipeMenuItem openItem = new SwipeMenuItem(GongQiuAdapterActivity.this);
                openItem.setBackground(new ColorDrawable(Color.rgb(0xF9, 0x3F, 0x25)));
                openItem.setWidth(Tools.dp2px(GongQiuAdapterActivity.this, 90));
                openItem.setTitle("删除");
                openItem.setTitleSize(18);
                openItem.setTitleColor(Color.WHITE);
                menu.addMenuItem(openItem);

                /*SwipeMenuItem deleteItem = new SwipeMenuItem(getActivity());
                deleteItem.setBackground(new ColorDrawable(Color.rgb(0xF9, 0x3F, 0x25)));
                deleteItem.setWidth(Tools.dp2px(getActivity(), 90));
                menu.addMenuItem(deleteItem);*/
            }
        };
        // set creator
        mPullListView.setMenuCreator(creator);
        mPullListView.setOnMenuItemClickListener(new PullToRefreshSwipeMenuListView.OnMenuItemClickListener() {
            @Override
            public void onMenuItemClick(int position, SwipeMenu menu, int index) {
                GongHuoVO item = mListItems.get(position);
                switch (index) {
                    case 0:
                        cancleHandler();
                        selectArr.add(item);
                        deletHandler();
                        break;
                }
            }
        });

        //根据ID找到RadioGroup实例
        title_RG= (RadioGroup)gongqiu_title.findViewById(R.id.title_RG);
        //绑定一个匿名监听器
        title_RG.setOnCheckedChangeListener(this);
        if(state == 1){
            radio2.setChecked(true);
        }else{
            radio1.setChecked(true);
        }
//        title_RG.check();
    }


    @Override
    public void onResume() {
        super.onResume();
        this.flushData(true);
    }

    /**
     * 初始化数据
     */
    private void initData(){
        this.getGongQiuList();
    }

    public void setTitle(){
        title_TV.setVisibility(View.GONE);
        title_RG.setVisibility(View.VISIBLE);
        if(type==1||type==2){
            radio1.setText("我的需求");
            radio2.setText("我的供应");
        }else if(type==3){
            radio1.setText("供应关注");
            radio2.setText("需求关注");
        }else if(type==4){
            radio1.setText("供应足迹");
            radio2.setText("需求足迹");
        }else if(type==5){
            radio1.setText("卖家推荐");
            radio2.setText("买家推荐");
        }else if(type==7){
            title_RG.setVisibility(View.GONE);
            title_TV.setText("我的二手");
            title_TV.setVisibility(View.VISIBLE);
        }
    }

    private String getXieYiName(){
        if(type==3){
            return Config.MyAttentionList;
        }else if(type==4){
            return Config.myFootprintList;
        }else if(type==5){
            return Config.getHotGongQiuList;
        }else if(type==6){
            return Config.getHotchooseList;
        }else{
            return Config.MyGongQiuList;
        }
    }

    private String getDeletXieYiName(){
        if(type==3){
            return Config.deleteMyAtte;
        }else if(type==4){
            return Config.deleteMyFoot;
        }else{
            return Config.deleteMySDInfo;
        }
    }

    /*
   * 向服务器发送请求消息列表
   * */
    private void getGongQiuList(){
        if(ctr_box.getVisibility()==View.VISIBLE){
            mPullListView.stopLoadMore();
            mPullListView.stopRefresh();
            ToastUtil.showToast(this,"您正在进行删除操作，不能执行刷新");
            return;
        }


        String agreement=getXieYiName();

        RequestParams params=new RequestParams();
        params.put("userId",application.getUserId(this));
        params.put("type",String.valueOf(state));
        params.put("curSize",String.valueOf(mCurIndex));
        params.put("count",String.valueOf(mLoadDataCount));


        HttpUtil.get(agreement,params,new AsyncHttpResponseHandler(){
            Boolean isHasMore=false;
            @Override
            public void onFailure(Throwable error, String content) {
                super.onFailure(error, content);
                ToastUtil.showToast(GongQiuAdapterActivity.this,content);
            }

            @Override
            public void onSuccess(String content) {
                int index=content.indexOf("\"isSuc\":0");
                if(content.equals("")||index>=0){
                    return;
                }
                super.onSuccess(content);
                ArrayList<GongHuoVO> arrayList= (ArrayList<GongHuoVO>) JSON.parseArray(content,GongHuoVO.class);

                if (isChange) {
                    mListItems.clear();
                    isChange = false;
                }
                if(arrayList!=null) {
                    mListItems.addAll(arrayList);
                    mCurIndex ++;
                    if (arrayList.size() < mLoadDataCount) {
                        isHasMore = false;
                    } else {
                        isHasMore = true;
                    }
                }

                mAdapter.notifyDataSetChanged();
                mPullListView.setRefreshTime(RefreshTime.getRefreshTime(GongQiuAdapterActivity.this));
                mPullListView.stopRefresh();
                mPullListView.stopLoadMore();
                mPullListView.setPullLoadEnable(isHasMore);

            }
        });
//        mListItems.clear();
//        GongHuoVO vo;
//
//        for (int i = 0; i < 11; i++) {
//            vo = new GongHuoVO();
//            vo.setAdress("山东省临沂市罗庄区");
//            vo.setContent("出售500斤铜矿");
//            vo.setStar(5);
//            vo.setTelephone("15953981802");
//            vo.setTitle("出售铜矿");
//            mListItems.add(vo);
//        }
    }

    public void flushData(boolean isChange){
        this.isChange=isChange;
        mCurIndex=0;
        this.initData();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.backBtn:
                this.finish();
                break;
            case R.id.cancleBtn:
                this.cancleHandler();
                break;
            case R.id.deletBtn:
                this.deletHandler();
                break;
            case R.id.all_CB:
                this.updateSelect(all_CB.isChecked());
                break;
        }
    }


    private void cancleHandler(){
        selectArr.clear();
        this.updateSelect(false);
        this.updateShow(false);
        all_CB.setChecked(false);
        ctr_box.setVisibility(View.GONE);
    }

    private void deletHandler(){
        RequestParams params=new RequestParams();
        params.put("type",String.valueOf(state));
        params.put("userId", application.getUserId(this));
        String idStr="";
        int i=0;
        for (GongHuoVO vo:selectArr){
            if(i<selectArr.size()-1){
                idStr+=vo.getSId()+",";
            }else{
                idStr+=vo.getSId();
            }
            i++;
        }
        params.put("sId", idStr);
        HttpUtil.get(this.getDeletXieYiName(), params, new AsyncHttpResponseHandler() {
            @Override
            public void onFailure(Throwable error, String content) {
                super.onFailure(error, content);
                ToastUtil.showToast(GongQiuAdapterActivity.this, content);
            }

            @Override
            public void onSuccess(String content) {
                super.onSuccess(content);

                JSONObject jsonObject = null;
                try {
                    jsonObject = new JSONObject(content);
                    byte isSuc = Byte.parseByte(jsonObject.getString("isSuc"));
                    if (isSuc == 0) {
                        String msg = jsonObject.getString("msg");
                        ToastUtil.showToast(GongQiuAdapterActivity.this, msg);
                    } else {
                        cancleHandler();
                        flushData(true);
                        ToastUtil.showToast(GongQiuAdapterActivity.this, "删除信息成功");
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    private void updateSelect(boolean isSelected){
        for (GongHuoVO vo:mListItems){
            vo.setIsSelected(isSelected);
            if(isSelected){
                selectArr.add(vo);
            }else{
                selectArr.remove(vo);
            }
        }
        mAdapter.notifyDataSetChanged();
    }

    private void updateShow(boolean isShow){
        for (GongHuoVO vo:mListItems){
            vo.setIsShow(isShow);
        }
        mAdapter.notifyDataSetChanged();
    }


    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        ListView listView = (ListView) parent;
        GongHuoVO vo = (GongHuoVO) listView.getItemAtPosition(position);

        if (application.getUserId(this).equals("-1")) {
            LoginUtil.gotoLogin(this);
            return;
        }
        Intent intent = new Intent(this, GongQiuInfoActivity.class);
        intent.putExtra("sId", vo.getSId());
        intent.putExtra("type", state);
        startActivity(intent);
    }

    @Override
    public void click(View v) {
        final GongHuoVO vo = (GongHuoVO) v.getTag();
        switch (v.getId()) {
            case R.id.phoneBtn:
                new AlertDialog(this).builder().setTitle("联系商家")
                        .setMsg(vo.getPhone()+"\n\n废废网竭诚为您服务")
                        .setPositiveButton("确定", new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                phoneHandler(vo);
                            }
                        }).setNegativeButton("取消", new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                    }
                }).show();
                break;
            case R.id.select_CB:
                vo.setIsSelected(!vo.isSelected());
                if(!vo.isSelected()){
                    all_CB.setChecked(false);
                    selectArr.remove(vo);
                }else{
                    selectArr.add(vo);
                    if(selectArr.size()==mListItems.size()){
                        all_CB.setChecked(true);
                    }
                }
                mAdapter.notifyDataSetChanged();
                break;
        }
    }

    private void phoneHandler(GongHuoVO vo){
        Intent intent = new Intent(Intent.ACTION_CALL);
        Uri data = Uri.parse("tel:" + vo.getPhone());
        intent.setData(data);
        startActivity(intent);
    }


    @Override
    public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
        ctr_box.setVisibility(View.VISIBLE);
        this.updateShow(true);
        return true;
    }


    @Override
    public void onCheckedChanged(RadioGroup group, int checkedId) {
        if(checkedId==R.id.radio1){
            state=2;
            this.flushData(true);
        }else{
            state=1;
            this.flushData(true);
        }
    }

    @Override
    public void onRefresh() {
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                SimpleDateFormat df = new SimpleDateFormat("MM-dd HH:mm", Locale.getDefault());
                RefreshTime.setRefreshTime(GongQiuAdapterActivity.this, df.format(new Date()));
                flushData(true);
            }
        }, 2000);
    }

    @Override
    public void onLoadMore() {
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                initData();
            }
        }, 2000);
    }
}
