package com.newcolor.qixinginfo.activity;

import android.app.Activity;
import android.app.KeyguardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.PowerManager;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;

import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.adapter.AlarmItemAdapter;
import com.newcolor.qixinginfo.global.MyApplication;
import com.newcolor.qixinginfo.model.ContactVO;
import com.newcolor.qixinginfo.model.Msg;
import com.newcolor.qixinginfo.util.LogUtil;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import cn.jpush.android.api.JPushInterface;

/**
 * 锁屏情况下，消息屏幕正中列表显示Jpush推送的消息
 *
 * Created by Administrator on 2015/10/25.
 */
public class AlarmHandlerActivity extends Activity implements View.OnClickListener, AdapterView.OnItemClickListener {
    private LinearLayout alarm_LL;
    private MyApplication application;

    private ImageButton closeBtn;
    private ListView mListView;
    private AlarmItemAdapter mAdapter;
    private ArrayList<Msg> mListItems;
    private Msg msg; //屏幕点亮
    private PowerManager.WakeLock m_wakeLockObj = null;
    private static final int[] viewIdArr={R.id.content_TV,R.id.time_TV};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        final Window win = getWindow();
        win.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
                | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);

        setContentView(R.layout.activity_alarm);
        application= (MyApplication) this.getApplication();

        closeBtn= (ImageButton) this.findViewById(R.id.closeBtn);
        alarm_LL= (LinearLayout) this.findViewById(R.id.alarm_LL);
        alarm_LL.setOnClickListener(this);
        closeBtn.setOnClickListener(this);

        msg=null;
        Intent intent=this.getIntent();
        if(intent!=null){
            msg =intent.getParcelableExtra("msg");
        }

        mListItems=application.getSubscribeList();
        mAdapter=new AlarmItemAdapter(this,mListItems,R.layout.item_list_alarm,viewIdArr);

        mListView= (ListView) this.findViewById(R.id.data_LV);
        mListView.setAdapter(mAdapter);
        mListView.setOnItemClickListener(this);

        this.initData();
    }

    //		if (MainActivity.isForeground) {
//			String message = bundle.getString(JPushInterface.EXTRA_MESSAGE);
//			String extras = bundle.getString(JPushInterface.EXTRA_EXTRA);
//			Intent msgIntent = new Intent(MainActivity.MESSAGE_RECEIVED_ACTION);
//			msgIntent.putExtra(MainActivity.KEY_MESSAGE, message);
//			if (!ExampleUtil.isEmpty(extras)) {
//				try {
//					JSONObject extraJson = new JSONObject(extras);
//					if (null != extraJson && extraJson.length() > 0) {
//						msgIntent.putExtra(MainActivity.KEY_EXTRAS, extras);
//					}
//				} catch (JSONException e) {
//
//				}
//
//			}
//			context.sendBroadcast(msgIntent);
//		}

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (m_wakeLockObj != null) {
            m_wakeLockObj.release();
            m_wakeLockObj = null;
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        PowerManager pm = (PowerManager) this.getSystemService(Context.POWER_SERVICE);
        if (!pm.isScreenOn()) {
            m_wakeLockObj = pm.newWakeLock(PowerManager.ACQUIRE_CAUSES_WAKEUP |
                    PowerManager.SCREEN_BRIGHT_WAKE_LOCK, "bright");
            m_wakeLockObj.setReferenceCounted(false);
            m_wakeLockObj.acquire(1000 * 3);
//            m_wakeLockObj.release();
        }
        msg=null;
        if(intent!=null){
            msg =intent.getParcelableExtra("msg");
        }
        this.initData();
    }





    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.alarm_LL:
                this.clickHandler();
                break;
            case R.id.closeBtn:
                this.finish();
                break;
        }

    }

    private void initData(){
        if(msg!=null){
            if(mListItems.size()>5){
                mListItems.remove(0);
                mListItems.add(msg);
            }else{
                mListItems.add(msg);
            }
            mAdapter.notifyDataSetChanged();
        }

//        for(int i=0;i<5;i++){
//
//            if(i==1||i==3){
//                vo.setContent("● 光亮铜5元");
//            }else {
//                vo.setContent("● 光亮铜5元嘎鱼敌法师房贷是覅按时到覅阿萨德发送的发生发生地方");
//            }
//        }
    }

    private void clickHandler(){
        KeyguardManager keyguardManager = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
        KeyguardManager.KeyguardLock keyguardLock = keyguardManager.newKeyguardLock("");
        keyguardLock.disableKeyguard();

        Intent i = new Intent(this, MainActivity.class);
        i.putExtra("index",2);
        this.startActivity(i);

        this.finish();
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        ListView listView = (ListView) parent;
        Msg msg = (Msg) listView.getItemAtPosition(position);

        KeyguardManager keyguardManager = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
        KeyguardManager.KeyguardLock keyguardLock = keyguardManager.newKeyguardLock("");
        keyguardLock.disableKeyguard();

        Intent intent;
        if(msg.getType().equals("1")) {
//            intent=new Intent(this, SubscribeActivity.class);
//            intent.putExtra("type",1);
//            startActivityForResult(intent, 1);

            intent = new Intent(this, MainActivity.class);
            intent.putExtra("index",2);
            this.startActivity(intent);

            this.finish();
        }else{
            intent = new Intent(this, MsgActivity.class);
            Bundle mBundle = new Bundle();
            mBundle.putParcelable("msg", msg);
            intent.putExtras(mBundle);
            this.startActivity(intent);
        }
    }
}
