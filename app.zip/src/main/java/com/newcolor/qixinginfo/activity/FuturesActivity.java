package com.newcolor.qixinginfo.activity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.entity.FutruesEntity;
import com.newcolor.qixinginfo.fragment.KChartsFragment;
import com.newcolor.qixinginfo.fragment.TimesFragment;
import com.newcolor.qixinginfo.util.ProtocolUtil;

import org.w3c.dom.Text;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * 期货行情界面
 *
 * Created by Administrator on 2016/1/15.
 */
public class FuturesActivity extends FragmentActivity implements View.OnClickListener {
    private RadioGroup bottomRg;
    //    private FragmentManager fragmentManager;
//    private FragmentTransaction fragmentTransaction;
    private RadioButton rbOne, rbTwo;
    private Boolean isExit = false;
    private int index=1,prevIndex=-1;
    private ArrayList<RadioButton> radioArr;
    private FutruesEntity curVO;
    private ImageButton backBtn;
    private Button title_refresh_btn;
    private TextView title_name,title_num,now_price,lift,lift_rate
                ,open_data,high_data,zuo_jie_data,jie_price_data,ysd_close_data
            ,low_data,buy_price_data,sell_price_data,buy_count_data,sell_count_data
            ,chi_cang_data,cheng_jiao_data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_futures);

        Intent intent=getIntent();
        if(intent!=null){
            curVO=intent.getParcelableExtra("FutruesEntity");
        }

        bottomRg = (RadioGroup) findViewById(R.id.bottomRg);
        rbOne = (RadioButton) findViewById(R.id.rbOne);
        rbTwo = (RadioButton) findViewById(R.id.rbTwo);

        radioArr=new ArrayList<RadioButton>();
        radioArr.add(rbOne);
        radioArr.add(rbTwo);

        this.init();
        this.initData();

    }

    private void init(){
        setFragmentIndicator();
        this.openHandler(index);

        backBtn= (ImageButton) this.findViewById(R.id.backBtn);
        title_refresh_btn= (Button) this.findViewById(R.id.title_refresh_btn);
        title_name= (TextView) this.findViewById(R.id.title_name);
        title_num= (TextView) this.findViewById(R.id.title_num);
        open_data= (TextView) this.findViewById(R.id.open_data);
        now_price= (TextView) this.findViewById(R.id.now_price);
        lift= (TextView) this.findViewById(R.id.lift);
        lift_rate= (TextView) this.findViewById(R.id.lift_rate);
        low_data= (TextView) this.findViewById(R.id.low_data);
        high_data= (TextView) this.findViewById(R.id.high_data);
        zuo_jie_data= (TextView) this.findViewById(R.id.zuo_jie_data);
        jie_price_data= (TextView) this.findViewById(R.id.jie_price_data);
        ysd_close_data= (TextView) this.findViewById(R.id.ysd_close_data);
        buy_price_data= (TextView) this.findViewById(R.id.buy_price_data);
        sell_price_data= (TextView) this.findViewById(R.id.sell_price_data);
        buy_count_data= (TextView) this.findViewById(R.id.buy_count_data);
        sell_count_data= (TextView) this.findViewById(R.id.sell_count_data);
        chi_cang_data= (TextView) this.findViewById(R.id.chi_cang_data);
        cheng_jiao_data= (TextView) this.findViewById(R.id.cheng_jiao_data);

        backBtn.setOnClickListener(this);
        title_refresh_btn.setOnClickListener(this);
    }

    private void initData(){
        ProtocolUtil.getFutruesEntity("http://hq.sinajs.cn/list=" + curVO.getPrefix() + curVO.getCode(), new ProtocolUtil.CallBack() {
            @Override
            public void onListCom(ArrayList list) {
            }

            @Override
            public void onVoCom(FutruesEntity vo) {
                DecimalFormat df = new DecimalFormat("#.##");
                title_name.setText(vo.getName());
                title_num.setText(vo.getCode());
                if(vo.getChangeAmount()>0) {
                    now_price.setTextColor(Color.RED);
                    lift.setTextColor(Color.RED);
                    lift_rate.setTextColor(Color.RED);
                    lift.setText("+" + String.valueOf(df.format(vo.getChangeAmount())));
                    lift_rate.setText("+"+String.valueOf(df.format(vo.getChangeRate()))+"%");
                }else if(vo.getChangeAmount()==0) {
                    now_price.setTextColor(Color.GRAY);
                    lift.setTextColor(Color.GRAY);
                    lift_rate.setTextColor(Color.GRAY);
                    lift.setText(String.valueOf(df.format(vo.getChangeAmount())));
                    lift_rate.setText(String.valueOf(df.format(vo.getChangeRate()))+"%");
                }else{
                    now_price.setTextColor(Color.GREEN);
                    lift.setTextColor(Color.GREEN);
                    lift_rate.setTextColor(Color.GREEN);
                    lift.setText("-" + String.valueOf(df.format(vo.getChangeAmount())));
                    lift_rate.setText("-"+String.valueOf(df.format(vo.getChangeRate()))+"%");
                }

                now_price.setText(String.valueOf(vo.getPrice()));

                open_data.setText(String.valueOf(df.format(vo.getOpen())));
                low_data.setText(String.valueOf(df.format(vo.getLow())));
                high_data.setText(String.valueOf(df.format(vo.getHigh())));
                zuo_jie_data.setText(String.valueOf(df.format(vo.getZuoJie())));
                jie_price_data.setText(String.valueOf(df.format(vo.getJiePrice())));
                ysd_close_data.setText(String.valueOf(df.format(vo.getZuoJie())));
                buy_price_data.setText(String.valueOf(df.format(vo.getBuyPrice())));
                sell_price_data.setText(String.valueOf(df.format(vo.getSellPrice())));
                buy_count_data.setText(String.valueOf(vo.getBuyCount()));
                sell_count_data.setText(String.valueOf(vo.getSellCount()));
                chi_cang_data.setText(String.valueOf(vo.getChiCang()));
                cheng_jiao_data.setText(String.valueOf(vo.getChengJiao()));
            }
        });
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        index=intent.getIntExtra("index",1);
        this.openHandler(index);
    }

    private void openHandler(int index){
//        fragmentTransaction = fragmentManager.beginTransaction()
//                .hide(mFragments[0]).hide(mFragments[1])
//                .hide(mFragments[2]).hide(mFragments[3]);
//        fragmentTransaction.show(mFragments[index]).commitAllowingStateLoss();
        if(this.prevIndex==index){
            return;
        }

        this.prevIndex=index;
        Fragment df;
        if(index==0) {
            df = new TimesFragment();
        }else{
            df = new KChartsFragment();
            Bundle bundle = new Bundle();
            bundle.putParcelable("futruesVo", curVO);
            df.setArguments(bundle);
        }
        //获取FragmentTransaction 实例
        FragmentTransaction ft = this.getSupportFragmentManager().beginTransaction();
        //使用DetailsFragment 的实例
        ft.replace(R.id.detials, df);
        ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
        ft.commitAllowingStateLoss();
        radioArr.get(index).setChecked(true);

    }


    private void setFragmentIndicator() {
        bottomRg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.rbOne:
                        openHandler(0);
                        break;
                    case R.id.rbTwo:
                        openHandler(1);
                        break;
                }

            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.backBtn:
                this.finish();
                break;
            case R.id.title_refresh_btn:
                Intent intent=new Intent(this, OpinionActivity.class);
                intent.putExtra("type",1);
                startActivity(intent);
                break;
        }
    }
}
