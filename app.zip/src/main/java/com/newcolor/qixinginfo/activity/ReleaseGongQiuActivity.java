package com.newcolor.qixinginfo.activity;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.dialog.AlertDialog;
import com.newcolor.qixinginfo.global.Config;
import com.newcolor.qixinginfo.global.MyApplication;
import com.newcolor.qixinginfo.http.AsyncHttpResponseHandler;
import com.newcolor.qixinginfo.http.RequestParams;
import com.newcolor.qixinginfo.manager.ScreenManager;
import com.newcolor.qixinginfo.model.ContactVO;
import com.newcolor.qixinginfo.model.GongQiuInfoVO;
import com.newcolor.qixinginfo.model.GoodTypeVO;
import com.newcolor.qixinginfo.util.ChooseTypeUtil;
import com.newcolor.qixinginfo.util.HttpUtil;
import com.newcolor.qixinginfo.util.ToastUtil;
import com.newcolor.qixinginfo.view.AddImageView;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;

/**
 * 发布供求界面
 *
 * Created by Administrator on 2015/10/9.
 * 发布供求
 */
public class ReleaseGongQiuActivity extends Activity implements View.OnClickListener {

    private MyApplication application;
    private FrameLayout login_title;
    private TextView tv,name_TV,phone_TV,address_TV,classification_TV;
    private ImageButton backBtn;
    private RelativeLayout contact_LL,classification_RL;
    private Button releaseBtn,tuiGuangBtn;
    private EditText title_ET,num_ET,price_ET,content_ET;
    private int type;
    private ArrayList<String> urlArr=new ArrayList<String>();
    private ContactVO curVo;
    private boolean isRelease=false;
    private String curMsgId="";
    private GoodTypeVO curGoodTypeVo;
    private AddImageView addImageView;
    private GongQiuInfoVO infoVO;

    public static final int RELEASE_HUO_YUAN=1;
    public static final int RELEASE_XU_QIU=2;
    public static final int RELEASE_ER_SHOU=3;

    public static final int TAKE_BIG_PICTURE=1;
    public static final int TAKE_SMALL_PICTURE=2;

    public static final int CROP_BIG_PICTURE=3;
    public static final int CROP_SMALL_PICTURE=4;

    public static final int TAKE_CAMERA_PICTURE=5;
    private static final int CONTACT_LIST_REQUEST_CODE=6;
    private static final int ADD_IMG_REQUEST_CODE=7;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_release_gong_qiu);
        application = (MyApplication)getApplication();
        ScreenManager.getInstance().pushActivity(this);

        init();
    }

    private void init(){
        Intent intent=this.getIntent();
        if(intent!=null){
            type=intent.getIntExtra("type",RELEASE_HUO_YUAN);
            infoVO=intent.getParcelableExtra("infoVo");
        }
        login_title=(FrameLayout) this.findViewById(R.id.release_title);
        tv = (TextView) login_title.findViewById(R.id.titleTv);

        backBtn= (ImageButton) login_title.findViewById(R.id.backBtn);
        contact_LL= (RelativeLayout) this.findViewById(R.id.contact_LL);
        name_TV= (TextView) this.findViewById(R.id.name_TV);
        phone_TV= (TextView) this.findViewById(R.id.phone_TV);
        address_TV= (TextView) this.findViewById(R.id.address_TV);
        classification_TV= (TextView) this.findViewById(R.id.classification_TV);
        classification_RL= (RelativeLayout) this.findViewById(R.id.classification_RL);
        releaseBtn= (Button) this.findViewById(R.id.releaseBtn);
        tuiGuangBtn= (Button) this.findViewById(R.id.tuiGuangBtn);
        title_ET= (EditText) this.findViewById(R.id.title_ET);
        price_ET= (EditText) this.findViewById(R.id.price_ET);
        num_ET= (EditText) this.findViewById(R.id.num_ET);
        content_ET= (EditText) this.findViewById(R.id.content_ET);
        if(type==RELEASE_HUO_YUAN) {
            tv.setText("发布货源");
//            addImg_RL.setVisibility(View.VISIBLE);
        }else if(type==RELEASE_XU_QIU){
            tv.setText("发布需求");
//            addImg_RL.setVisibility(View.GONE);
        }else if(type==RELEASE_ER_SHOU){
            tv.setText("发布二手");
//            addImg_RL.setVisibility(View.GONE);
        }

        addImageView= (AddImageView) this.findViewById(R.id.addImageView);

        backBtn.setOnClickListener(this);
        contact_LL.setOnClickListener(this);
        releaseBtn.setOnClickListener(this);
        tuiGuangBtn.setOnClickListener(this);
        classification_RL.setOnClickListener(this);

        this.initData();
        addImageView.initView(urlArr);
    }

    private void initData(){
        if(infoVO!=null){
            title_ET.setText(infoVO.getTitle());
            price_ET.setText(infoVO.getPrice());
            num_ET.setText(infoVO.getNum());
            name_TV.setText(infoVO.getName());
            phone_TV.setText(infoVO.getPhone());
            address_TV.setText(infoVO.getAddress());
            content_ET.setText(infoVO.getContent());
            curVo=new ContactVO();
            curVo.setCoordinate(infoVO.getCoordinate());
            curVo.setName(infoVO.getName());
            curVo.setAddress(infoVO.getAddress());
            curVo.setPhone(infoVO.getPhone());
            ChooseTypeUtil.getInstance(this).getClassificationVo(infoVO.getClassificationId(), new ChooseTypeUtil.Callback() {
                @Override
                public void onCom(GoodTypeVO vo) {
                    classification_TV.setText(vo.getName());
                    curGoodTypeVo=vo;
                }
            });
            Collections.addAll(urlArr, infoVO.getUrlArr());
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        addImageView.onActivityResult(requestCode,resultCode,data);

        switch (requestCode) {
            case CONTACT_LIST_REQUEST_CODE:
                if(resultCode==ContactListActivity.RELEASE_GONG_QIU_RESULT_CODE) {
                    curVo = data.getParcelableExtra("contactVo");
                    name_TV.setText("姓名：" + curVo.getName());
                    phone_TV.setText("电话：" + curVo.getPhone());
                    address_TV.setText("地址：" + curVo.getSureAddress());
                }
                break;
            default:
                break;
        }
    }


    @Override
    protected void onResume() {
        super.onResume();
    };

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.backBtn:
                this.finish();
                break;
            case R.id.contact_LL:
                Intent intent=new Intent(this,ContactListActivity.class);
                intent.putExtra("type", ContactListActivity.RELEASE_OPEN);
                startActivityForResult(intent, CONTACT_LIST_REQUEST_CODE);
                break;

            case R.id.releaseBtn:
                this.releaseHandler(false);
                break;
            case R.id.tuiGuangBtn:
                this.releaseHandler(true);
                break;
            case R.id.classification_RL:
                ChooseTypeUtil.getInstance(this).showDatas(new ChooseTypeUtil.Callback() {
                    @Override
                    public void onCom(GoodTypeVO vo) {
                        curGoodTypeVo=vo;
                        classification_TV.setText(curGoodTypeVo.getName());
                    }
                });
                break;
        }
    }

    private void tuiGuangHandler(){
        RequestParams params=new RequestParams();
        params.put("userId",application.getUserId(this));
        params.put("type",String.valueOf(type));
        params.put("sId",curMsgId);
        HttpUtil.post(Config.addHotchooseInfo, params, new AsyncHttpResponseHandler() {
            @Override
            public void onFailure(Throwable error, String content) {
                super.onFailure(error, content);
                ToastUtil.showToast(ReleaseGongQiuActivity.this, content);
                isRelease = false;
            }

            @Override
            public void onSuccess(String content) {
                super.onSuccess(content);

                JSONObject jsonObject = null;
                try {
                    jsonObject = new JSONObject(content);
                    byte isSuc = Byte.parseByte(jsonObject.getString("isSuc"));
                    String msg = jsonObject.getString("msg");
                    if (isSuc == 0) {
                        ToastUtil.showToast(ReleaseGongQiuActivity.this, msg);
                    } else {
                        finish();
                        int num=jsonObject.getInt("num");
                        if(num>0){
                            new AlertDialog(ReleaseGongQiuActivity.this).builder().setTitle("推广提示")
                                    .setMsg("您的前面还有 "+num+" 条信息排队，预计 "+(num*3)+" 天后，您的信息将在首页推广。如需立即响应到首页推广，可致电我们的客服：13345086668")
                                    .setPositiveButton("电话沟通", new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            phoneHandler();
                                        }
                                    }).setNegativeButton("排队等待", new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                }
                            }).show();

                        }else{
                            new AlertDialog(ReleaseGongQiuActivity.this).builder().setTitle("推广提示")
                                    .setMsg("已将您的信息添加到首页推广，3天后将自动下架，需要再次点击推广，进行排队，如需长期推广，可致电我们的客服：13345086668")
                                    .setPositiveButton("电话沟通", new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            phoneHandler();
                                        }
                                    }).setNegativeButton("排队等待", new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                }
                            }).show();
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                isRelease = false;
            }
        });
    }


    private void phoneHandler(){
        Intent intent = new Intent(Intent.ACTION_CALL);
        Uri data = Uri.parse("tel:" + curVo.getPhone());
        intent.setData(data);
        startActivity(intent);
    }

    private void releaseHandler(final boolean isTuiGuang){
        if(isRelease)return;
        isRelease=true;
        if(curVo==null){
            isRelease=false;
            ToastUtil.showToast(this,"请添加联系方式");
            return;
        }
        if(title_ET.getText().toString().isEmpty()){
            isRelease=false;
            ToastUtil.showToast(this,"标题不能为空");
            return;
        }
        if(content_ET.getText().toString().isEmpty()){
            isRelease=false;
            ToastUtil.showToast(this,"内容不能为空");
            return;
        }
        if(curVo.getName()==null||curVo.getName().isEmpty()){
            isRelease=false;
            ToastUtil.showToast(this,"姓名不能为空");
            return;
        }
        if(curVo.getPhone()==null||curVo.getPhone().isEmpty()){
            isRelease=false;
            ToastUtil.showToast(this,"电话不能为空");
            return;
        }
        if(curVo.getAddress()==null||curVo.getAddress().isEmpty()){
            isRelease=false;
            ToastUtil.showToast(this,"地址不能为空");
            return;
        }

        if(curGoodTypeVo==null){
            isRelease=false;
            ToastUtil.showToast(this,"必须选择物品分类");
            return;
        }

        if(isTuiGuang){
            if(urlArr.size()<=0){
                ToastUtil.showToast(this,"推广的产品必须资料完整，请上传图片");
                return;
            }
            if(content_ET.getText().toString().isEmpty()){
                ToastUtil.showToast(this,"推广的产品必须资料完整，请填写产品描述");
                return;
            }
        }

        RequestParams params=new RequestParams();
        if(infoVO!=null){
            params.put("sId",infoVO.getsId());
        }
        params.put("userId",application.getUserId(this));
        params.put("type",String.valueOf(type));
        params.put("title",title_ET.getText().toString());
        params.put("name",curVo.getName());
        params.put("phone",curVo.getPhone());
        params.put("address",curVo.getAddress());
        params.put("coordinate",curVo.getCoordinate());
        params.put("num",num_ET.getText().toString());
        params.put("price",price_ET.getText().toString());
        params.put("classificationId", String.valueOf(curGoodTypeVo.getsId()));
        params.put("content", content_ET.getText().toString());

        String imgStr="";
        int i=0;
        for (String url:urlArr){
            if(url==AddImageView.defaultUrl){
                continue;
            }
            if(i<urlArr.size()-1) {
                imgStr += url + ",";
            }else{
                imgStr+=url;
            }
            i++;
        }
        params.put("imgArr", imgStr);

        HttpUtil.get(Config.ReleaseGongQiuInfo,params,new AsyncHttpResponseHandler(){
            @Override
            public void onFailure(Throwable error, String content) {
                super.onFailure(error, content);
                ToastUtil.showToast(ReleaseGongQiuActivity.this, content);
                isRelease=false;
            }

            @Override
            public void onSuccess(String content) {
                super.onSuccess(content);

                JSONObject jsonObject= null;
                try {
                    jsonObject = new JSONObject(content);
                    byte isSuc= Byte.parseByte(jsonObject.getString("isSuc"));
                    if(isSuc==0){
                        String msg=jsonObject.getString("msg");
                        ToastUtil.showToast(ReleaseGongQiuActivity.this,msg);
                        isRelease=false;
                    }else{
                        curMsgId=jsonObject.getString("sId");
                        if(!isTuiGuang) {
                            finish();
                            isRelease=false;
                            ToastUtil.showToast(ReleaseGongQiuActivity.this, "发布成功");
                        }else{
                            tuiGuangHandler();
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        });
    }


}
