package com.newcolor.qixinginfo.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.TextView;

import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.global.Constant;
import com.newcolor.qixinginfo.global.MyApplication;
import com.newcolor.qixinginfo.manager.ScreenManager;
import com.newcolor.qixinginfo.util.LoginUtil;
import com.newcolor.qixinginfo.util.SharedUtil;

import cn.jpush.android.api.JPushInterface;

/**
 * 登录界面
 *
 * Created by Administrator on 2015/10/9.
 */
public class LoginActivity extends Activity implements View.OnClickListener {
    private MyApplication application;

    private EditText et_account = null;
    private EditText et_password = null;
    private FrameLayout login_title;
    private TextView tv,registerTxt,findPasswordTxt;
    private Button loginBtn;
    private ImageButton backBtn;
    private String mStr_name = null;
    private String mStr_pwd = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_login);
        application = (MyApplication)getApplication();
        ScreenManager.getInstance().pushActivity(this);

        init();
    }



    private void init(){
        login_title=(FrameLayout) this.findViewById(R.id.login_title);

        tv = (TextView) login_title.findViewById(R.id.titleTv);
        tv.setText(R.string.title_login);
        backBtn= (ImageButton) login_title.findViewById(R.id.backBtn);

        et_account = (EditText)this.findViewById(R.id.et_account);
        et_password = (EditText)this.findViewById(R.id.et_password);
        registerTxt= (TextView) this.findViewById(R.id.registerTxt);
        findPasswordTxt= (TextView) this.findViewById(R.id.findPasswordTxt);
        loginBtn= (Button) this.findViewById(R.id.loginBtn);


        loginBtn.setOnClickListener(this);
        registerTxt.setOnClickListener(this);
        findPasswordTxt.setOnClickListener(this);
        backBtn.setOnClickListener(this);


        mStr_name=SharedUtil.getString(this,Constant.USERNAMECOOKIE);
        mStr_pwd=SharedUtil.getString(this,Constant.USERPASSWORDCOOKIE);
        if(mStr_name!=null && mStr_pwd!=null && !mStr_name.isEmpty()&&!mStr_pwd.isEmpty()){
            et_account.setText(mStr_name);
            et_password.setText(mStr_pwd);
            this.loginHandler();
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.registerTxt:
                Intent intent= new Intent(this,RegisterActivity.class);
                intent.putExtra("type", RegisterActivity.RegisterType);
                startActivity(intent);
                break;
            case R.id.findPasswordTxt:
                intent= new Intent(this,RegisterActivity.class);
                intent.putExtra("type", RegisterActivity.FindPasswordType);
                startActivity(intent);
                break;
            case R.id.loginBtn:
//                Intent alarmIntent = new Intent(this, AlarmHandlerActivity.class);
//                this.startActivity(alarmIntent);
                this.loginHandler();
//                this.goMainActicity();
                break;
            case R.id.backBtn:
                this.finish();
                break;

        }
    }

    private void loginHandler(){
        LoginUtil.gotoLogin(this, et_account.getText().toString(),
                et_password.getText().toString(), new LoginUtil.Callback() {
            @Override
            public void onCom() {
                goMainActicity();
            }
        });

//        RequestParams params=new RequestParams();
//        params.put("account",et_account.getText().toString());
//        params.put("passWord",et_password.getText().toString());
//        HttpUtil.get(Config.userLogin, params, new AsyncHttpResponseHandler() {
//            @Override
//            public void onFailure(Throwable error, String content) {
//                super.onFailure(error, content);
//            }
//
//            @Override
//            public void onSuccess(String content) {
//                super.onSuccess(content);
//
//                JSONObject jsonObject= null;
//                try {
//                    jsonObject = new JSONObject(content);
//                    byte isSuc= Byte.parseByte(jsonObject.getString("isSuc"));
//                    if(isSuc==0){
//                        String msg=jsonObject.getString("msg");
//                        ToastUtil.showToast(LoginActivity.this,msg);
//                    }else{
//                        application.setUserId(jsonObject.getString("userId"));
//                        JPushInterface.setAlias(application.getApplicationContext(), application.getUserId(LoginActivity.this), new TagAliasCallback() {
//                            @Override
//                            public void gotResult(int arg0, String arg1, Set<String> arg2) {
//                                // TODO Auto-generated method stub
//                                if (arg0 == 0) {
//                                    ToastUtil.showToast(LoginActivity.this, "设置标签成功");
//                                }
//                            }
//                        });
//
//                        SharedUtil.putString(LoginActivity.this, Constant.USERNAMECOOKIE, et_account.getText().toString());
//                        SharedUtil.putString(LoginActivity.this, Constant.USERPASSWORDCOOKIE, et_password.getText().toString());
//
//                        goMainActicity();
//                    }
//                } catch (JSONException e) {
//                    e.printStackTrace();
//                }
//            }
//        });
    }

    private void goMainActicity(){
        ((InputMethodManager)this.getSystemService(Context.INPUT_METHOD_SERVICE))
                .hideSoftInputFromWindow(this.getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
        this.finish();
        SharedUtil.putString(this,Constant.USERNAMECOOKIE,et_account.getText().toString());
        SharedUtil.putString(this, Constant.USERPASSWORDCOOKIE, et_password.getText().toString());
        Intent intent=new Intent(this,MainActivity.class);
        intent.putExtra("index",1);
        startActivity(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        JPushInterface.onResume(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        JPushInterface.onPause(this);
    }




}
