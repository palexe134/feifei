package com.newcolor.qixinginfo.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.text.Spanned;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.global.Config;
import com.newcolor.qixinginfo.global.MyApplication;
import com.newcolor.qixinginfo.http.AsyncHttpResponseHandler;
import com.newcolor.qixinginfo.http.RequestParams;
import com.newcolor.qixinginfo.manager.ScreenManager;
import com.newcolor.qixinginfo.model.Msg;
import com.newcolor.qixinginfo.util.HttpUtil;
import com.newcolor.qixinginfo.util.ToastUtil;


/**
 * 消息详情界面
 *
 * Created by baolei.si on 2015/8/13.
 */
public class MsgActivity extends Activity implements View.OnClickListener {
    TextView tv_content;
    private FrameLayout msg_title;
    private TextView tv,tv_title,otherBtn;
    View backBtn;
    private Button subBtn;
    private MyApplication application;
    private Msg msg=null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_msg);

        application = (MyApplication)getApplication();
        ScreenManager.getInstance().pushActivity(this);

        msg_title=(FrameLayout) this.findViewById(R.id.titleMsg);
        tv = (TextView) msg_title.findViewById(R.id.titleTv);
        tv.setText(R.string.msg_system_txt);
        otherBtn = (TextView) msg_title.findViewById(R.id.add_TV);
        otherBtn.setText("意见反馈");
        backBtn=(ImageView) msg_title.findViewById(R.id.backBtn);
        backBtn.setOnClickListener(this);

        tv_content=(TextView) findViewById(R.id.tv_content);
        tv_title=(TextView) findViewById(R.id.tv_msg_title);

        subBtn= (Button) this.findViewById(R.id.subBtn);
        subBtn.setOnClickListener(this);
        otherBtn.setOnClickListener(this);

        Intent intent = getIntent();
        if (null != intent) {
            msg =intent.getParcelableExtra("msg");
        }

        if(msg!=null) {
            int type= Integer.parseInt(msg.getType());
            if (type == 1) {
                subBtn.setVisibility(View.GONE);
                tv.setText(R.string.msg_subscribe_txt);

            } else if (type == 2) {
                subBtn.setVisibility(View.GONE);
                tv.setText(R.string.msg_personal_txt);

            } else if (type == 3) {
                tv.setText(R.string.msg_hang_qing_txt);
                subBtn.setVisibility(View.VISIBLE);

            } else if (type == 4) {
                subBtn.setVisibility(View.GONE);
                tv.setText(R.string.msg_system_txt);

            }
        }

        this.getMsgInfo();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.backBtn:
                finish();
                break;
            case R.id.subBtn:
                Intent intent=new Intent(this, PayInfoActivity.class);
                intent.putExtra("type",2);
                startActivity(intent);
                break;
            case R.id.add_TV:
                intent=new Intent(this, OpinionActivity.class);
                startActivity(intent);
                break;
        }
    }

    /*向服务器请求消息的详细信息*/
    private void getMsgInfo(){
        if(msg==null)return;
        RequestParams rParams=new RequestParams();
        rParams.put("userId", application.getUserId(this));
        rParams.put("id", msg.getsId());
        rParams.put("type", msg.getType());

        HttpUtil.get(Config.getMsgInfo, rParams, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(String response) {
                super.onSuccess(response);
                //处理服务器返回来的详细信息
                if (!response.isEmpty()) {
//                    ArrayList<Msg> infoList = (ArrayList<Msg>) JsonUtil.fromJson(response, new TypeToken<ArrayList<Msg>>() {
//                    });
//                    Msg infoMsg = infoList.get(0);
                    Msg infoMsg = JSON.parseObject(response, Msg.class);
                    if(infoMsg!=null) {
                        updateData(infoMsg);
                    }
                }
            }

            @Override
            public void onFailure(Throwable error, String content) {
                super.onFailure(error, content);
                ToastUtil.showToast(MsgActivity.this, content);
            }
        });
    }

    /*请求更新数据*/
    private void updateData(Msg infoMsg){
        tv_title.setText(infoMsg.getTitle());
        Spanned sp = Html.fromHtml(infoMsg.getContent());
        tv_content.setText(sp);
        this.updateMsgState();
    }

    /*
    * 向服务器更新阅读状态
    * */
    private void updateMsgState(){
//        if(msg==null)return;
//
//        if(!msg.getState().equals("1"))return;
//
//        RequestParams params=new RequestParams();
//        params.put("UserID", application.getUserId(this));
//        params.put("MessageID", msg.getMessageid());
////        params.put("Type", type);
////        params.put("StateType", Config.StateType);
//
//        HttpUtil.post(Config.UpdateMessageState,params,new AsyncHttpResponseHandler(){
//            @Override
//            public void onSuccess(String response){
//                if(!response.isEmpty()){
//                    ToastUtil.showToast(MsgActivity.this, response);
//                }
//            }
//        });
    }
}
