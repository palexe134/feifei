package com.newcolor.qixinginfo.activity;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.adapter.OtherGongQiuAdapter;
import com.newcolor.qixinginfo.dialog.AddPopWindow;
import com.newcolor.qixinginfo.dialog.AlertDialog;
import com.newcolor.qixinginfo.global.Config;
import com.newcolor.qixinginfo.global.Constant;
import com.newcolor.qixinginfo.global.MyApplication;
import com.newcolor.qixinginfo.http.AsyncHttpResponseHandler;
import com.newcolor.qixinginfo.http.RequestParams;
import com.newcolor.qixinginfo.manager.ScreenManager;
import com.newcolor.qixinginfo.model.BaiduMapVo;
import com.newcolor.qixinginfo.model.GongQiuInfoVO;
import com.newcolor.qixinginfo.model.OtherGongQiuVO;
import com.newcolor.qixinginfo.ui.cycleviewpager.ADInfo;
import com.newcolor.qixinginfo.ui.cycleviewpager.ImageCycleView;
import com.newcolor.qixinginfo.util.HttpUtil;
import com.newcolor.qixinginfo.util.ToastUtil;
import com.newcolor.qixinginfo.util.Tools;

import java.util.ArrayList;

/**
 * 供求详情界面
 *
 * Created by Administrator on 2015/10/9.
 */
public class GongQiuInfoActivity extends Activity implements View.OnClickListener, AdapterView.OnItemClickListener {
    private MyApplication application;
    private FrameLayout login_title;
    private TextView tv,company_TV,num_TV,content_TV
            ,content2_TV,price_TV,name_TV,tui_guang_btn;
    private ImageButton backBtn,phoneBtn,addBtn,site_IB;
    private ImageCycleView mAdView;
    private ArrayList<ADInfo> infos = new ArrayList<ADInfo>();
    private String curId;
    private int type;
    private LinearLayout content2_LL,content_LL,content1_LL;
    private RadioButton rb1,rb2,rb3;

    private GongQiuInfoVO curVo;

    private ListView mListView;
    private OtherGongQiuAdapter mAdapter;
    private ArrayList<OtherGongQiuVO> mListItems;
    private static final int[] viewIdArr={R.id.title_TV,R.id.num_TV,R.id.price_TV};

//    private String[] imageUrls = {"http://img.taodiantong.cn/v55183/infoimg/2013-07/130720115322ky.jpg",
//            "http://pic30.nipic.com/20130626/8174275_085522448172_2.jpg",
//            "http://pic18.nipic.com/20111215/577405_080531548148_2.jpg",
//            "http://pic15.nipic.com/20110722/2912365_092519919000_2.jpg",
//            "http://pic.58pic.com/58pic/12/64/27/55U58PICrdX.jpg"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_gong_qiu_info);
        application = (MyApplication)getApplication();
        ScreenManager.getInstance().pushActivity(this);

        Intent intent=this.getIntent();
        if(intent!=null){
            curId=intent.getStringExtra("sId");
            type=intent.getIntExtra("type", 1);
        }

        init();
        this.initData();
    }



    private void init(){
        login_title=(FrameLayout) this.findViewById(R.id.gongqiu_title);

        tv = (TextView) login_title.findViewById(R.id.titleTv);
        if(type==1) {
            tv.setText("供货详情");
        }else if(type==3){
            tv.setText("二手市场");
        }else{
            tv.setText("需求详情");
        }
        backBtn= (ImageButton) login_title.findViewById(R.id.backBtn);
        addBtn= (ImageButton) login_title.findViewById(R.id.addBtn);
        site_IB= (ImageButton) this.findViewById(R.id.site_IB);
        company_TV= (TextView) this.findViewById(R.id.company_TV);
        num_TV= (TextView) this.findViewById(R.id.num_TV);
        name_TV= (TextView) this.findViewById(R.id.name_TV);
        price_TV= (TextView) this.findViewById(R.id.price_TV);
        content_TV= (TextView) this.findViewById(R.id.content_TV);
        content2_TV= (TextView) this.findViewById(R.id.content2_TV);
        tui_guang_btn= (TextView) this.findViewById(R.id.tui_guang_btn);

        content_LL= (LinearLayout) this.findViewById(R.id.content_LL);
        content1_LL= (LinearLayout) this.findViewById(R.id.content1_LL);
        content2_LL= (LinearLayout) this.findViewById(R.id.content2_LL);
        content1_LL.setVisibility(View.GONE);
        content2_LL.setVisibility(View.GONE);

        phoneBtn= (ImageButton) this.findViewById(R.id.phoneBtn);
        rb1 = (RadioButton) findViewById(R.id.rb1);
        rb2 = (RadioButton) findViewById(R.id.rb2);
        rb3 = (RadioButton) findViewById(R.id.rb3);

        backBtn.setOnClickListener(this);
        addBtn.setOnClickListener(this);
        phoneBtn.setOnClickListener(this);
        site_IB.setOnClickListener(this);
        tui_guang_btn.setOnClickListener(this);
        rb1.setOnClickListener(this);
        rb2.setOnClickListener(this);
        rb3.setOnClickListener(this);

        mAdView = (ImageCycleView) findViewById(R.id.ad_view);


        mListItems=new ArrayList<OtherGongQiuVO>();

//        OtherGongQiuVO vo;
//        for(int i=0;i<5;i++){
//            vo=new OtherGongQiuVO();
//            vo.setId(String.valueOf(i));
//            vo.setTitle("asfdasdf");
//            vo.setNum("10t");
//            vo.setPrice("10t");
//            mListItems.add(vo);
//        }

        mAdapter=new OtherGongQiuAdapter(this,mListItems,R.layout.item_list_other_gong_qiu,viewIdArr);

        mListView= (ListView) this.findViewById(R.id.other_LV);
        mListView.setAdapter(mAdapter);

        mListView.setOnItemClickListener(this);
        mListView.setFocusable(false);
    }



    private void initData(){
        RequestParams params=new RequestParams();
        params.put("userId",application.getUserId(this));
        params.put("type", String.valueOf(type));
        params.put("id", curId);
        HttpUtil.get(Config.GetGongQiuInfo, params, new AsyncHttpResponseHandler() {
            @Override
            public void onFailure(Throwable error, String content) {
                super.onFailure(error, content);
                ToastUtil.showToast(GongQiuInfoActivity.this, content);
            }

            @Override
            public void onSuccess(String content) {
                super.onSuccess(content);
                curVo =JSON.parseObject(content, GongQiuInfoVO.class);
                if (curVo != null) {
                    updateData(curVo);
                }
            }
        });
    }

    private void updateData(GongQiuInfoVO vo){
        if(vo.getUrlArr()!=null&&vo.getUrlArr().length>0) {
            infos.clear();
            for (int i = 0; i < vo.getUrlArr().length; i++) {
                ADInfo info = new ADInfo();
                info.setUrl(vo.getUrlArr()[i]);
                info.setContent("top-->" + i);
                infos.add(info);
            }
            mAdView.setImageResources(infos, mAdCycleViewListener);
        }else{
            infos.clear();
            ADInfo info = new ADInfo();
            info.setUrl("");
            info.setContent("top-->");
            infos.add(info);
            mAdView.setImageResources(infos, mAdCycleViewListener);
        }
//company_TV,address_TV,num_TV,content_TV,content2_TV
        company_TV.setText(vo.getCompanyName());
        num_TV.setText("数量：" + vo.getNum() + "吨");
        price_TV.setText("价格：" + vo.getPrice() + "元");
        name_TV.setText("标题：" + vo.getTitle());
        content_TV.setText(vo.getContent());
        content2_TV.setText(vo.getCompanyDis());

        this.updateGongQiuType(vo);

        mListItems.clear();
        if(vo.getOtherData()!=null) {
            mListItems.addAll(vo.getOtherData());
        }
        mAdapter.notifyDataSetChanged();

//        setListViewHeightBasedOnChildren(mListView);
    }

    private void updateGongQiuType(GongQiuInfoVO vo){
        if(vo.getUserId()==application.getUserId(this)){
            tui_guang_btn.setVisibility(View.VISIBLE);
            if(vo.getTopId()>0) {
                tui_guang_btn.setText("已置顶");
            }else{
                tui_guang_btn.setText("申请置顶");
            }
        }else{
            tui_guang_btn.setVisibility(View.GONE);
        }
    }

    private ImageCycleView.ImageCycleViewListener mAdCycleViewListener = new ImageCycleView.ImageCycleViewListener() {

        @Override
        public void onImageClick(ADInfo info, int position, View imageView) {
//            Toast.makeText(this, "content->" + info.getContent(), Toast.LENGTH_SHORT).show();
        }

        @Override
        public void displayImage(String imageURL, ImageView imageView) {
            Tools.loadImg(GongQiuInfoActivity.this,imageURL, imageView,
                    Constant.getSimpleDisplayImage(R.mipmap.default_head_bg),null,R.mipmap.default_head_bg);// 使用ImageLoader对图片进行加装！
        }
    };

    @Override
    protected void onResume() {
        super.onResume();
        mAdView.startImageCycle();
    };

    @Override
    protected void onPause() {
        super.onPause();
        mAdView.pushImageCycle();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mAdView.pushImageCycle();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.backBtn:
                this.finish();
                break;
            case R.id.site_IB:
                Intent intent=new Intent(this,BaiduMapActivity.class);
                BaiduMapVo vo=new BaiduMapVo();
                vo.setCoordinate(curVo.getCoordinate());
                vo.setCompanyName(curVo.getCompanyName());
                vo.setType(type);
                vo.setAddrStr(curVo.getAddress());
                intent.putExtra("mapVo",vo);
                intent.putExtra("type",2);
                this.startActivity(intent);
                break;
            case R.id.addBtn:
//                foucsHandler();
                AddPopWindow addPopWindow = new AddPopWindow(this,curId,type,curVo);
                addPopWindow.showPopupWindow(addBtn);
                break;
            case R.id.tui_guang_btn:
                if(tui_guang_btn.getText().equals("申请置顶")) {
                    new AlertDialog(GongQiuInfoActivity.this).builder().setTitle("置顶提示")
                            .setMsg("置顶的供求信息会默认显示在前三条，并特殊显示，详情可致电我们的客服：13345086668")
                            .setPositiveButton("电话沟通", new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    phoneHandler();
                                }
                            }).setNegativeButton("随便逛逛", new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                }
                            }).show();
                }else{
                    ToastUtil.showToast(this,"您的信息已经被置顶");
                }
                //ToastUtil.showToast(this,"推广成功将在20天后展示在热点推荐中");
                break;
            case R.id.phoneBtn:
                new AlertDialog(this).builder().setTitle("联系商家")
                        .setMsg(curVo.getPhone()+"\n\n废废网竭诚为您服务")
                        .setPositiveButton("确定", new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                phoneHandler();
                            }
                        }).setNegativeButton("取消", new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {

                            }
                        }).show();
                break;
            case R.id.rb1:
                content_LL.setVisibility(View.VISIBLE);
                content1_LL.setVisibility(View.GONE);
                content2_LL.setVisibility(View.GONE);
                break;
            case R.id.rb2:
                content_LL.setVisibility(View.GONE);
                content1_LL.setVisibility(View.VISIBLE);
                content2_LL.setVisibility(View.GONE);
                break;
            case R.id.rb3:
                content_LL.setVisibility(View.GONE);
                content1_LL.setVisibility(View.GONE);
                content2_LL.setVisibility(View.VISIBLE);
                break;

        }
    }

//    private void tuiGuangHandler(){
//        if(curVo.getTitle()==null||curVo.getTitle().isEmpty()||
//                curVo.getPhone()==null||curVo.getPhone().isEmpty()
//                ||curVo.getAddress()==null||curVo.getAddress().isEmpty()||
//                curVo.getContent()==null||curVo.getContent().isEmpty()||
//                curVo.getUrlArr().length<1){
//            ToastUtil.showToast(this, "推广的产品必须资料完整,请重新发布");
//            return;
//        }
//
//        RequestParams params=new RequestParams();
//        params.put("userId",application.getUserId(this));
//        params.put("type", String.valueOf(type));
//        params.put("sId", curId);
//        HttpUtil.post(Config.addHotchooseInfo, params, new AsyncHttpResponseHandler() {
//            @Override
//            public void onFailure(Throwable error, String content) {
//                super.onFailure(error, content);
//                ToastUtil.showToast(GongQiuInfoActivity.this, content);
//            }
//
//            @Override
//            public void onSuccess(String content) {
//                super.onSuccess(content);
//
//                JSONObject jsonObject = null;
//                try {
//                    jsonObject = new JSONObject(content);
//                    byte isSuc = Byte.parseByte(jsonObject.getString("isSuc"));
//                    String msg = jsonObject.getString("msg");
//                    if (isSuc == 0) {
//                        ToastUtil.showToast(GongQiuInfoActivity.this, msg);
//                    } else {
//                        int num = jsonObject.getInt("num");
//                        if (num > 0) {
//                            new AlertDialog(GongQiuInfoActivity.this).builder().setTitle("推广提示")
//                                    .setMsg("您的前面还有 " + num + " 条信息排队，预计 " + (num * 3) + " 天后，您的信息将在首页推广。如需立即响应到首页推广，可致电我们的客服：13345086668")
//                                    .setPositiveButton("电话沟通", new View.OnClickListener() {
//                                        @Override
//                                        public void onClick(View v) {
//                                            phoneHandler();
//                                        }
//                                    }).setNegativeButton("排队等待", new View.OnClickListener() {
//                                @Override
//                                public void onClick(View v) {
//                                }
//                            }).show();
//
//                        } else {
//                            new AlertDialog(GongQiuInfoActivity.this).builder().setTitle("推广提示")
//                                    .setMsg("已将您的信息添加到首页推广，3天后将自动下架，需要再次点击推广，进行排队，如需长期推广，可致电我们的客服：13345086668")
//                                    .setPositiveButton("电话沟通", new View.OnClickListener() {
//                                        @Override
//                                        public void onClick(View v) {
//                                            phoneHandler();
//                                        }
//                                    }).setNegativeButton("排队等待", new View.OnClickListener() {
//                                @Override
//                                public void onClick(View v) {
//                                }
//                            }).show();
//                        }
//
//                        curVo.setGongQiuType(2);
//                        updateGongQiuType(curVo);
//                    }
//                } catch (JSONException e) {
//                    e.printStackTrace();
//                }
//
//            }
//        });
//    }

    private void phoneHandler(){
        Intent intent = new Intent(Intent.ACTION_CALL);
        Uri data = Uri.parse("tel:" + curVo.getPhone());
        intent.setData(data);
        startActivity(intent);
    }


    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        ListView listView = (ListView) parent;
        OtherGongQiuVO vo = (OtherGongQiuVO) listView.getItemAtPosition(position);
//        Intent intent=new Intent(this,GongQiuInfoActivity.class);
//        intent.putExtra("sId",vo.getId());
//        intent.putExtra("type",type);
//        startActivity(intent);
        curId=vo.getId();
        this.initData();
    }


}
