package com.newcolor.qixinginfo.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.global.Config;
import com.newcolor.qixinginfo.global.Constant;
import com.newcolor.qixinginfo.global.MyApplication;
import com.newcolor.qixinginfo.http.AsyncHttpResponseHandler;
import com.newcolor.qixinginfo.http.RequestParams;
import com.newcolor.qixinginfo.manager.ScreenManager;
import com.newcolor.qixinginfo.ui.cycleviewpager.ADInfo;
import com.newcolor.qixinginfo.ui.cycleviewpager.ImageCycleView;
import com.newcolor.qixinginfo.util.HttpUtil;
import com.newcolor.qixinginfo.util.IntentUtil;
import com.newcolor.qixinginfo.util.SharedUtil;
import com.newcolor.qixinginfo.util.Tools;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * 欢迎界面
 *
 * Created by Administrator on 2016/1/29.
 */
public class WelcomeActivity extends Activity implements View.OnClickListener {
    private MyApplication application;
    private ImageCycleView ad_view;
    private Button enterBtn;
    private ArrayList<ADInfo> infos = new ArrayList<ADInfo>();

    private final static String defaultImage="";
    private String[] imageUrls = {defaultImage};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
        application = (MyApplication) getApplication();
        ScreenManager.getInstance().pushActivity(this);

        boolean isFirstStart= Constant.isAppFirst;//SharedUtil.getBoolean(this,Constant.ISFIRSTSTART,true);
        if(isFirstStart) {
            ad_view = (ImageCycleView) this.findViewById(R.id.ad_view);
            enterBtn = (Button) this.findViewById(R.id.enterBtn);
            enterBtn.setOnClickListener(this);
            if(!IntentUtil.isConnect(this)||IntentUtil.getNetType(this)!= IntentUtil.Type._WIFI) {
                this.gotoMain();
            }else{
                this.getUrls();
            }
        }else{
            this.gotoMain();
        }
    }

    private void getUrls(){
        HttpUtil.get(Config.getWelcomeUrls, new RequestParams(), new AsyncHttpResponseHandler() {
            @Override
            public void onFailure(Throwable error, String content) {
                gotoMain();
            }

            @Override
            public void onSuccess(String content) {
                super.onSuccess(content);


                JSONArray jsArr = null;
                try {
                    jsArr = new JSONArray(content);

                    if (jsArr.length() < 1) {
                        addImgInfo(defaultImage, "");
                    } else {
                        for (int i = 0; i < jsArr.length(); i++) {
                            JSONObject jsOb = jsArr.getJSONObject(i);
                            addImgInfo(jsOb.getString("url"), "");
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                ad_view.setImageResources(infos, mAdCycleViewListener);
                handler.postDelayed(runnable, 8000);
                Constant.isAppFirst = false;
            }
        });
    }


    private void addImgInfo(String url,String content){
        ADInfo info = new ADInfo();
        info.setUrl(url);
        info.setContent(content);
        infos.add(info);
    }


    Handler handler = new Handler();
    Runnable runnable = new Runnable() {
        @Override
        public void run() {
            gotoMain();
        }
    };

    private ImageCycleView.ImageCycleViewListener mAdCycleViewListener = new ImageCycleView.ImageCycleViewListener() {

        @Override
        public void onImageClick(ADInfo info, int position, View imageView) {
//            Toast.makeText(this, "content->" + info.getContent(), Toast.LENGTH_SHORT).show();
        }

        @Override
        public void displayImage(String imageURL, ImageView imageView) {
//            ImageLoader.getInstance().displayImage(imageURL, imageView,Constant.propagandaOptions);// 使用ImageLoader对图片进行加装！
            Tools.loadImg(WelcomeActivity.this, imageURL, imageView, null, null, R.mipmap.default_head_bg);
        }
    };


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.enterBtn:
                this.gotoMain();
                break;
        }
    }

    private void gotoMain(){
        Intent intent =new Intent(this,MainActivity.class);
        intent.putExtra("index",1);
        startActivity(intent);
        handler.removeCallbacks(runnable);
        this.finish();
    }
}

