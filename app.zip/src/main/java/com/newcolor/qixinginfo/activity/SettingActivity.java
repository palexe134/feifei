package com.newcolor.qixinginfo.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.adapter.MeAdapter;
import com.newcolor.qixinginfo.dialog.AlertDialog;
import com.newcolor.qixinginfo.global.MyApplication;
import com.newcolor.qixinginfo.manager.ScreenManager;
import com.newcolor.qixinginfo.model.MeVO;
import com.newcolor.qixinginfo.util.DataCleanUtil;
import com.newcolor.qixinginfo.util.LoginUtil;
import com.newcolor.qixinginfo.util.SharedUtil;
import com.newcolor.qixinginfo.util.ToastUtil;
import com.newcolor.qixinginfo.util.Tools;
import com.newcolor.qixinginfo.version.DownloadManager;

import java.util.ArrayList;

import cn.sharesdk.framework.ShareSDK;
import cn.sharesdk.onekeyshare.OnekeyShare;
import cn.sharesdk.onekeyshare.OnekeyShareTheme;

/**
 * 设置界面
 *
 * Created by Administrator on 2015/10/17.
 */
public class SettingActivity extends Activity implements View.OnClickListener,AdapterView.OnItemClickListener {
    private MyApplication application;
    private FrameLayout login_title;
    private TextView tv;
    private ImageButton backBtn;
    private ListView mListView;
    private MeAdapter mAdapter;
    private Button cancleBtn,exitBtn;
    private ArrayList<MeVO> mListItems;
    private static final int[] viewIdArr={R.id.img_IV,R.id.name_TV};
    private static final String[] titleArr={"个人资料","重置密码","清除缓存","separator","关于我们","版本检测(4.0.0)"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_setting);
        application = (MyApplication)getApplication();
        ScreenManager.getInstance().pushActivity(this);

        init();
    }



    private void init(){
        login_title=(FrameLayout) this.findViewById(R.id.setting_title);

        tv = (TextView) login_title.findViewById(R.id.titleTv);
        tv.setText("个人设置");
        backBtn= (ImageButton) login_title.findViewById(R.id.backBtn);
        cancleBtn= (Button) this.findViewById(R.id.cancleBtn);
        exitBtn= (Button) this.findViewById(R.id.exitBtn);

        backBtn.setOnClickListener(this);
        exitBtn.setOnClickListener(this);
        cancleBtn.setOnClickListener(this);

        this.initData();

        mAdapter=new MeAdapter(this,mListItems,viewIdArr);

        mListView= (ListView) this.findViewById(R.id.data_LV);
        mListView.setAdapter(mAdapter);

        mListView.setOnItemClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.registerTxt:
                Intent intent= new Intent(this,RegisterActivity.class);
                intent.putExtra("type", RegisterActivity.RegisterType);
                startActivity(intent);
                break;
            case R.id.backBtn:
                this.finish();
                break;
            case R.id.cancleBtn:
                SharedUtil.clearLoginParams(this);
                application.setUserId("-1");
                application.setCurUserVo(null);
                this.finish();
                intent =new Intent(this,LoginActivity.class);
                startActivity(intent);

                break;
            case R.id.exitBtn:
                ScreenManager.getInstance().popAllActivity();
                break;


        }
    }

    private void initData(){
        mListItems=new ArrayList<MeVO>();
        MeVO vo;
        for(int i=0;i<titleArr.length;i++){
            vo=new MeVO();
            vo.setName(titleArr[i]);
            vo.setIconId(0);
            mListItems.add(vo);
        }
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        switch (position) {
            case 0:
                if(application.getUserId(this).equals("-1")){
                    LoginUtil.gotoLogin(this);
                    return;
                }
                Intent intent = new Intent(this, PersonalInfoActivity.class);
                intent.putExtra("type", 1);
                startActivity(intent);
                break;
            case 1:
                intent= new Intent(this,RegisterActivity.class);
                intent.putExtra("type", RegisterActivity.FindPasswordType);
                startActivity(intent);
                break;
            case 2:
                new AlertDialog(this).builder().setTitle("清除缓存")
                        .setMsg("确定要清除缓存吗？")
                        .setPositiveButton("确定", new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                DataCleanUtil.cleanApplicationData(SettingActivity.this);
                                ToastUtil.showToast(SettingActivity.this,"缓存清除完毕");
                            }
                        }).setNegativeButton("取消", new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {

                            }
                        }).show();
                break;
            case 4:
                intent= new Intent(this,AboutActivity.class);
                startActivity(intent);
                break;
            case 5:
                DownloadManager downManger = new DownloadManager(this,true);
                downManger.checkDownload(new DownloadManager.CallBackHandler() {
                    @Override
                    public void onCallBack() {
//                      init();
                    }
                });
                break;
        }
    }



}
