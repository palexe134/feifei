package com.newcolor.qixinginfo.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.TextView;

import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.global.Config;
import com.newcolor.qixinginfo.global.MyApplication;
import com.newcolor.qixinginfo.http.AsyncHttpResponseHandler;
import com.newcolor.qixinginfo.http.RequestParams;
import com.newcolor.qixinginfo.manager.ScreenManager;
import com.newcolor.qixinginfo.ui.editortxt.SearchEditText;
import com.newcolor.qixinginfo.util.HttpUtil;
import com.newcolor.qixinginfo.util.LoginUtil;
import com.newcolor.qixinginfo.util.ToastUtil;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * 意见反馈界面
 *
 * Created by Administrator on 2015/10/9.
 */
public class OpinionActivity extends Activity implements View.OnClickListener {
    private MyApplication application;

    private EditText content_TV = null;
    private SearchEditText phone_ET = null;
    private FrameLayout login_title;
    private TextView tv;
    private Button subBtn;
    private ImageButton backBtn;
    private int type;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_opinion);
        application = (MyApplication)getApplication();
        ScreenManager.getInstance().pushActivity(this);
        init();
    }



    private void init(){
        login_title=(FrameLayout) this.findViewById(R.id.login_title);

        tv = (TextView) login_title.findViewById(R.id.titleTv);
        backBtn= (ImageButton) login_title.findViewById(R.id.backBtn);
        subBtn= (Button) this.findViewById(R.id.subBtn);
        content_TV= (EditText) this.findViewById(R.id.content_TV);
        phone_ET= (SearchEditText) this.findViewById(R.id.phone_ET);

        Intent intent=this.getIntent();
        if(intent!=null){
            type=intent.getIntExtra("type",0);
        }
        if(type==1){
            tv.setText("申请开户");
            content_TV.setHint("手续费最低，请输入您的手机号和姓名，我们将第一时间与您取得联系.");
        }else {
            tv.setText("意见反馈");
            content_TV.setHint("请输入您的宝贵意见，我们将会做的更好！");
        }

        backBtn.setOnClickListener(this);
        subBtn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.subBtn:
                this.opinionHandler();
                break;
            case R.id.backBtn:
                this.finish();
                break;

        }
    }

    private void opinionHandler(){
        RequestParams params=new RequestParams();
        params.put("userId",application.getUserId(this));
        params.put("phone",phone_ET.getText().toString());
        params.put("content", content_TV.getText().toString());

        if(phone_ET.getText().toString().isEmpty()){
            ToastUtil.showToast(this,"电话不能为空");
            return;
        }

        if(content_TV.getText().toString().isEmpty()){
            ToastUtil.showToast(this,"反馈内容不能为空");
            return;
        }

        HttpUtil.get(Config.userOpinion,params,new AsyncHttpResponseHandler(){
            @Override
            public void onSuccess(String content) {
                super.onSuccess(content);

                JSONObject jsonObject= null;
                try {
                    jsonObject = new JSONObject(content);
                    byte isSuc= Byte.parseByte(jsonObject.getString("isSuc"));
                    if(isSuc==0){
                        String msg=jsonObject.getString("msg");
                        ToastUtil.showToast(OpinionActivity.this,msg);
                    }else{
                        finish();
                        ToastUtil.showToast(OpinionActivity.this,"意见反馈成功");
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Throwable error, String content) {
                super.onFailure(error, content);
                ToastUtil.showToast(OpinionActivity.this,content);
            }
        });
    }
}
