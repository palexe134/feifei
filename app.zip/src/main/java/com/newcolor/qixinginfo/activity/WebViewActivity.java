package com.newcolor.qixinginfo.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.global.MyApplication;
import com.newcolor.qixinginfo.manager.ScreenManager;

/**
 * activity直接嵌入网页，只需在intent中传入url，可以显示,通用模板
 *
 * Created by Administrator on 2015/10/30.
 */
public class WebViewActivity extends Activity implements View.OnClickListener {
    private MyApplication application;
    private FrameLayout wb_title;
    private TextView tv;
    private ImageButton backBtn;
    private LinearLayout wb_menu;
    private ImageView goBack,goForward,reload;
    private WebView webview;
    private String webUrl="http://www.51cto.com/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_webview);
        application = (MyApplication)getApplication();
        ScreenManager.getInstance().pushActivity(this);

        Intent intent=this.getIntent();
        if(intent!=null){
            webUrl=intent.getStringExtra("webUrl");
        }

        wb_title=(FrameLayout) this.findViewById(R.id.wb_title);
        wb_menu= (LinearLayout) this.findViewById(R.id.wb_menu);
        webview= (WebView) this.findViewById(R.id.webview);
        //设置WebView属性，能够执行Javascript脚本
        webview.getSettings().setJavaScriptEnabled(true);
        //加载需要显示的网页
        webview.loadUrl(webUrl);
        //设置Web视图
        webview.setWebViewClient(new HelloWebViewClient ());

        goBack= (ImageView) wb_menu.findViewById(R.id.goBack);
        goForward= (ImageView) wb_menu.findViewById(R.id.goForward);
        reload= (ImageView) wb_menu.findViewById(R.id.reload);

        tv = (TextView) wb_title.findViewById(R.id.titleTv);
        tv.setText("有奖分享");
        backBtn= (ImageButton) wb_title.findViewById(R.id.backBtn);

        backBtn.setOnClickListener(this);
        goBack.setOnClickListener(this);
        goForward.setOnClickListener(this);
        reload.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.backBtn:
                this.finish();
                break;
            case R.id.reload:
                webview.reload();
                break;
            case R.id.goBack:
                webview.goBack();
                break;
            case R.id.goForward:
                webview.goForward();
                break;
        }
    }

    @Override
    //设置回退
    //覆盖Activity类的onKeyDown(int keyCoder,KeyEvent event)方法
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if ((keyCode == KeyEvent.KEYCODE_BACK) && webview.canGoBack()) {
            webview.goBack(); //goBack()表示返回WebView的上一页面
            return true;
        }
        return false;
    }

    //Web视图
    private class HelloWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }
    }


}
