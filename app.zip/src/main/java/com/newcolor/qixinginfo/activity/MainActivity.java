package com.newcolor.qixinginfo.activity;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.fragment.GongQiuFragment;
import com.newcolor.qixinginfo.fragment.HomePageFragment;
import com.newcolor.qixinginfo.fragment.MeFragment;
import com.newcolor.qixinginfo.fragment.NewMsgFragment;
import com.newcolor.qixinginfo.global.Constant;
import com.newcolor.qixinginfo.global.MyApplication;
import com.newcolor.qixinginfo.manager.ScreenManager;
import com.newcolor.qixinginfo.ui.badge.BadgeView;
import com.newcolor.qixinginfo.util.DealUtil;
import com.newcolor.qixinginfo.util.IntentUtil;
import com.newcolor.qixinginfo.util.LoginUtil;
import com.newcolor.qixinginfo.util.SharedUtil;
import com.newcolor.qixinginfo.util.Tools;
import com.newcolor.qixinginfo.version.DownloadManager;

import java.util.ArrayList;

import cn.jpush.android.api.JPushInterface;
import cn.sharesdk.framework.ShareSDK;

/**
 * 主界面
 */
public class MainActivity extends FragmentActivity{

    private Fragment[] mFragments;
    private RadioGroup bottomRg;
//    private FragmentManager fragmentManager;
//    private FragmentTransaction fragmentTransaction;
    private RadioButton rbOne, rbTwo, rbThree, rbFour,rbFive;
    private Boolean isExit = false;
    private Button bt3;
    private int index=1,prevIndex=0;
    private ArrayList<RadioButton> radioArr;
    private  BadgeView badge;

    private MyApplication application;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_main);

        ScreenManager.getInstance().pushActivity(this);


        bottomRg = (RadioGroup) findViewById(R.id.bottomRg);
        rbOne = (RadioButton) findViewById(R.id.rbOne);
//        rbTwo = (RadioButton) findViewById(R.id.rbTwo);
        rbThree = (RadioButton) findViewById(R.id.rbThree);
        rbFour = (RadioButton) findViewById(R.id.rbFour);
        rbFive = (RadioButton) findViewById(R.id.rbFive);

        radioArr=new ArrayList<RadioButton>();
        radioArr.add(rbOne);
//        radioArr.add(rbTwo);
        radioArr.add(rbThree);
        radioArr.add(rbFour);
        radioArr.add(rbFive);

        bt3= (Button) findViewById(R.id.bt3);

        badge= new BadgeView(this);
        badge.setEnabled(false);
        badge.setTargetView(bt3);
        badge.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.ITALIC));
        badge.setShadowLayer(2, -1, -1, Color.GREEN);
        badge.setBadgeGravity(Gravity.TOP | Gravity.RIGHT);
        badge.setBadgeMargin(0, 0, 20, 0);
        badge.setBadgeCount(SharedUtil.getInt(this,"newYingYongNum"));
        badge.setVisibility(View.GONE);

//        mFragments = new Fragment[4];
//        fragmentManager = getSupportFragmentManager();
//        mFragments[0] = fragmentManager.findFragmentById(R.id.fragement_gongqiu);
//        mFragments[1] = fragmentManager.findFragmentById(R.id.fragement_app);
//        mFragments[2] = fragmentManager.findFragmentById(R.id.fragement_msg);
//        mFragments[3] = fragmentManager.findFragmentById(R.id.fragement_me);
//
//        fragmentTransaction = fragmentManager.beginTransaction()
//                .hide(mFragments[0]).hide(mFragments[1])
//                .hide(mFragments[2]).hide(mFragments[3]);

        if(IntentUtil.isConnect(this)) {
            DownloadManager downManger = new DownloadManager(this, false);
            downManger.checkDownload(new DownloadManager.CallBackHandler() {
                @Override
                public void onCallBack() {
                    init();
                }
            });
        }else{

            new Handler().postDelayed(new Runnable() {
                public void run() {
                    init();
                }
            }, 300);
        }
    }

    private void init(){
        this.checkLogin();

        Intent intent=this.getIntent();
        if(intent!=null){
            index=intent.getIntExtra("index",1);
        }
        setFragmentIndicator();
        this.openHandler(index);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        index=intent.getIntExtra("index",1);
        this.openHandler(index);
    }

    private void openHandler(int index){
//        fragmentTransaction = fragmentManager.beginTransaction()
//                .hide(mFragments[0]).hide(mFragments[1])
//                .hide(mFragments[2]).hide(mFragments[3]);
//        fragmentTransaction.show(mFragments[index]).commitAllowingStateLoss();
        if(this.prevIndex==index){
            return;
        }

        this.prevIndex=index;
        Fragment df;
        if(index==0) {
            df = new GongQiuFragment();
        }
//        else if(index==1) {
//            df = new AppFragment();
//        }
        else if(index==1) {
            df = new NewMsgFragment();
        }else if(index==2){
            df = new MeFragment();
        }else{
            df = new HomePageFragment();
        }
        //获取FragmentTransaction 实例
        FragmentTransaction ft = this.getSupportFragmentManager().beginTransaction();
        //使用DetailsFragment 的实例
        ft.replace(R.id.detials, df);
        ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
        ft.commitAllowingStateLoss();
        radioArr.get(index).setChecked(true);

    }

    private void checkLogin(){
        String mStr_name= SharedUtil.getString(this, Constant.USERNAMECOOKIE);
        String mStr_pwd=SharedUtil.getString(this,Constant.USERPASSWORDCOOKIE);
        if(mStr_name!=null && mStr_pwd!=null && !mStr_name.isEmpty()&&!mStr_pwd.isEmpty()){
            LoginUtil.gotoLogin(this, SharedUtil.getString(this, Constant.USERNAMECOOKIE)
                    , SharedUtil.getString(this, Constant.USERPASSWORDCOOKIE), null);
        }
    }


    private void setFragmentIndicator() {
        bottomRg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId){
                    case R.id.rbOne:
                        openHandler(0);
                        break;
//                    case R.id.rbTwo:
//                        openHandler(1);
//                        break;
                    case R.id.rbThree:
                        openHandler(1);
                        break;
                    case R.id.rbFour:
                        openHandler(2);
                        break;
                    case R.id.rbFive:
                        openHandler(3);
                        break;
                }
//                fragmentTransaction = fragmentManager.beginTransaction()
//                        .hide(mFragments[0]).hide(mFragments[1])
//                        .hide(mFragments[2]).hide(mFragments[3]);
//                switch (checkedId) {
//                    case R.id.rbOne:
//                        fragmentTransaction.show(mFragments[0]).commitAllowingStateLoss();
//                        break;
//
//                    case R.id.rbTwo:
////                          openMsg();
//                        fragmentTransaction.show(mFragments[1]).commitAllowingStateLoss();
//                        break;
//
//                    case R.id.rbThree:
//                        fragmentTransaction.show(mFragments[2]).commitAllowingStateLoss();
//                        break;
//                    case R.id.rbFour:
//                        fragmentTransaction.show(mFragments[3]).commitAllowingStateLoss();
//                        break;
//
//                    default:
//                        break;
//                }
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        JPushInterface.onResume(this);

//        this.newGongNeng();
    }

    @Override
    protected void onPause() {
        super.onPause();
        JPushInterface.onPause(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    };


    private void newGongNeng(){
        if(badge==null){
            return;
        }
        if(SharedUtil.getInt(this,"newYingYongNum")>0) {
            badge.setVisibility(View.VISIBLE);
        } else{
            badge.setVisibility(View.GONE);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
//        super.onSaveInstanceState(outState);
    }
}
