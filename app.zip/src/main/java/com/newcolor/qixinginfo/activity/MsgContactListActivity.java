package com.newcolor.qixinginfo.activity;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.adapter.MsgContactAdapter;
import com.newcolor.qixinginfo.dialog.AlertDialog;
import com.newcolor.qixinginfo.global.Config;
import com.newcolor.qixinginfo.global.MyApplication;
import com.newcolor.qixinginfo.http.AsyncHttpResponseHandler;
import com.newcolor.qixinginfo.http.RequestParams;
import com.newcolor.qixinginfo.model.MsgContactVO;
import com.newcolor.qixinginfo.ui.pullrefresh.PullToRefreshBase;
import com.newcolor.qixinginfo.ui.pullrefresh.PullToRefreshListView;
import com.newcolor.qixinginfo.util.DateUtils;
import com.newcolor.qixinginfo.util.HttpUtil;

import java.util.ArrayList;

/**
 * 谁看过我界面
 *
 * Created by Administrator on 2015/10/26.
 */
public class MsgContactListActivity extends Activity implements View.OnClickListener, AdapterView.OnItemClickListener, MsgContactAdapter.Callback {
    private TextView tv;
    private FrameLayout contact_list_title;
    private MyApplication application;

    private ListView mListView;
    private PullToRefreshListView mPullListView;
    private MsgContactAdapter mAdapter;
    private ArrayList<MsgContactVO> mListItems;
    private int mCurIndex = 0;
    private static final int mLoadDataCount = 20;
    private ImageButton backBtn;
    private boolean isChange=false;
    private static final int[] viewIdArr={R.id.itemImage,R.id.name_TV,R.id.phone_TV,R.id.phoneBtn};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        application = (MyApplication)this.getApplication();
        setContentView(R.layout.activity_msg_contact_list);

        contact_list_title=(FrameLayout) this.findViewById(R.id.msg_contact_title);

        tv = (TextView) contact_list_title.findViewById(R.id.titleTv);
        tv.setText("谁看过我");
        backBtn = (ImageButton) contact_list_title.findViewById(R.id.backBtn);
        backBtn.setOnClickListener(this);

        //定义下拉刷新
        mPullListView=(PullToRefreshListView) this.findViewById(R.id.msgPullListView);
        mPullListView.setPullLoadEnabled(false);
        mPullListView.setScrollLoadEnabled(true);

        mListItems = new ArrayList<MsgContactVO>();

        mAdapter = new MsgContactAdapter(this,mListItems,R.layout.item_list_msg_contact,viewIdArr,this);
        mListView = mPullListView.getRefreshableView();
        mListView.setAdapter(mAdapter);
        mListView.setOnItemClickListener(this);

        mPullListView.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener<ListView>() {
            @Override
            public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {
                initData();
            }

            @Override
            public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {
                initData();
            }
        });
        setLastUpdateTime();
    }

    @Override
    public void onResume() {
        super.onResume();
        this.flushData(true);
    }

    public void flushData(boolean isChange){
        this.isChange=isChange;
        mCurIndex=0;
        mPullListView.doPullRefreshing(true, 500);
    }

    /**
     * 初始化数据
     */
    private void initData(){
        RequestParams params=new RequestParams();
        params.put("userId", application.getUserId(this));
        params.put("curSize",String.valueOf(mCurIndex));
        params.put("count",String.valueOf(mLoadDataCount));
        HttpUtil.get(Config.whoSeenMeList, params, new AsyncHttpResponseHandler() {
            Boolean isHasMore = false;

            @Override
            public void onFailure(Throwable error, String content) {
                super.onFailure(error, content);
            }

            @Override
            public void onSuccess(String content) {
                if(content.equals("")||content.indexOf("\"isSuc\":0")>=0){
                    return;
                }
                super.onSuccess(content);
                ArrayList<MsgContactVO> arrayList = (ArrayList<MsgContactVO>) JSON.parseArray(content,MsgContactVO.class);

                if (isChange) {
                    mListItems.clear();
                    isChange = false;
                }

                if (arrayList != null) {
                    mListItems.addAll(arrayList);
                    mCurIndex++;
                    if (arrayList.size() < mLoadDataCount) {
                        isHasMore = false;
                    } else {
                        isHasMore = true;
                    }
                }

                mAdapter.notifyDataSetChanged();
                mPullListView.onPullDownRefreshComplete();
                mPullListView.onPullUpRefreshComplete();
                mPullListView.setHasMoreData(false);
                setLastUpdateTime();
            }
        });


        /*MsgContactVO vo;
        for(int i=0;i<10;i++){
            vo=new MsgContactVO();
            vo.setName("王小二");
            vo.setPhone("15953981811");
            vo.setIconUrl("");
            mListItems.add(vo);
        }*/


    }

    private void setLastUpdateTime() {
        String text = DateUtils.formatSimpleDateTime(System.currentTimeMillis());
        mPullListView.setLastUpdatedLabel(text);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.backBtn:
                this.finish();
                break;
        }
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void click(View v) {
        final MsgContactVO vo = (MsgContactVO) v.getTag();
        switch (v.getId()) {
            case R.id.phoneBtn:
                new AlertDialog(this).builder().setTitle("联系商家")
                        .setMsg(vo.getPhone()+"\n\n废废网竭诚为您服务")
                        .setPositiveButton("确定", new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                phoneHandler(vo);
                            }
                        }).setNegativeButton("取消", new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                    }
                }).show();
                break;
        }
    }

    private void phoneHandler(MsgContactVO vo){
        Intent intent = new Intent(Intent.ACTION_CALL);
        Uri data = Uri.parse("tel:" + vo.getPhone());
        intent.setData(data);
        startActivity(intent);
    }
}
