package com.newcolor.qixinginfo.ui.pullrefresh.swipemenulistview;

public interface SwipeMenuCreator {

    void create(SwipeMenu menu);
}
