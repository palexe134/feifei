package com.newcolor.qixinginfo.ui.picher;

import android.app.DatePickerDialog;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;

/**
 * 日期选择器
 *
 * Created by baolei.si on 2015/9/8.
 */
public class TimePickerDialog extends DatePickerDialog {
    private int chartType;

    public TimePickerDialog(Context context, OnDateSetListener callBack, int year, int monthOfYear, int dayOfMonth, int chartType) {
        super(context, callBack, year, monthOfYear, dayOfMonth);

        this.chartType=chartType;

        ViewGroup group=((ViewGroup) ((ViewGroup) this.getDatePicker().getChildAt(0)).getChildAt(0));
        if(chartType==1) {
            group.getChildAt(1).setVisibility(View.GONE);
            group.getChildAt(2).setVisibility(View.GONE);
            this.setTitle(year + "年");
        }else if(chartType==2){
            group.getChildAt(2).setVisibility(View.GONE);
            this.setTitle(year + "年" + (monthOfYear + 1) + "月");
        }else{
            this.setTitle(year + "年" + (monthOfYear + 1) + "月"+dayOfMonth+"日");
        }
    }

    @Override
    public void onDateChanged(DatePicker view, int year, int month, int day) {
        super.onDateChanged(view, year, month, day);
        this.setTitle(year + "年" + (month + 1) + "月");

        if(chartType==1) {
            this.setTitle(year + "年");
        }else if(chartType==2){
            this.setTitle(year + "年" + (month + 1) + "月");
        }else{
            this.setTitle(year + "年" + (month + 1) + "月"+day+"日");
        }
    }

}