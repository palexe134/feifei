package com.newcolor.qixinginfo.fragment;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.RelativeLayout;

import com.activeandroid.ActiveAndroid;
import com.alibaba.fastjson.JSON;
import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.adapter.SubscribeAdapter;
import com.newcolor.qixinginfo.dialog.AlertDialog;
import com.newcolor.qixinginfo.global.Config;
import com.newcolor.qixinginfo.global.Constant;
import com.newcolor.qixinginfo.global.MyApplication;
import com.newcolor.qixinginfo.http.AsyncHttpResponseHandler;
import com.newcolor.qixinginfo.http.RequestParams;
import com.newcolor.qixinginfo.manager.ScreenManager;
import com.newcolor.qixinginfo.model.ContactVO;
import com.newcolor.qixinginfo.model.Msg;
import com.newcolor.qixinginfo.ui.pullrefresh.PullToRefreshBase;
import com.newcolor.qixinginfo.ui.pullrefresh.PullToRefreshListView;
import com.newcolor.qixinginfo.util.DBUtil;
import com.newcolor.qixinginfo.util.DateUtils;
import com.newcolor.qixinginfo.util.DealUtil;
import com.newcolor.qixinginfo.util.HttpUtil;
import com.newcolor.qixinginfo.util.IntentUtil;
import com.newcolor.qixinginfo.util.SharedUtil;
import com.newcolor.qixinginfo.util.ToastUtil;
import com.newcolor.qixinginfo.util.Tools;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 订阅信息fragment
 *
 * Created by Administrator on 2015/11/27.
 */
public class SubscribeFragment extends Fragment implements View.OnClickListener, AdapterView.OnItemLongClickListener{
    private MyApplication application;
    private PullToRefreshListView scrollView;
    private ArrayList<Msg> mListItems;
    private SubscribeAdapter mAdapter;
    private ListView mListView;
    private boolean isChange=false;
    private int mCurIndex = 0;
    private RelativeLayout ctr_box;
    private Button deletBtn,cancleBtn;
    private CheckBox all_CB;
    private ArrayList<Msg> selectArr;
    private static final int mLoadDataCount = 20;
    private static final int[] viewIdArr={R.id.tv_time,R.id.tv_content,R.id.select_CB,R.id.bg_RL};

    public static Handler handler;


    public static SubscribeFragment newInstance(int index) {
        // TODO Auto-generated method stub
        SubscribeFragment df=new SubscribeFragment();
        Bundle bundle=new Bundle();
        bundle.putInt("index", index);
        df.setArguments(bundle);
        return df;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.activity_subscribe, container, false);
        return view;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        application= (MyApplication) this.getActivity().getApplication();
        ScreenManager.getInstance().pushActivity(this.getActivity());

        selectArr=new ArrayList<Msg>();

        ctr_box= (RelativeLayout) this.getView().findViewById(R.id.ctr_box);
        deletBtn= (Button) this.getView().findViewById(R.id.deletBtn);
        cancleBtn= (Button) this.getView().findViewById(R.id.cancleBtn);
        all_CB= (CheckBox) this.getView().findViewById(R.id.all_CB);
        ctr_box.setVisibility(View.GONE);
        deletBtn.setOnClickListener(this);
        cancleBtn.setOnClickListener(this);
        all_CB.setOnClickListener(this);

        scrollView= (PullToRefreshListView) this.getView().findViewById(R.id.msgPullListView);

        mListItems = new ArrayList<Msg>();
        mAdapter = new SubscribeAdapter(this.getActivity(), mListItems, R.layout.item_list_subscribe, viewIdArr, new SubscribeAdapter.Callback() {
            @Override
            public void onSelectChange(View v) {
                Msg vo= (Msg) v.getTag();
                vo.setIsSelected(!vo.isSelected());
                if(!vo.isSelected()){
                    all_CB.setChecked(false);
                    selectArr.remove(vo);
                }else{
                    selectArr.add(vo);
                    if(selectArr.size()==mListItems.size()){
                        all_CB.setChecked(true);
                    }
                }
                mAdapter.notifyDataSetChanged();
            }
        });
        mListView = scrollView.getRefreshableView();
        mListView.setAdapter(mAdapter);
//        mListView.setOnItemClickListener(this);
        mListView.setOnItemLongClickListener(this);

        scrollView.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener<ListView>() {
            @Override
            public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {
                downHandler();
            }

            @Override
            public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {
                upHandler();
            }
        });
        setLastUpdateTime();

        handler= new Handler(){
            @Override
            public void handleMessage(Message msg) {
                if (msg.what == 1 && !SubscribeFragment.this.isHidden()) {
                    Bundle bundle=msg.getData();

                    Msg vo=bundle.getParcelable("msg");
                    mListItems.add(vo);

                    mAdapter.notifyDataSetChanged();
                }
            }

        };
    }


    @Override
    public void onResume() {
        super.onResume();
        flushData(true);
    }



    public void flushData(boolean isChange){
        this.isChange=isChange;
        mCurIndex=0;
//        mListItems.clear();
        scrollView.doPullRefreshing(true, 500);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.cancleBtn:
                this.cancleHandler();
                break;
            case R.id.deletBtn:
                this.deletHandler();

                break;
            case R.id.all_CB:
                this.updateSelect(all_CB.isChecked());
                break;
        }

    }


    private void deletHandler(){
        DBUtil.deletMsgs(selectArr);

        RequestParams params=new RequestParams();
        params.put("userId",application.getUserId(this.getActivity()));
        String idStr="";
        int i=0;
        for (Msg vo:selectArr){
            if(i<selectArr.size()-1){
                idStr+=vo.getsId()+",";
            }else{
                idStr+=vo.getsId();
            }
            i++;
        }
        params.put("sId", idStr);
        HttpUtil.get(Config.deleteSubInfo,params,new AsyncHttpResponseHandler(){
            @Override
            public void onFailure(Throwable error, String content) {
                super.onFailure(error, content);
                if(getActivity()==null)return;
                ToastUtil.showToast(SubscribeFragment.this.getActivity(),content);

                cancleHandler();
                flushData(true);
            }

            @Override
            public void onSuccess(String content) {
                super.onSuccess(content);
                if(getActivity()==null)return;

                JSONObject jsonObject= null;
                try {
                    jsonObject = new JSONObject(content);
                    byte isSuc= Byte.parseByte(jsonObject.getString("isSuc"));
                    if(isSuc==0){
                        String msg=jsonObject.getString("msg");
                        ToastUtil.showToast(SubscribeFragment.this.getActivity(),msg);
                    }else{
                        cancleHandler();
                        flushData(true);
                        ToastUtil.showToast(SubscribeFragment.this.getActivity(), "删除信息成功");
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    private void cancleHandler(){
        selectArr.clear();
        this.updateSelect(false);
        this.updateShow(false);
        all_CB.setChecked(false);
        ctr_box.setVisibility(View.GONE);
    }

    private void updateSelect(boolean isSelected){
        for (Msg vo:mListItems){
            vo.setIsSelected(isSelected);
            if(isSelected){
                selectArr.add(vo);
            }else{
                selectArr.remove(vo);
            }
        }
        mAdapter.notifyDataSetChanged();
    }

    private void updateShow(boolean isShow){
        for (Msg vo:mListItems){
            vo.setIsShow(isShow);
        }
        mAdapter.notifyDataSetChanged();
    }

    private void upHandler(){

    }

    private void downHandler(){
        if(ctr_box.getVisibility()==View.VISIBLE){
            scrollView.onPullDownRefreshComplete();
            scrollView.onPullUpRefreshComplete();
            ToastUtil.showToast(this.getActivity(),"您正在进行删除操作，不能执行刷新");
            return;
        }

        if(IntentUtil.isConnect(this.getActivity())&& !application.getUserId(this.getActivity()).equals("-1")){
            this.getMessageList();
        }else{
            int ps=0;
            if (isChange) {
                mListItems.clear();
            }
            List<Msg> list = DBUtil.getMsgList(1,mCurIndex,mLoadDataCount);
            Collections.reverse(list);
            mListItems.addAll(0, list);
            ps=list.size();
            updateFlag();

            mCurIndex++;

            mAdapter.notifyDataSetChanged();
            scrollView.onPullDownRefreshComplete();
            scrollView.onPullUpRefreshComplete();
            scrollView.setHasMoreData(false);
            setLastUpdateTime();

            if(!isChange){
                ps--;
            }
            isChange=false;
            mListView.setSelection(ps);
        }

//        mListItems.clear();
//        Msg vo = null;
//
//        for (int i = 0; i < 10; i++) {
//            vo=new Msg();
//            vo.setFlag(i%2);
//            vo.setMTime("2015.10.5 下午5点");
//            vo.setContent("...");
//            mListItems.add(0,vo);
//        }
//
//        mAdapter.notifyDataSetChanged();
//        scrollView.onPullDownRefreshComplete();
//        scrollView.onPullUpRefreshComplete();
//        scrollView.setHasMoreData(false);
//        mListView.setSelection(mListView.getBottom());
//        setLastUpdateTime();
    }


    private void getMessageList(){
        RequestParams rParams=new RequestParams();
        rParams.put("userId", application.getUserId(this.getActivity()));
        rParams.put("curSize",String.valueOf(mCurIndex));
        rParams.put("count",String.valueOf(mLoadDataCount));

        HttpUtil.get(Config.GetSubscribeMsgList, rParams, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(String response) {
                super.onSuccess(response);
                boolean hasMoreData = true;
                int ps=0;

                if (response!=null && !response.isEmpty()) {
                    ArrayList<Msg> nowMsgList = (ArrayList<Msg>) JSON.parseArray(response, Msg.class);
                    if (nowMsgList != null) {
                        if (isChange) {
                            mListItems.clear();
                        }

                        Collections.reverse(nowMsgList);
                        mCurIndex ++;
                        if (nowMsgList.size() < mLoadDataCount) {
                            hasMoreData = false;
                        }
                        //新获得的数据添加进数组
                        mListItems.addAll(0, nowMsgList);
                        ps=nowMsgList.size();
                        updateFlag();
                        updateDataBase(nowMsgList);
                    }
                } else {
                    hasMoreData = false;
                    if (isChange) {
                        mListItems.clear();
                    }
                }
                mAdapter.notifyDataSetChanged();
                scrollView.onPullDownRefreshComplete();
                scrollView.onPullUpRefreshComplete();
                scrollView.setHasMoreData(hasMoreData);
                if(!isChange){
                    ps--;
                }
                isChange=false;
                mListView.setSelection(ps);

                //上传用户联系人列表
                if(getActivity()==null)return;
                boolean isSaveC=SharedUtil.getBoolean(getActivity(), Constant.ISSAVEPHONECONTACT, false);
                if(!isSaveC) {
                    new AlertDialog(getActivity()).builder().setTitle("访问通讯录")
                            .setMsg("请允许访问通讯录，她会帮你建立圈子，添加好友。")
                            .setPositiveButton("确定", new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    ArrayList<ContactVO> contactList= (ArrayList<ContactVO>) Tools.getLocalContactsInfos(getActivity());
                                    String cStr="";
                                    for (ContactVO vo:contactList){
                                        cStr+=vo.getId()+","+vo.getName()+","+vo.getPhone()+";";
                                    }
                                    DealUtil.savePhoneContacts(getActivity(),application.getUserId(getActivity()),cStr);
                                    SharedUtil.putBoolean(getActivity(), Constant.ISSAVEPHONECONTACT, true);
                                }
                            }).setNegativeButton("取消", new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        SharedUtil.putBoolean(getActivity(), Constant.ISSAVEPHONECONTACT, true);
                                    }
                            }).show();
                }

            }
        });
    }

    private void updateFlag(){
        int i=0;
        for (Msg vo:mListItems) {
            vo.setFlag(i%2);
//            mListItems.add(0,vo);
            i++;
        }
    }

    private void setLastUpdateTime() {
        String text = DateUtils.formatSimpleDateTime(System.currentTimeMillis());
        scrollView.setLastUpdatedLabel(text);
    }

//    @Override
//    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//
//    }


    private void updateDataBase(ArrayList<Msg> arrayList){
        ActiveAndroid.beginTransaction();
        try {
            for (Msg vo:arrayList) {
                vo.save();
            }
            ActiveAndroid.setTransactionSuccessful();
        }
        finally {
            ActiveAndroid.endTransaction();
        }

        DBUtil.deletMsgByType(1);
    }

    @Override
    public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
        ctr_box.setVisibility(View.VISIBLE);
        this.updateShow(true);
        return false;
    }



}
