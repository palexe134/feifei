package com.newcolor.qixinginfo.fragment;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.activity.FuturesActivity;
import com.newcolor.qixinginfo.adapter.FuturesAdapter;
import com.newcolor.qixinginfo.entity.FutruesEntity;
import com.newcolor.qixinginfo.global.MyApplication;
import com.newcolor.qixinginfo.util.ProtocolUtil;
import com.newcolor.qixinginfo.util.ToastUtil;

import java.util.ArrayList;

/**
 * 上海期货fragment
 */
public class ShangHaiQiHuoFragment extends Fragment implements AdapterView.OnItemClickListener {
	private Context mContext;
	private MyApplication application;
	private ListView mListView;
	private FuturesAdapter mAdapter;
	private ArrayList<FutruesEntity> mListItems;
	private static final String[] ziXuanArr={};
	private static final String[] lianXuArr={"CU0","CU1605","CU1606","CU1607","CU1608","CU1609","CU1610","CU1611","CU1612","CU1701","CU1702","CU1703"
			,"AL0","AL1605","AL1606","AL1607","AL1608","AL1609","AL1610","AL1611","AL1612","AL1701","AL1702","AL1703"
			,"PB0","PB1605","PB1606","PB1607","PB1608","PB1609","PB1610","PB1611","PB1612","PB1701","PB1702","PB1703"
			,"ZN0","ZN1605","ZN1606","ZN1607","ZN1608","ZN1609","ZN1610","ZN1611","ZN1612","ZN1701","ZN1702","ZN1703"
			,"NI0","NI1605","NI1606","NI1607","NI1608","NI1609","NI1610","NI1611","NI1612","NI1701","NI1702","NI1703"
			,"SN0","SN1605","SN1606","SN1607","SN1608","SN1609","SN1610","SN1611","SN1612","SN1701","SN1702","SN1703"
			,"AU0","AU1605","AU1606","AU1608","AU1610","AU1612","AU1702"
			,"AG0","AG1605","AG1606","AG1607","AG1608","AG1609","AG1610","AG1611","AG1612","AG1701","AG1702","AG1703"
			,"RB0","RB1605","RB1606","RB1607","RB1608","RB1609","RB1610","RB1611","RB1612","RB1701","RB1702","RB1703"
			,"WR0","WR1605","WR1606","WR1607","WR1608","WR1609","WR1610","WR1611","WR1612","WR1701","WR1702","WR1703"
			,"HC0","HC1605","HC1606","HC1607","HC1608","HC1609","HC1610","HC1611","HC1612","HC1701","HC1702","HC1703"
			,"BU0","BU1605","BU1606","BU1607","BU1608","BU1609","BU1612","BU1703"
			,"FU0","FU1605","FU1606","FU1607","FU1608","FU1609","FU1610","FU1611","FU1612","FU1702","FU1703"
			,"RU0","RU1605","RU1606","RU1607","RU1608","RU1609","RU1610","RU1611","RU1701","RU1703"};
	private int TIME = 5000;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_zi_xuan, null);

		return view;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		application = (MyApplication) this.getActivity().getApplication();
		mContext = this.getActivity();

		mListItems=new ArrayList<FutruesEntity>();
		mAdapter=new FuturesAdapter(this.getActivity(),mListItems,null);

		mListView= (ListView) this.getActivity().findViewById(R.id.data_LV);
		mListView.setAdapter(mAdapter);

		mListView.setOnItemClickListener(this);
		this.initData();
	}

	@Override
	public void onResume() {
		super.onResume();
		handler.postDelayed(runnable, TIME);
	}

	private void initData(){
		String listStr="";
		for(String str:ziXuanArr){
			listStr+="hf_"+str+",";
		}

		for(String str:lianXuArr){
			listStr+=str+",";
		}

		ProtocolUtil.getFutruesEntityList("http://hq.sinajs.cn/list=" + listStr, new ProtocolUtil.CallBack() {
			@Override
			public void onListCom(ArrayList list) {
				mListItems.clear();
				mListItems.addAll(list);

				mAdapter.notifyDataSetChanged();
			}

			@Override
			public void onVoCom(FutruesEntity vo) {

			}
		});
	}


	Handler handler = new Handler();
	Runnable runnable = new Runnable() {
		@Override
		public void run() {
			initData();
			handler.postDelayed(this, TIME);
		}
	};




	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
		ListView listView= (ListView) parent;
		FutruesEntity vo = (FutruesEntity) listView.getItemAtPosition(position);

		Intent intent=new Intent(this.getActivity(),FuturesActivity.class);
		intent.putExtra("FutruesEntity",vo);
		startActivity(intent);
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		handler.removeCallbacks(runnable);
	}

	@Override
	public void onPause() {
		super.onPause();
		handler.removeCallbacks(runnable);
	}
}
