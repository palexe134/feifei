package com.newcolor.qixinginfo.fragment;


import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.activeandroid.ActiveAndroid;
import com.alibaba.fastjson.JSON;
import com.baidu.location.BDLocation;
import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.activity.GongQiuInfoActivity;
import com.newcolor.qixinginfo.adapter.GongQiuAdapter;
import com.newcolor.qixinginfo.dialog.AlertDialog;
import com.newcolor.qixinginfo.global.Config;
import com.newcolor.qixinginfo.global.MyApplication;
import com.newcolor.qixinginfo.http.AsyncHttpResponseHandler;
import com.newcolor.qixinginfo.http.RequestParams;
import com.newcolor.qixinginfo.model.GongHuoVO;
import com.newcolor.qixinginfo.ui.editortxt.SearchEditText;
import com.newcolor.qixinginfo.ui.pullrefresh.PullToRefreshSwipeMenuListView;
import com.newcolor.qixinginfo.ui.pullrefresh.RefreshTime;
import com.newcolor.qixinginfo.ui.pullrefresh.swipemenulistview.SwipeMenu;
import com.newcolor.qixinginfo.ui.pullrefresh.swipemenulistview.SwipeMenuCreator;
import com.newcolor.qixinginfo.ui.pullrefresh.swipemenulistview.SwipeMenuItem;
import com.newcolor.qixinginfo.util.DBUtil;
import com.newcolor.qixinginfo.util.HttpUtil;
import com.newcolor.qixinginfo.util.IntentUtil;
import com.newcolor.qixinginfo.util.LoginUtil;
import com.newcolor.qixinginfo.util.ProtocolUtil;
import com.newcolor.qixinginfo.util.Tools;
import com.newcolor.qixinginfo.view.SiteUpdateLayout;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * 供求Fragment
 *
 * Created by Administrator on 2015/10/8.
 */
public class GongQiuFragment extends Fragment implements View.OnClickListener
        ,AdapterView.OnItemClickListener,GongQiuAdapter.Callback, RadioGroup.OnCheckedChangeListener, PullToRefreshSwipeMenuListView.IXListViewListener {
    private PullToRefreshSwipeMenuListView mPullListView;
    private GongQiuAdapter mAdapter;
    private ArrayList<GongHuoVO> mListItems;
    private int mCurIndex = 0;
    private static final int mLoadDataCount = 20;
    private static final int[] viewIdArr={R.id.img_IV,R.id.phoneBtn
            ,R.id.title_TV,R.id.address_TV,R.id.content_TV,
            R.id.star_LL,R.id.time_TV,R.id.icon_IV,R.id.distance_TV,R.id.content_LL,R.id.bg_LL};

    private MyApplication application;
    private FrameLayout gongqiu_title;
    private SiteUpdateLayout siteUL;
    private Button searchBtn;
    private int type=1;//1：供货方 2：需求方
    private boolean isChange=false;
    private SearchEditText search_contact;
    private ImageButton backBtn;
    private int flushType=1;//1：正常刷新 2:搜索刷新
    private BDLocation curLocation;
    private TextView condition1,condition2,condition3;
    private Context mContext;
    private Handler mHandler;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_gongqiu, container, false);
        return view;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        application = (MyApplication) this.getActivity().getApplication();
        mContext=this.getActivity();

        gongqiu_title=(FrameLayout) getView().findViewById(R.id.gongqiu_title);

        siteUL=(SiteUpdateLayout) getView().findViewById(R.id.siteUL);
        siteUL.startPosition(new SiteUpdateLayout.Callback() {
            @Override
            public void onLocationCom(BDLocation location) {
                curLocation=location;
                if(isVisible()||!isHidden()) {
//                    flushData(true);
                }
            }
        });

        backBtn = (ImageButton) gongqiu_title.findViewById(R.id.backBtn);
//        condition1 = (TextView) this.getActivity().findViewById(R.id.condition1);
//        condition2 = (TextView) this.getActivity().findViewById(R.id.condition2);
//        condition3 = (TextView) this.getActivity().findViewById(R.id.condition3);
//        condition1.setOnClickListener(this);
//        condition2.setOnClickListener(this);
//        condition3.setOnClickListener(this);

        backBtn.setVisibility(View.GONE);

        mListItems = new ArrayList<GongHuoVO>();
        //定义下拉刷新
        mPullListView=(PullToRefreshSwipeMenuListView) getView().findViewById(R.id.gongQiuPullListView);
        mAdapter = new GongQiuAdapter(this.getActivity(),mListItems,R.layout.item_list_gong_qiu,viewIdArr,this);
        mPullListView.setAdapter(mAdapter);
        mPullListView.setPullRefreshEnable(true);
        mPullListView.setPullLoadEnable(true);
        mPullListView.setXListViewListener(this);
        mPullListView.setOnItemClickListener(this);
        mPullListView.setDividerHeight(10);
        mHandler = new Handler();

        SwipeMenuCreator creator = new SwipeMenuCreator() {
            @Override
            public void create(SwipeMenu menu) {
                SwipeMenuItem openItem = new SwipeMenuItem(getActivity());
                openItem.setBackground(new ColorDrawable(Color.rgb(0xF9, 0x3F, 0x25)));
                openItem.setWidth(Tools.dp2px(getActivity(), 90));
                openItem.setTitle("关注");
                openItem.setTitleSize(18);
                openItem.setTitleColor(Color.WHITE);
                menu.addMenuItem(openItem);

                /*SwipeMenuItem deleteItem = new SwipeMenuItem(getActivity());
                deleteItem.setBackground(new ColorDrawable(Color.rgb(0xF9, 0x3F, 0x25)));
                deleteItem.setWidth(Tools.dp2px(getActivity(), 90));
                menu.addMenuItem(deleteItem);*/
            }
        };
        // set creator
        mPullListView.setMenuCreator(creator);
        mPullListView.setOnMenuItemClickListener(new PullToRefreshSwipeMenuListView.OnMenuItemClickListener() {
            @Override
            public void onMenuItemClick(int position, SwipeMenu menu, int index) {
                GongHuoVO item = mListItems.get(position);
                switch (index) {
                    case 0:
                        ProtocolUtil.foucsHandler(mContext, application, type, item.getSId());
                        break;
                    /*case 1:
                        mListItems.remove(position);
                        mAdapter.notifyDataSetChanged();
                        break;*/
                }
            }
        });

        mCurIndex = 0;

        searchBtn= (Button) this.getView().findViewById(R.id.searchBtn);
        search_contact= (SearchEditText) this.getView().findViewById(R.id.search_contact);
        searchBtn.setOnClickListener(this);

        //根据ID找到RadioGroup实例
        RadioGroup group = (RadioGroup)gongqiu_title.findViewById(R.id.title_RG);
        //绑定一个匿名监听器
        group.setOnCheckedChangeListener(this);
        initData();
    }




    @Override
    public void onResume() {
        super.onResume();

    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        if(!hidden){
            this.flushData(true);
        }
    }

    /**
     * 初始化数据
     */
    private void initData(){
        if(IntentUtil.isConnect(this.getActivity())){
            if(flushType==1) {
                this.getGongQiuList();
            }else{
                this.searchHandler();
            }
        }else{
            mListItems.clear();
            List<GongHuoVO> list = DBUtil.getGongQiuList(type);
            mListItems.addAll(list);

            mAdapter.notifyDataSetChanged();
        }
    }

    /*
   * 向服务器发送请求消息列表
   * */
    private void getGongQiuList(){
        RequestParams params=new RequestParams();

        if(curLocation!=null) {
            double latitude = curLocation.getLatitude();
            double longitude = curLocation.getLongitude();
            params.put("location", String.valueOf(longitude)+","+String.valueOf(latitude));
            params.put("district",curLocation.getDistrict());
        }
        params.put("userId",application.getUserId(this.getActivity()));
        params.put("type",String.valueOf(type));
        params.put("curSize",String.valueOf(mCurIndex));

        params.put("count",String.valueOf(mLoadDataCount));
        HttpUtil.get(Config.GetGongQiuList, params, new AsyncHttpResponseHandler() {
            Boolean isHasMore = false;

            @Override
            public void onFailure(Throwable error, String content) {
                super.onFailure(error, content);
            }

            @Override
            public void onSuccess(String content) {
                super.onSuccess(content);
                ArrayList<GongHuoVO> arrayList = (ArrayList<GongHuoVO>) JSON.parseArray(content, GongHuoVO.class);
                if (isChange) {
                    mListItems.clear();
                    isChange = false;
                }

                if(arrayList!=null) {
                    updateDataBase(arrayList);
                    mListItems.addAll(arrayList);
                    mCurIndex ++;
                    if (arrayList.size() < mLoadDataCount) {
                        isHasMore = false;
                    } else {
                        isHasMore = true;
                    }
                }

                mAdapter.notifyDataSetChanged();
                mPullListView.setRefreshTime(RefreshTime.getRefreshTime(getActivity()));
                mPullListView.stopRefresh();
                mPullListView.stopLoadMore();
                mPullListView.setPullLoadEnable(isHasMore);
            }
        });
//        mListItems.clear();
//        GongHuoVO vo;
//
//        for (int i = 0; i < 11; i++) {
//            vo = new GongHuoVO();
//            vo.setAdress("山东省临沂市罗庄区");
//            vo.setContent("出售500斤铜矿");
//            vo.setStar(5);
//            vo.setTelephone("15953981802");
//            vo.setTitle("出售铜矿");
//            mListItems.add(vo);
//        }
    }

    private void updateDataBase(ArrayList<GongHuoVO> arrayList){
        DBUtil.deletGongQiuByType(type);

        ActiveAndroid.beginTransaction();
        try {
            for (GongHuoVO vo:arrayList) {
                vo.save();
            }
            ActiveAndroid.setTransactionSuccessful();
        }
        finally {
            ActiveAndroid.endTransaction();
        }
    }

    public void flushData(boolean isChange){
//        String userId=SharedUtil.getString(this.getActivity(),"userId");
//        if(userId==null){
//            return;
//        }
        if(search_contact.getText().toString().isEmpty()){
            flushType=1;
        }else{
            flushType=2;
        }
        this.isChange=isChange;
        mCurIndex=0;
        initData();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.searchBtn:
                flushData(true);
                break;
//            case R.id.condition1:
//                ChooseTypeUtil.getInstance(this.getActivity()).showDatas(new ChooseTypeUtil.Callback() {
//                    @Override
//                    public void onCom(GoodTypeVO vo) {
//
//                    }
//                });
//                break;
        }
    }

    private void searchHandler(){
        ((InputMethodManager)this.getActivity().getSystemService(Context.INPUT_METHOD_SERVICE))
                .hideSoftInputFromWindow(this.getActivity().getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);

//        InputMethodManager imm = (InputMethodManager) this.getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
//        imm.toggleSoftInput(0, InputMethodManager.HIDE_NOT_ALWAYS);

        RequestParams params=new RequestParams();
        params.put("type",String.valueOf(type));
        params.put("title",search_contact.getText().toString());
        params.put("curSize",String.valueOf(mCurIndex));
        params.put("count",String.valueOf(mLoadDataCount));
        HttpUtil.get(Config.searchInfoList, params, new AsyncHttpResponseHandler() {
            Boolean isHasMore = false;

            @Override
            public void onFailure(Throwable error, String content) {
                super.onFailure(error, content);
            }

            @Override
            public void onSuccess(String content) {
                super.onSuccess(content);
                ArrayList<GongHuoVO> arrayList = (ArrayList<GongHuoVO>) JSON.parseArray(content, GongHuoVO.class);

                if (isChange) {
                    mListItems.clear();
                    isChange = false;
                }

                if(arrayList!=null) {
                    updateDataBase(arrayList);
                    mListItems.addAll(arrayList);
                    mCurIndex ++;
                    if (arrayList.size() < mLoadDataCount) {
                        isHasMore = false;
                    } else {
                        isHasMore = true;
                    }
                }

                mAdapter.notifyDataSetChanged();
            }
        });
    }


    private void changeInfo(){
        if(type==1){
            type=2;
            this.flushData(true);
        }else{
            type=1;
            this.flushData(true);
        }
    }


    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        ListView listView = (ListView) parent;
        GongHuoVO vo = (GongHuoVO) listView.getItemAtPosition(position);

        if (application.getUserId(this.getActivity()).equals("-1")) {
            LoginUtil.gotoLogin(this.getActivity());
            return;
        }
        Intent intent = new Intent(this.getActivity(), GongQiuInfoActivity.class);
        intent.putExtra("sId", vo.getSId());
        intent.putExtra("type", type);
        startActivity(intent);
    }

    @Override
    public void click(View v) {
        final GongHuoVO vo = (GongHuoVO) v.getTag();
        switch (v.getId()) {
            case R.id.phoneBtn:
                new AlertDialog(this.getActivity()).builder().setTitle("联系商家")
                        .setMsg(vo.getPhone()+"\n\n废废网竭诚为您服务")
                        .setPositiveButton("确定", new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                phoneHandler(vo);
                            }
                        }).setNegativeButton("取消", new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                    }
                }).show();
                break;
        }
    }

    private void phoneHandler(GongHuoVO vo){
        Intent intent = new Intent(Intent.ACTION_CALL);
        Uri data = Uri.parse("tel:" + vo.getPhone());
        intent.setData(data);
        startActivity(intent);
    }

    @Override
    public void onCheckedChanged(RadioGroup group, int checkedId) {
        this.changeInfo();
    }

    @Override
    public void onRefresh() {
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                SimpleDateFormat df = new SimpleDateFormat("MM-dd HH:mm", Locale.getDefault());
                RefreshTime.setRefreshTime(getActivity(), df.format(new Date()));
                flushData(true);
            }
        }, 2000);
    }

    @Override
    public void onLoadMore() {
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                initData();
            }
        }, 2000);
    }
}
