package com.newcolor.qixinginfo.fragment;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.activity.GongQiuInfoActivity;
import com.newcolor.qixinginfo.adapter.HomePageAdapter;
import com.newcolor.qixinginfo.global.Config;
import com.newcolor.qixinginfo.global.MyApplication;
import com.newcolor.qixinginfo.http.AsyncHttpResponseHandler;
import com.newcolor.qixinginfo.http.RequestParams;
import com.newcolor.qixinginfo.manager.ScreenManager;
import com.newcolor.qixinginfo.model.GongHuoVO;
import com.newcolor.qixinginfo.ui.pullrefresh.GridViewWithHeaderAndFooter;
import com.newcolor.qixinginfo.util.HttpUtil;
import com.newcolor.qixinginfo.util.ToastUtil;
import com.newcolor.qixinginfo.view.HomePageHeaderView;

import java.util.ArrayList;

/**
 * 首页fragment
 *
 * Created by Administrator on 2015/10/8.
 */
public class HomePageFragment extends Fragment implements AdapterView.OnItemClickListener, GridViewWithHeaderAndFooter.OnRefreshListener, View.OnClickListener {
    private MyApplication application;
//    private FrameLayout homePageTitle;
    private TextView tv;
    private ImageButton backBtn;
    private HomePageHeaderView headerView;
    private ImageView top_IV;
    private int mCurIndex = 0;
    private static final int mLoadDataCount = 10;
    private ArrayList<GongHuoVO> tuiJianListItems;
    private HomePageAdapter tuiJIanAdapter;
    private GridViewWithHeaderAndFooter tui_jian_GV;
    private static final int[] viewIdArr={R.id.title_TV,R.id.img_IV,R.id.icon_IV,R.id.price_TV,R.id.num_TV};

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_home_page, container, false);
        return view;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        application = (MyApplication)this.getActivity().getApplication();
        ScreenManager.getInstance().pushActivity(this.getActivity());

        init();
        this.initData();
    }


    private void init(){
//        homePageTitle=(FrameLayout) this.getActivity().findViewById(R.id.homePageTitle);
//
//        tv = (TextView) homePageTitle.findViewById(R.id.titleTv);
//        tv.setText("首页");
//        backBtn=(ImageButton) homePageTitle.findViewById(R.id.backBtn);
//        backBtn.setVisibility(View.GONE);

        headerView=new HomePageHeaderView(getActivity());
//        headerView.initData();
//        headerView.updateDate();

        tuiJianListItems=new ArrayList<GongHuoVO>();
        tuiJIanAdapter=new HomePageAdapter(getActivity(),tuiJianListItems,R.layout.item_list_home_page,viewIdArr,3);
        tui_jian_GV = (GridViewWithHeaderAndFooter) getActivity().findViewById(R.id.tui_jian_GV);
//        ImageView view=new ImageView(getActivity());
//        view.setImageResource(R.mipmap.default_head_bg);
        tui_jian_GV.setVerticalSpacing(10);
        tui_jian_GV.setHorizontalSpacing(10);
        tui_jian_GV.addHeaderView(headerView);
        tui_jian_GV.setAdapter(tuiJIanAdapter);
        tui_jian_GV.setOnRefreshListener(this);

        tui_jian_GV.setOnItemClickListener(this);
        tui_jian_GV.setFocusable(false);

        top_IV= (ImageView) getActivity().findViewById(R.id.top_IV);
        top_IV.setOnClickListener(this);
    }


    public void initData() {
        tuiJianListItems.clear();
        getHomePageTuiJianList();
    }


    private void getHomePageTuiJianList() {
        RequestParams params=new RequestParams();
        params.put("curSize",String.valueOf(mCurIndex));
        params.put("count",String.valueOf(mLoadDataCount));
        HttpUtil.get(Config.getHomePageTuiJianList, params, new AsyncHttpResponseHandler() {
            Boolean isHasMore = false;

            @Override
            public void onFailure(Throwable error, String content) {
                super.onFailure(error, content);
            }

            @Override
            public void onSuccess(String content) {
                super.onSuccess(content);
                ArrayList<GongHuoVO> arrayList = (ArrayList<GongHuoVO>) JSON.parseArray(content, GongHuoVO.class);

                if (arrayList != null) {
                    tuiJianListItems.addAll(arrayList);
                    mCurIndex++;
                    if (arrayList.size() < mLoadDataCount * 2) {
                        isHasMore=false;
                    } else {
                        isHasMore=true;
                    }
                }
                tuiJIanAdapter.notifyDataSetChanged();
                tui_jian_GV.setHasMoreData(isHasMore);
                tui_jian_GV.onPullUpRefreshComplete();
            }
        });
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        switch (parent.getId()) {
            case R.id.tui_jian_GV:
                GridView listView = (GridView) parent;
                GongHuoVO vo = (GongHuoVO) listView.getItemAtPosition(position+2);

                Intent intent = new Intent(this.getActivity(), GongQiuInfoActivity.class);
                intent.putExtra("sId", vo.getSId());
                intent.putExtra("type", vo.getType());
                getActivity().startActivity(intent);
                break;
        }
    }

    @Override
    public void onPullUpToRefresh(GridViewWithHeaderAndFooter refreshView) {
        getHomePageTuiJianList();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.top_IV:
                tui_jian_GV.setSelection(0);
//                tui_jian_GV.smoothScrollByOffset(0);
                ToastUtil.showToast(getActivity(),"回到顶端");
                break;
        }
    }
}
