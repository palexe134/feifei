package com.newcolor.qixinginfo.fragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.entity.FutruesEntity;
import com.newcolor.qixinginfo.entity.OHLCEntity;
import com.newcolor.qixinginfo.http.AsyncHttpResponseHandler;
import com.newcolor.qixinginfo.util.HttpUtil;
import com.newcolor.qixinginfo.util.ToastUtil;
import com.newcolor.qixinginfo.view.KChartsView;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * K线fragment
 */
public class KChartsFragment extends Fragment {
	private KChartsView mMyChartsView;
	private FutruesEntity curVo;

	public KChartsFragment() {
	}


	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		if(getArguments() != null) {
			curVo = getArguments().getParcelable("futruesVo");
		}

		View view = inflater.inflate(R.layout.fragment_kcharts, null);
		mMyChartsView = (KChartsView) view.findViewById(R.id.my_charts_view);

		this.initData();

		mMyChartsView.setLowerChartTabTitles(new String[]{"MACD", "KDJ", "RSI"});


		return view;
	}

	private void initData(){

		HttpUtil.getOther("http://stock2.finance.sina.com.cn/futures/api/json.php/IndexService.getInnerFuturesDailyKLine?symbol="+curVo.getCode() , new AsyncHttpResponseHandler() {
			@Override
			public void onFailure(Throwable error, String content) {
				super.onFailure(error, content);
			}

			@Override
			public void onSuccess(String content) {
				super.onSuccess(content);
				List<OHLCEntity> ohlc = new ArrayList<OHLCEntity>();

				try {
					JSONArray jsArr=new JSONArray(content);

					if (jsArr.length() < 1) {
						ToastUtil.showToast(getActivity(),"加载数据失败");
					} else {
						for (int i = 0; i < jsArr.length(); i++) {
							JSONArray jsOb = jsArr.getJSONArray(i);
							ohlc.add(0,new OHLCEntity(jsOb.getDouble(1), jsOb.getDouble(2), jsOb.getDouble(3), jsOb.getDouble(4), jsOb.getString(0)));
						}
					}

				} catch (JSONException e) {
					e.printStackTrace();
				}
//				Collections.reverse(ohlc);
				mMyChartsView.setOHLCData(ohlc);
				mMyChartsView.postInvalidate();
			}
		});
	}

}
