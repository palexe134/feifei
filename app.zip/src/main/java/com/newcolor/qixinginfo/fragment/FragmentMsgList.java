package com.newcolor.qixinginfo.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import com.activeandroid.ActiveAndroid;
import com.alibaba.fastjson.JSON;
import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.activity.MsgActivity;
import com.newcolor.qixinginfo.adapter.MsgAdapter;
import com.newcolor.qixinginfo.global.Config;
import com.newcolor.qixinginfo.global.MyApplication;
import com.newcolor.qixinginfo.http.AsyncHttpResponseHandler;
import com.newcolor.qixinginfo.http.RequestParams;
import com.newcolor.qixinginfo.model.Msg;
import com.newcolor.qixinginfo.ui.pullrefresh.PullToRefreshBase;
import com.newcolor.qixinginfo.ui.pullrefresh.PullToRefreshListView;
import com.newcolor.qixinginfo.util.DBUtil;
import com.newcolor.qixinginfo.util.DateUtils;
import com.newcolor.qixinginfo.util.HttpUtil;
import com.newcolor.qixinginfo.util.IntentUtil;
import com.newcolor.qixinginfo.util.ToastUtil;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


/**
 * 消息的fragment
 *
 *
 * Created by baolei.si on 2015/8/18.
 */
public class FragmentMsgList extends Fragment implements AdapterView.OnItemClickListener {
    private ListView mListView;
    private PullToRefreshListView mPullListView;
    private MsgAdapter mAdapter;
    private ArrayList<Msg> mListItems=new ArrayList<Msg>();
    private static final int[] viewIdArr={R.id.itemImage,R.id.itemTitle,R.id.listItemContent};
    public int type,state=1;
    private MyApplication application;
    private boolean isChange=false;
    private int mCurIndex = 0;
    private boolean isRefreshing=false;
    private static final int mLoadDataCount = 20;
    private static FragmentMsgList instance;

    public FragmentMsgList(){
        super();
    }



    public static FragmentMsgList getInstance(int mtype){
        if(instance==null){
            instance=new FragmentMsgList();
            instance.type=mtype;
        }else{
            instance.type=mtype;
            instance.flushData(true);
        }
        return instance;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_msg_list,null);
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        application= (MyApplication) this.getActivity().getApplication();

//        curPage=1;
//        mListItems.clear() ;

        //定义下拉刷新
        mPullListView=(PullToRefreshListView) this.getView().findViewById(R.id.msgListPullListView);
        mPullListView.setPullLoadEnabled(false);
        mPullListView.setScrollLoadEnabled(true);


        int iconId=0;
        if(type==1){
            iconId=R.mipmap.ic_gong_gao;
        }else{
            iconId=R.mipmap.ic_gong_gao;
        }

        mAdapter = new MsgAdapter(this.getActivity(),mListItems,R.layout.item_list_msg,viewIdArr,iconId);
        mListView = mPullListView.getRefreshableView();
        mListView.setAdapter(mAdapter);
        mListView.setOnItemClickListener(this);

        mPullListView.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener<ListView>() {
            @Override
            public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {
                initData();
            }

            @Override
            public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {
                initData();
            }
        });
        setLastUpdateTime();
//        if(state==1){
//            this.flushData(true);
//        }
//        mPullListView.doPullRefreshing(true, 500);
    }

    @Override
    public void onResume() {
        super.onResume();
        if(this.isVisible()) {
            this.flushData(true);
        }
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        if(!hidden){
            this.flushData(true);
        }
    }

    private void initData(){
        if(IntentUtil.isConnect(this.getActivity()) && !application.getUserId(this.getActivity()).equals("-1")){
            this.updateData();
        }else{
            int ps=0;
            if (isChange) {
                mListItems.clear();
            }
            List<Msg> list = DBUtil.getMsgList(type,mCurIndex,mLoadDataCount);
            Collections.reverse(list);
            mListItems.addAll(0, list);
            ps=list.size();

            mCurIndex++;

            mAdapter.notifyDataSetChanged();
            mPullListView.onPullDownRefreshComplete();
            mPullListView.onPullUpRefreshComplete();
            mPullListView.setHasMoreData(false);
            setLastUpdateTime();

            if(!isChange){
                ps--;
            }
            isChange=false;
            mListView.setSelection(ps);
        }
    }

    private void updateData(){

        RequestParams rParams=new RequestParams();
        rParams.put("userId", application.getUserId(this.getActivity()));
        //1：订阅消息  2：个人消息  3：今日行情  4：系统公告
        rParams.put("type", String.valueOf(type));
        rParams.put("version", String.valueOf(IntentUtil.getCurrentVersionCode(this.getActivity())));
        //  1 未读 2 已读
        rParams.put("msgState", String.valueOf(state));
        rParams.put("curSize",String.valueOf(mCurIndex));
        rParams.put("count", String.valueOf(mLoadDataCount));

        HttpUtil.get(Config.GetMsgList, rParams, new AsyncHttpResponseHandler() {
            @Override
            public void onFinish() {
                super.onFinish();
                isRefreshing=false;
            }

            @Override
            public void onFailure(Throwable error, String content) {
                super.onFailure(error, content);
                ToastUtil.showToast(getActivity(),content);
            }

            @Override
            public void onSuccess(String response) {
                super.onSuccess(response);
                boolean hasMoreData = true;

                if (!response.isEmpty()) {
//                    ArrayList<Msg> nowMsgList = (ArrayList<Msg>) JsonUtil.fromJson(response, new TypeToken<ArrayList<Msg>>() {
//                    });
                    ArrayList<Msg> nowMsgList= (ArrayList<Msg>) JSON.parseArray(response,Msg.class);
                    if (nowMsgList != null) {
                        if (isChange) {
                            mListItems.clear();
                            isChange = false;

                        }
                        mCurIndex++;
                        if (nowMsgList.size() < mLoadDataCount) {
                            hasMoreData = false;
                        }

                        //新获得的数据添加进数组
                        mListItems.addAll(nowMsgList);
                        updateDataBase(nowMsgList);
                    }
                } else {
                    hasMoreData = false;
                    if (isChange) {
                        mListItems.clear();
                        isChange = false;
                    }
                }
                mAdapter.notifyDataSetChanged();
                mPullListView.onPullDownRefreshComplete();
                mPullListView.onPullUpRefreshComplete();
                mPullListView.setHasMoreData(hasMoreData);
                setLastUpdateTime();
            }
        });
    }

    private void updateDataBase(ArrayList<Msg> arrayList){
        DBUtil.deletMsgByType(type);

        ActiveAndroid.beginTransaction();
        try {
            for (Msg vo:arrayList) {
                vo.save();
            }
            ActiveAndroid.setTransactionSuccessful();
        }
        finally {
            ActiveAndroid.endTransaction();
        }
    }


    public void flushData(boolean isChange){
        if(isRefreshing){
            return;
        }
        isRefreshing=true;
        this.isChange=isChange;
        mCurIndex=0;
//        mListItems.clear();
        if(mPullListView!=null) {
            mPullListView.doPullRefreshing(true, 500);
        }
    }


    private void setLastUpdateTime() {
        String text = DateUtils.formatSimpleDateTime(System.currentTimeMillis());
        mPullListView.setLastUpdatedLabel(text);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        ListView listView = (ListView)parent;
        Msg msg = (Msg) listView.getItemAtPosition(position);

        Intent i = new Intent(this.getActivity(), MsgActivity.class);
        Bundle mBundle = new Bundle();
        mBundle.putParcelable("msg", msg);
        i.putExtras(mBundle);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        this.startActivity(i);
    }


}
