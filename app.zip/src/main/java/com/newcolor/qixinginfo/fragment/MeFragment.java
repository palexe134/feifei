package com.newcolor.qixinginfo.fragment;


import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.baidu.location.BDLocation;
import com.baidu.location.BDLocationListener;
import com.baidu.location.LocationClient;
import com.baidu.mapapi.model.LatLng;
import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.activity.ContactListActivity;
import com.newcolor.qixinginfo.activity.GongQiuAdapterActivity;
import com.newcolor.qixinginfo.activity.LoginActivity;
import com.newcolor.qixinginfo.activity.MsgContactListActivity;
import com.newcolor.qixinginfo.activity.OpinionActivity;
import com.newcolor.qixinginfo.activity.PersonalInfoActivity;
import com.newcolor.qixinginfo.activity.SettingActivity;
import com.newcolor.qixinginfo.activity.WebViewActivity;
import com.newcolor.qixinginfo.adapter.MeAdapter;
import com.newcolor.qixinginfo.dialog.AlertDialog;
import com.newcolor.qixinginfo.global.Config;
import com.newcolor.qixinginfo.global.Constant;
import com.newcolor.qixinginfo.global.MyApplication;
import com.newcolor.qixinginfo.http.AsyncHttpResponseHandler;
import com.newcolor.qixinginfo.http.RequestParams;
import com.newcolor.qixinginfo.model.MeVO;
import com.newcolor.qixinginfo.model.UserVO;
import com.newcolor.qixinginfo.ui.cycleviewpager.ADInfo;
import com.newcolor.qixinginfo.ui.cycleviewpager.ImageCycleView;
import com.newcolor.qixinginfo.util.BaiduMapUtil;
import com.newcolor.qixinginfo.util.DealUtil;
import com.newcolor.qixinginfo.util.HttpUtil;
import com.newcolor.qixinginfo.util.LoginUtil;
import com.newcolor.qixinginfo.util.Tools;

import java.util.ArrayList;

/**
 * 我的fragment
 *
 * Created by Administrator on 2015/10/8.
 */
public class MeFragment extends Fragment implements AdapterView.OnItemClickListener, View.OnClickListener {
    private MyApplication application;
    private TextView name_TV,phone_TV,address_TV,zu_ji_num_TV,
    who_look_num_TV,guan_zhu_num_TV;
//    private FrameLayout msg_title;
    private ListView mListView;
    private MeAdapter mAdapter;
    private ArrayList<MeVO> mListItems;
    private ImageView setBtn,head_IV;
    private ImageButton backBtn;
    private LinearLayout info_LL,guan_zhu_LL,who_look_LL,zu_ji_LL;
    private Button loginBtn;
    private ImageCycleView mAdView;
    private UserVO curUserVo;
    private LocationClient locationClient;
    private ArrayList<ADInfo> infos = new ArrayList<ADInfo>();
    private static final int[] viewIdArr={R.id.img_IV,R.id.name_TV};
    private static final String[] titleArr={"我的需求","我的供应","我的二手","添加联系方式","客服中心","设置"};
    private static final int[] iconArr={R.mipmap.my_xu_qiu_icon,R.mipmap.my_gong_ying_icon,R.mipmap.ic_yi_jian,R.mipmap.ic_add_contact,R.mipmap.ic_ke_fu,R.mipmap.ic_setting};

    public BDLocationListener myListener=new BDLocationListener() {
        @Override
        public void onReceiveLocation(BDLocation location) {
            if(location==null){
                return;
            }

            LatLng ll=new LatLng(location.getLatitude(),
                    location.getLongitude());

            curUserVo.setAddress(location.getAddrStr());
            curUserVo.setCoordinate(location.getLongitude()+","+location.getLatitude());
            address_TV.setText("地址：" + curUserVo.getAddress());
            DealUtil.savePersonalInfo(getActivity(), curUserVo, application.getUserId(getActivity()));
        }
    };

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_me, container, false);
        return view;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        application = (MyApplication) this.getActivity().getApplication();

//        msg_title=(FrameLayout) getView().findViewById(R.id.msg_title);
//
//        tv = (TextView) msg_title.findViewById(R.id.titleTv);
//        tv.setText("我的");
//        backBtn = (ImageButton) msg_title.findViewById(R.id.backBtn);
//        backBtn.setVisibility(View.GONE);

        name_TV= (TextView) this.getView().findViewById(R.id.name_TV);
        phone_TV= (TextView) this.getView().findViewById(R.id.phone_TV);
        address_TV= (TextView) this.getView().findViewById(R.id.address_TV);
        zu_ji_num_TV= (TextView) this.getView().findViewById(R.id.zu_ji_num_TV);
        who_look_num_TV= (TextView) this.getView().findViewById(R.id.who_look_num_TV);
        guan_zhu_num_TV= (TextView) this.getView().findViewById(R.id.guan_zhu_num_TV);

        info_LL= (LinearLayout) this.getView().findViewById(R.id.info_LL);
        guan_zhu_LL= (LinearLayout) this.getView().findViewById(R.id.guan_zhu_LL);
        who_look_LL= (LinearLayout) this.getView().findViewById(R.id.who_look_LL);
        zu_ji_LL= (LinearLayout) this.getView().findViewById(R.id.zu_ji_LL);

        guan_zhu_LL.setOnClickListener(this);
        who_look_LL.setOnClickListener(this);
        zu_ji_LL.setOnClickListener(this);

        loginBtn= (Button) this.getView().findViewById(R.id.loginBtn);
        mAdView = (ImageCycleView) this.getView().findViewById(R.id.ad_view);

        loginBtn.setOnClickListener(this);

        this.initData();

        mAdapter=new MeAdapter(this.getActivity(),mListItems,viewIdArr);

        mListView= (ListView) this.getActivity().findViewById(R.id.data_LV);
        mListView.setAdapter(mAdapter);
        setBtn= (ImageView) this.getActivity().findViewById(R.id.set_IV);
        head_IV= (ImageView) this.getActivity().findViewById(R.id.head_IV);

        mListView.setOnItemClickListener(this);
        setBtn.setOnClickListener(this);
        head_IV.setOnClickListener(this);

        this.initView();
    }


    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        if(!hidden){
            this.checkLogin();
        }
    }


    @Override
    public void onResume() {
        super.onResume();
//        this.initView();
        if(this.isVisible()) {
            this.checkLogin();
        }
    }



    private void initView(){
        if(!application.getUserId(this.getActivity()).equals("-1")) {
            info_LL.setVisibility(View.VISIBLE);
            loginBtn.setVisibility(View.GONE);
            guan_zhu_num_TV.setVisibility(View.GONE);
            who_look_num_TV.setVisibility(View.GONE);
            zu_ji_num_TV.setVisibility(View.GONE);
        }else{
            info_LL.setVisibility(View.GONE);
            loginBtn.setVisibility(View.VISIBLE);
//            guan_zhu_num_TV.setVisibility(View.VISIBLE);
//            who_look_num_TV.setVisibility(View.VISIBLE);
//            zu_ji_num_TV.setVisibility(View.VISIBLE);
            guan_zhu_num_TV.setVisibility(View.GONE);
            who_look_num_TV.setVisibility(View.GONE);
            zu_ji_num_TV.setVisibility(View.GONE);
        }
    }

    private void checkLogin(){
        if(application.getUserId(this.getActivity()).equals("-1")){
            LoginUtil.gotoLogin(this.getActivity(), false, new LoginUtil.Callback() {
                @Override
                public void onCom() {
                    getUserInfo();
                }
            });
        }else{
            getUserInfo();
        }
    }

    private void getUserInfo(){
        RequestParams params=new RequestParams();
        params.put("userId",application.getUserId(this.getActivity()));

        HttpUtil.get(Config.GetMeInfo, params, new AsyncHttpResponseHandler() {
            @Override
            public void onFailure(Throwable error, String content) {
                super.onFailure(error, content);
            }

            @Override
            public void onSuccess(String content) {
                super.onSuccess(content);
                if(getActivity()==null)return;

                initView();

                curUserVo = JSON.parseObject(content, UserVO.class);
                if (curUserVo.getAddress() == null || curUserVo.getAddress().isEmpty() || curUserVo.getAddress().length() < 6||
                        curUserVo.getCoordinate() == null || curUserVo.getCoordinate().isEmpty()) {
                    startPosition();
                }

                application.setCurUserVo(curUserVo);
                name_TV.setText(application.getCurUserVo().getName());
                phone_TV.setText("电话：" + application.getCurUserVo().getPhone());
                address_TV.setText("地址：" + application.getCurUserVo().getAddress());
//                ImageLoader.getInstance().displayImage(application.getCurUserVo().getHeadImg(), head_IV, Constant.headOptions);
                Tools.loadImg(getActivity(), application.getCurUserVo().getHeadImg(), head_IV, Constant.getCircleHeadOptions(getActivity()), null, R.mipmap.defaulthead);
                if (application.getCurUserVo().getComponyImgsArr() != null && application.getCurUserVo().getComponyImgsArr().size() > 0) {
                    infos.clear();
                    for (int i = 0; i < application.getCurUserVo().getComponyImgsArr().size(); i++) {
                        ADInfo info = new ADInfo();
                        info.setUrl(application.getCurUserVo().getComponyImgsArr().get(i));
                        info.setContent("top-->" + i);
                        infos.add(info);
                    }
                    mAdView.setImageResources(infos, mAdCycleViewListener);
                }
            }
        });
    }

    private ImageCycleView.ImageCycleViewListener mAdCycleViewListener = new ImageCycleView.ImageCycleViewListener() {

        @Override
        public void onImageClick(ADInfo info, int position, View imageView) {
//            Toast.makeText(this, "content->" + info.getContent(), Toast.LENGTH_SHORT).show();
        }

        @Override
        public void displayImage(String imageURL, ImageView imageView) {
//            ImageLoader.getInstance().displayImage(imageURL, imageView,Constant.propagandaOptions);// 使用ImageLoader对图片进行加装！
            Tools.loadImg(getActivity(), imageURL, imageView,
                    Constant.getSimpleDisplayImage(R.mipmap.me_default_bg), null, R.mipmap.me_default_bg);
        }
    };

    private String[] imageUrls = {""};
//    "http://pic30.nipic.com/20130626/8174275_085522448172_2.jpg",
//            "http://pic18.nipic.com/20111215/577405_080531548148_2.jpg",
//            "http://pic15.nipic.com/20110722/2912365_092519919000_2.jpg",
//            "http://pic.58pic.com/58pic/12/64/27/55U58PICrdX.jpg"

    private void initData(){
        mListItems=new ArrayList<MeVO>();
        MeVO vo;
        for(int i=0;i<titleArr.length;i++){
            vo=new MeVO();
            vo.setName(titleArr[i]);
            vo.setIconId(iconArr[i]);
            mListItems.add(vo);
        }

        for (int i = 0; i < imageUrls.length; i++) {
            ADInfo info = new ADInfo();
            info.setUrl(imageUrls[i]);
            info.setContent("top-->" + i);
            infos.add(info);
        }
        mAdView.setImageResources(infos, mAdCycleViewListener);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        switch (position){
            case 0:
                if(application.getUserId(this.getActivity()).equals("-1")){
                    LoginUtil.gotoLogin(this.getActivity());
                    return;
                }
                Intent intent=new Intent(this.getActivity(), GongQiuAdapterActivity.class);
                intent.putExtra("type",1);
                intent.putExtra("state",2);
                startActivity(intent);
                break;
            case 1:
                if(application.getUserId(this.getActivity()).equals("-1")){
                    LoginUtil.gotoLogin(this.getActivity());
                    return;
                }
                intent=new Intent(this.getActivity(), GongQiuAdapterActivity.class);
                intent.putExtra("type",2);
                intent.putExtra("state",1);
                startActivity(intent);
                break;
            case 2:
                if(application.getUserId(this.getActivity()).equals("-1")){
                    LoginUtil.gotoLogin(this.getActivity());
                    return;
                }
                intent=new Intent(this.getActivity(), GongQiuAdapterActivity.class);
                intent.putExtra("type",7);
                intent.putExtra("state",3);
                startActivity(intent);
                break;
            case 3:
                if(application.getUserId(this.getActivity()).equals("-1")){
                    LoginUtil.gotoLogin(this.getActivity());
                    return;
                }
                intent=new Intent(this.getActivity(), ContactListActivity.class);
                startActivity(intent);
                break;
            /*case 4:
                intent=new Intent(this.getActivity(), WebViewActivity.class);
                intent.putExtra("webUrl", "http://sj.aaaly.com/");
                startActivity(intent);
                break;
            case 2:
                if(application.getUserId(this.getActivity()).equals("-1")){
                    LoginUtil.gotoLogin(this.getActivity());
                    return;
                }
                intent=new Intent(this.getActivity(), OpinionActivity.class);
                startActivity(intent);
                break;*/
            case 4:
                new AlertDialog(this.getActivity()).builder().setTitle("联系客服")
                        .setMsg("13345086668\n\n全天24小时竭诚为您服务")
                        .setPositiveButton("确定", new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                phoneHandler();
                            }
                        }).setNegativeButton("取消", new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                    }
                }).show();
                break;
            case 5:
                intent=new Intent(this.getActivity(), SettingActivity.class);
                startActivity(intent);
                break;
        }
    }


    private void phoneHandler(){
        Intent intent = new Intent(Intent.ACTION_CALL);
        Uri data = Uri.parse("tel:" + "13345086668");
        intent.setData(data);
        startActivity(intent);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.set_IV:
                Intent intent=new Intent(this.getActivity(), SettingActivity.class);
                startActivity(intent);
                break;
            case R.id.head_IV:
                if(application.getUserId(this.getActivity()).equals("-1")){
                    LoginUtil.gotoLogin(this.getActivity());
                    return;
                }
                intent=new Intent(this.getActivity(), PersonalInfoActivity.class);
                startActivity(intent);
                break;
            case R.id.loginBtn:
                intent=new Intent(this.getActivity(),LoginActivity.class);
                startActivity(intent);
                break;
            case R.id.guan_zhu_LL:
                if(application.getUserId(this.getActivity()).equals("-1")){
                    LoginUtil.gotoLogin(this.getActivity());
                    return;
                }
                intent=new Intent(this.getActivity(), GongQiuAdapterActivity.class);
                intent.putExtra("type",3);
                startActivity(intent);
                break;
            case R.id.who_look_LL:
                if(application.getUserId(this.getActivity()).equals("-1")){
                    LoginUtil.gotoLogin(this.getActivity());
                    return;
                }
                intent=new Intent(this.getActivity(), MsgContactListActivity.class);
                startActivity(intent);
                break;
            case R.id.zu_ji_LL:
                if(application.getUserId(this.getActivity()).equals("-1")){
                    LoginUtil.gotoLogin(this.getActivity());
                    return;
                }
                intent=new Intent(this.getActivity(), GongQiuAdapterActivity.class);
                intent.putExtra("type",4);
                startActivity(intent);
                break;
            default:
                break;
        }
    }

    private void startPosition(){
        if(locationClient==null) {
            locationClient = new LocationClient(this.getActivity().getApplicationContext());
            locationClient.registerLocationListener(myListener);
            locationClient.setLocOption(BaiduMapUtil.getDefaultLocationOption());   //设置定位参数
        }
        locationClient.start(); // 开始定位
    }


}
