package com.newcolor.qixinginfo.fragment;


import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.global.Config;
import com.newcolor.qixinginfo.global.MyApplication;
import com.newcolor.qixinginfo.http.AsyncHttpResponseHandler;
import com.newcolor.qixinginfo.http.RequestParams;
import com.newcolor.qixinginfo.ui.badge.BadgeView;
import com.newcolor.qixinginfo.util.HttpUtil;
import com.newcolor.qixinginfo.util.IntentUtil;
import com.newcolor.qixinginfo.util.LoginUtil;
import com.newcolor.qixinginfo.util.ToastUtil;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * 现在在用的消息fragment
 *
 * Created by Administrator on 2015/10/8.
 */
public class NewMsgFragment extends Fragment implements View.OnClickListener, RadioGroup.OnCheckedChangeListener {
    private TextView tv;
    private FrameLayout msg_title;
    private MyApplication application;
    private ImageButton backBtn;

//    private Fragment[] mFragments;
//    private RadioGroup topRg;
//    private FragmentManager fragmentManager;
//    private FragmentTransaction fragmentTransaction;
    private RadioButton msgOne, msgTwo, msgThree, msgFour;
    private int index=1;
    private ArrayList<RadioButton> radioArr;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_new_msg, container, false);
        return view;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        application = (MyApplication)this.getActivity().getApplication();

        msg_title=(FrameLayout) getView().findViewById(R.id.msg_title);

        tv = (TextView) msg_title.findViewById(R.id.titleTv);
        tv.setText("消息");
        backBtn = (ImageButton) msg_title.findViewById(R.id.backBtn);
        backBtn.setVisibility(View.GONE);

//        mFragments = new Fragment[4];
//        fragmentManager =this.getChildFragmentManager();
//        mFragments[0] = fragmentManager.findFragmentById(R.id.fragement_subscribe);
//        mFragments[1] = fragmentManager.findFragmentById(R.id.fragement_personal);
//        mFragments[2] = fragmentManager.findFragmentById(R.id.fragement_hang_qing);
//        mFragments[3] = fragmentManager.findFragmentById(R.id.fragement_system);
        setFragmentIndicator();

    }

    @Override
    public void onResume() {
        super.onResume();
        if(this.isVisible()) {
            this.openHandler(index);
        }
    }


    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        if(!hidden){
            this.openHandler(index);
        }
    }

    private void openHandler(int index){
        this.index=index;
//        fragmentTransaction = fragmentManager.beginTransaction()
//                .hide(mFragments[0]).hide(mFragments[1])
//                .hide(mFragments[2]).hide(mFragments[3]);
//        fragmentTransaction.show(mFragments[index]).commitAllowingStateLoss();
//        radioArr.get(index).setChecked(true);

        //获取详情Fragment的实例
        if(index==1) {
            SubscribeFragment df = SubscribeFragment.newInstance(index);
            //获取FragmentTransaction 实例
            FragmentTransaction ft = getChildFragmentManager().beginTransaction();
            //使用DetailsFragment 的实例
            ft.replace(R.id.detials, df);
            ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
            ft.commit();
        }else{
            FragmentMsgList df = FragmentMsgList.getInstance(index);
            //获取FragmentTransaction 实例
            FragmentTransaction ft = getChildFragmentManager().beginTransaction();
            //使用DetailsFragment 的实例
            ft.replace(R.id.detials, df);
            ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
            ft.commit();
        }

        checkLogin();
    }

    private void setFragmentIndicator() {

//        topRg = (RadioGroup) this.getView().findViewById(R.id.topRg);
        msgOne = (RadioButton) this.getView().findViewById(R.id.msgOne);
        msgTwo = (RadioButton) this.getView().findViewById(R.id.msgTwo);
        msgThree = (RadioButton) this.getView().findViewById(R.id.msgThree);
        msgFour = (RadioButton) this.getView().findViewById(R.id.msgFour);

        radioArr=new ArrayList<RadioButton>();
        radioArr.add(msgOne);
        radioArr.add(msgTwo);
        radioArr.add(msgThree);
        radioArr.add(msgFour);
//        topRg.setOnCheckedChangeListener(this);

        msgOne.setOnClickListener(this);
        msgTwo.setOnClickListener(this);
        msgThree.setOnClickListener(this);
        msgFour.setOnClickListener(this);
    }

    private void checkLogin(){
        if(IntentUtil.isConnect(this.getActivity()) && application.getUserId(this.getActivity()).equals("-1")){
            LoginUtil.gotoLogin(this.getActivity(),true, new LoginUtil.Callback() {
                @Override
                public void onCom() {
                    getMsgList();
                }
            });
        }else{
            getMsgList();
        }
    }

    /*
   * 向服务器发送请求消息列表
   * */
    private void getMsgList(){
        RequestParams params=new RequestParams();
        params.put("userId",application.getUserId(this.getActivity()));

        HttpUtil.get(Config.GetUnReadMsgCount, params, new AsyncHttpResponseHandler() {
            @Override
            public void onFailure(Throwable error, String content) {
                super.onFailure(error, content);
            }

            @Override
            public void onSuccess(String content) {
                super.onSuccess(content);
                if(getActivity()==null)return;

                try {
                    JSONArray jsonArray = new JSONArray(content);

                    for (int i = 0; i < radioArr.size(); i++) {
                        JSONObject object = (JSONObject) jsonArray.get(i);
                        String aa = (i + 1) + "";
                        Object count = object.get(aa);

                        BadgeView badge= (BadgeView) radioArr.get(i).getTag();
                        if(badge==null) {
                            badge = new BadgeView(getActivity());
                            badge.setTargetView(radioArr.get(i));
                            radioArr.get(i).setTag(badge);

                            badge.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.ITALIC));
                            badge.setShadowLayer(2, -1, -1, Color.GREEN);
                            badge.setBadgeGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
                            badge.setBadgeMargin(0, 0, 8, 0);
                            badge.setBadgeCount((Integer) count);
                        }else {
                            badge.setBadgeCount((Integer) count);
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        });
    }


    @Override
    public void onClick(View v) {
        for(RadioButton rb:radioArr){
            rb.setChecked(false);
        }
        RadioButton rb= (RadioButton) v;
        rb.setChecked(true);
        openHandler(radioArr.indexOf(v)+1);
    }

    @Override
    public void onCheckedChanged(RadioGroup group, int checkedId) {
        switch (checkedId){
            case R.id.msgOne:
                openHandler(1);
                break;
            case R.id.msgTwo:
                openHandler(2);
                break;
            case R.id.msgThree:
                openHandler(3);
                break;
            case R.id.msgFour:
                openHandler(4);
                break;
        }
    }
}
