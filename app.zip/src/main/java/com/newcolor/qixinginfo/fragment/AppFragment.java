package com.newcolor.qixinginfo.fragment;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.activity.BaiduMapActivity;
import com.newcolor.qixinginfo.activity.FuturesActivity;
import com.newcolor.qixinginfo.activity.FuturesListActivity;
import com.newcolor.qixinginfo.activity.OpinionActivity;
import com.newcolor.qixinginfo.activity.PayInfoActivity;
import com.newcolor.qixinginfo.activity.QrCodeActivity;
import com.newcolor.qixinginfo.activity.ReleaseGongQiuActivity;
import com.newcolor.qixinginfo.adapter.AppAdapter;
import com.newcolor.qixinginfo.adapter.SubscribeAdapter;
import com.newcolor.qixinginfo.global.MyApplication;
import com.newcolor.qixinginfo.model.AppVO;
import com.newcolor.qixinginfo.util.LoginUtil;
import com.newcolor.qixinginfo.util.SharedUtil;
import com.newcolor.qixinginfo.util.Tools;

import java.util.ArrayList;

/**
 * 应用的fragment
 *
 * Created by Administrator on 2015/10/8.
 */
public class AppFragment extends Fragment implements AdapterView.OnItemClickListener {
    private MyApplication application;
    private GridView app_GV;
    private AppAdapter appAdapter;
    private ArrayList<AppVO> mListItems;
    private SubscribeAdapter mAdapter;
    private ListView mListView;
    private FrameLayout app_title;
    private ImageButton backBtn;
    private TextView tv;
    private static final int[] viewIdArr={R.id.icon_IV, R.id.name_TV};
    private static final String[] appNameArr={"发布货源","发布需求","分享","二维码","支付方式","意见反馈","废废地图","期货行情"};
    private static final int[] appIconArr={R.mipmap.gong_huo_icon, R.mipmap.xu_qiu_icon, R.mipmap.fen_xiang_icon
            , R.mipmap.qr_code_icon, R.mipmap.pay_info_icon, R.mipmap.opinion_icon, R.mipmap.bai_du_map_icon, R.mipmap.bai_du_map_icon};

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_app, container, false);
        return view;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        application = (MyApplication) this.getActivity().getApplication();
        app_title=(FrameLayout) getView().findViewById(R.id.app_title);

        tv = (TextView) app_title.findViewById(R.id.titleTv);
        backBtn = (ImageButton) app_title.findViewById(R.id.backBtn);
        tv.setText("应用");
        backBtn.setVisibility(View.GONE);

        app_GV= (GridView) this.getActivity().findViewById(R.id.app_GV);

        mListItems = new ArrayList<AppVO>();
        appAdapter = new AppAdapter(this.getActivity(),mListItems, R.layout.item_list_app,viewIdArr);

        app_GV.setAdapter(appAdapter);
        app_GV.setOnItemClickListener(this);

        this.updateDate();
    }


    private void updateDate(){
        int count= SharedUtil.getInt(this.getActivity(), "newYingYongNum");

        AppVO vo;
        for(int i=0;i<appNameArr.length;i++){
            vo=new AppVO();
            vo.setIconId(appIconArr[i]);
            vo.setName(appNameArr[i]);
            if(i>appNameArr.length-1-count){
                vo.setIsNew(true);
            }
            mListItems.add(vo);
        }

        appAdapter.notifyDataSetChanged();
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        if(application.getUserId(this.getActivity()).equals("-1")){
            LoginUtil.gotoLogin(this.getActivity());
            return;
        }

        GridView listView = (GridView) parent;
        AppVO vo = (AppVO) listView.getItemAtPosition(position);
        Intent intent;
        if(vo.getName().equals("发布货源")){
            intent=new Intent(this.getActivity(), ReleaseGongQiuActivity.class);
            intent.putExtra("type", ReleaseGongQiuActivity.RELEASE_HUO_YUAN);
            startActivity(intent);
        }else if(vo.getName().equals("发布需求")){
            intent=new Intent(this.getActivity(), ReleaseGongQiuActivity.class);
            intent.putExtra("type", ReleaseGongQiuActivity.RELEASE_XU_QIU);
            startActivity(intent);
        }else if(vo.getName().equals("分享")){
            Tools.showShare(this.getActivity(), null, false);
        }else if(vo.getName().equals("二维码")){
            intent=new Intent(this.getActivity(), QrCodeActivity.class);
            startActivity(intent);
        }else if(vo.getName().equals("支付方式")){
            intent=new Intent(this.getActivity(), PayInfoActivity.class);
            intent.putExtra("type",1);
            startActivity(intent);
        }else if(vo.getName().equals("意见反馈")){
            intent=new Intent(this.getActivity(), OpinionActivity.class);
            startActivity(intent);
        }else if(vo.getName().equals("期货行情")){
            intent=new Intent(this.getActivity(), FuturesListActivity.class);
            startActivity(intent);
        }else if(vo.getName().equals("百度地图")){
            intent=new Intent(this.getActivity(), BaiduMapActivity.class);
            startActivity(intent);
        }
    }
}
