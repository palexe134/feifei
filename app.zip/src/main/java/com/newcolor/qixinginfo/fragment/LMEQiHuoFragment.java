package com.newcolor.qixinginfo.fragment;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.activity.FuturesActivity;
import com.newcolor.qixinginfo.adapter.FuturesAdapter;
import com.newcolor.qixinginfo.entity.FutruesEntity;
import com.newcolor.qixinginfo.global.MyApplication;
import com.newcolor.qixinginfo.util.ProtocolUtil;
import com.newcolor.qixinginfo.util.ToastUtil;

import java.util.ArrayList;

/**
 * LME伦敦期货fragment
 */
public class LMEQiHuoFragment extends Fragment implements AdapterView.OnItemClickListener {
	private Context mContext;
	private MyApplication application;
	private ListView mListView;
	private FuturesAdapter mAdapter;
	private ArrayList<FutruesEntity> mListItems;
	private static final String[] ziXuanArr={"CAD","AHD","NID","PBD","SND","ZSD","HG","CL"
			,"SI","GC","DXF"};
	private static final String[] lianXuArr={};
	private int TIME = 5000;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_zi_xuan, null);

		return view;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		application = (MyApplication) this.getActivity().getApplication();
		mContext = this.getActivity();

		mListItems=new ArrayList<FutruesEntity>();
		mAdapter=new FuturesAdapter(this.getActivity(),mListItems,null);

		mListView= (ListView) this.getActivity().findViewById(R.id.data_LV);
		mListView.setAdapter(mAdapter);

		mListView.setOnItemClickListener(this);
		this.initData();
	}

	@Override
	public void onResume() {
		super.onResume();
		handler.postDelayed(runnable, TIME);
	}

	private void initData(){
		String listStr="";
		for(String str:ziXuanArr){
			listStr+="hf_"+str+",";
		}

		for(String str:lianXuArr){
			listStr+=str+",";
		}

		ProtocolUtil.getFutruesEntityList("http://hq.sinajs.cn/list=" + listStr, new ProtocolUtil.CallBack() {
			@Override
			public void onListCom(ArrayList list) {
				mListItems.clear();
				mListItems.addAll(list);

				mAdapter.notifyDataSetChanged();
			}

			@Override
			public void onVoCom(FutruesEntity vo) {

			}
		});
	}


	Handler handler = new Handler();
	Runnable runnable = new Runnable() {
		@Override
		public void run() {
			initData();
			handler.postDelayed(this, TIME);
		}
	};




	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
		ListView listView= (ListView) parent;
		FutruesEntity vo = (FutruesEntity) listView.getItemAtPosition(position);

		Intent intent=new Intent(this.getActivity(),FuturesActivity.class);
		intent.putExtra("FutruesEntity",vo);
		startActivity(intent);
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		handler.removeCallbacks(runnable);
	}

	@Override
	public void onPause() {
		super.onPause();
		handler.removeCallbacks(runnable);
	}
}
