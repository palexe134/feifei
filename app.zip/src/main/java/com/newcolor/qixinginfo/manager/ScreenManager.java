package com.newcolor.qixinginfo.manager;

import android.app.Activity;

import java.util.Stack;

/**
 * 场景管理类，用来全局退出应用程序
 * Created by baolei.si on 2015/8/29.
 */
public class ScreenManager {
    private static Stack<Activity> activityStack;
    private static ScreenManager instance;


    public static ScreenManager getInstance() {
        if (instance == null) {
            instance = new ScreenManager();
        }
        return instance;
    }

    public void pushActivity(Activity activity){
        if(activityStack==null){
            activityStack=new Stack<Activity>();
        }
        activityStack.add(activity);
    }
    public void popAllActivity(){
       for(Activity activity:activityStack){
           activity.finish();
       }
        activityStack.clear();
    }

}


