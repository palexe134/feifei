package com.newcolor.qixinginfo.upload;

import java.io.File;
import java.io.IOException;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.content.ByteArrayBody;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.view.View;

import com.newcolor.qixinginfo.adapter.GongQiuAdapter;
import com.newcolor.qixinginfo.global.MyApplication;
import com.newcolor.qixinginfo.util.ToastUtil;

/**
 * 图片上传
 */
public class HttpMultipartPost extends AsyncTask<String, Integer, String> {

	private Context context;
	private String filePath,fileName;
	private byte[] fileData;
	private ProgressDialog pd;
	private long totalSize;
	private Callback onCallback;


	public HttpMultipartPost(Context context, String filePath) {
		this.context = context;
		this.filePath = filePath;
	}

	public HttpMultipartPost(Context context,byte[] fileData,String fileName,Callback onCallback){
		this.context=context;
		this.fileData=fileData;
		this.fileName=fileName;
		this.onCallback=onCallback;
	}

	@Override
	protected void onPreExecute() {
		pd = new ProgressDialog(context);
		pd.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
		pd.setMessage("正在上传...");
		pd.setCancelable(false);
		pd.show();
	}

	@Override
	protected String doInBackground(String... params) {
		String serverResponse = null;

		HttpClient httpClient = new DefaultHttpClient();
		HttpContext httpContext = new BasicHttpContext();
		HttpPost httpPost = new HttpPost("http://service.aaaly.com/f/index.php/home/index/uploadImg/");

		try {
			CustomMultipartEntity multipartContent = new CustomMultipartEntity(
					new CustomMultipartEntity.ProgressListener() {
						@Override
						public void transferred(long num) {
							publishProgress((int) ((num / (float) totalSize) * 100));
						}
					});
			StringBody stringBody1 = new StringBody(MyApplication.getInstance().getUserId(this.context));
			// We use FileBody to transfer an image
//			multipartContent.addPart("data", new FileBody(new File(filePath)));
			multipartContent.addPart("userId",stringBody1);
			multipartContent.addPart("data", new ByteArrayBody(fileData, this.fileName));
			totalSize = multipartContent.getContentLength();

			// Send it
			httpPost.setEntity(multipartContent);
			HttpResponse response = httpClient.execute(httpPost, httpContext);
			serverResponse = EntityUtils.toString(response.getEntity());

		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (httpClient != null) {
				httpClient.getConnectionManager().shutdown();
				httpClient = null;
			}
		}

		return serverResponse;
	}

	@Override
	protected void onProgressUpdate(Integer... progress) {
		pd.setProgress((int) (progress[0]));
	}

	@Override
	protected void onPostExecute(String result) {
		System.out.println("result: " + result);
		JSONObject jsonObject= null;
		try {
			jsonObject = new JSONObject(result);
			byte isSuc= Byte.parseByte(jsonObject.getString("isSuc"));
			String msg=jsonObject.getString("msg");
			if(isSuc==0){
				ToastUtil.showToast(this.context, msg);
			}else{
				String urlImg=jsonObject.getString("urlImg");
				ToastUtil.showToast(this.context, msg);
				this.onCallback.onCom(urlImg);
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
		pd.dismiss();
	}

	@Override
	protected void onCancelled() {
		System.out.println("cancle");
	}

	/**
	 * 自定义接口，用于回调按钮点击事件到Activity
	 * @author Ivan Xu
	 * 2014-11-26
	 */
	public interface Callback {
		public void onCom(String url);
	}

}
