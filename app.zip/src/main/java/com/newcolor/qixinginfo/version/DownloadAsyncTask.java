/**
 * Copyright(c)2012 Beijing PeaceMap Co. Ltd.
 * All right reserved. 
 */
package com.newcolor.qixinginfo.version;

import android.os.AsyncTask;
import android.os.Environment;


import com.newcolor.qixinginfo.util.IntentUtil;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;


/**
 * 异步下载数据
 * @author： aokunsang
 * @date： 2012-12-17
 */
public class DownloadAsyncTask extends AsyncTask<String, Integer, String> {

	private DownloadCallback downCallBack;
	private HttpURLConnection urlConn;
	
	public DownloadAsyncTask(DownloadCallback downloadCallback){
		this.downCallBack = downloadCallback;
	}
	
	@Override
	protected void onPreExecute() {
		downCallBack.onDownloadPreare();
		super.onPreExecute();
	}
	
	@Override
	protected String doInBackground(String... args) {
		String apkDownloadUrl = args[0]; //apk下载地址
		String apkName = args[1];   //apk在sd卡中的安装位置
		String apkSize=args[2];
		String result = "";
		if(!IntentUtil.checkURL(apkDownloadUrl)){
			result = "netfail";
		}else{
			InputStream is = null;
			FileOutputStream fos = null;
			try {
				URL url = new URL(apkDownloadUrl);
				urlConn = (HttpURLConnection)url.openConnection();
				urlConn.setRequestProperty("Accept-Encoding", "identity");
				urlConn.connect();
				int length = Integer.parseInt(apkSize);   //文件大小
				is = urlConn.getInputStream();
				String path=Environment.getExternalStorageDirectory()+"/"+apkName;
				fos = new FileOutputStream(path);

				int count = 0,numread = 0;
				byte buf[] = new byte[1024];
				
				while(!downCallBack.onCancel()&& (numread = is.read(buf))!=-1){
					count+=numread;
					int progressCount =(int)(((float)count / length) * 100);
					publishProgress(progressCount);
					fos.write(buf, 0, numread);
				}
				fos.flush();
				result = "success";
			} catch (Exception e) {
				e.printStackTrace();
				result = "fail";
			}finally{
				try {
					if(fos!=null)
						fos.close();
					if(is!=null)
						is.close();
				} catch (IOException e) {
					e.printStackTrace();
					result = "fail";
				}
			}
		}
		return result;
	}
	
	@Override
	protected void onProgressUpdate(Integer... values) {
		downCallBack.onChangeProgress(values[0]);
		super.onProgressUpdate(values);
	}
	
	@Override
	protected void onPostExecute(String result) {
		if(downCallBack.onCancel()){
			downCallBack.onCompleted(false, "版本更新下载已取消。");
		}else if("success".equals(result)){
			downCallBack.onCompleted(true, null);
		}else if("netfail".equals(result)){
			downCallBack.onCompleted(false, "连接服务器失败，请稍后重试。");
		}else{
			downCallBack.onCompleted(false, "版本更新失败，请稍后重试。");
		}
		super.onPostExecute(result);
	}
	
	@Override
	protected void onCancelled() {
		if(urlConn!=null){
			urlConn.disconnect();
		}
		super.onCancelled();
	}
}
