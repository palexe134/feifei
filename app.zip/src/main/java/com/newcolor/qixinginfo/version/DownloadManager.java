/**
 * Copyright(c)2012 Beijing PeaceMap Co. Ltd.
 * All right reserved. 
 */
package com.newcolor.qixinginfo.version;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Handler;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

import com.newcolor.qixinginfo.dialog.AlertDialog;
import com.newcolor.qixinginfo.global.Config;
import com.newcolor.qixinginfo.global.Constant;
import com.newcolor.qixinginfo.http.AsyncHttpResponseHandler;
import com.newcolor.qixinginfo.http.RequestParams;
import com.newcolor.qixinginfo.model.ApkInfo;
import com.newcolor.qixinginfo.util.HttpUtil;
import com.newcolor.qixinginfo.util.IntentUtil;

import org.json.JSONObject;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 下载管理
 * @author： aokunsang
 * @date： 2012-12-18
 */
public class DownloadManager{

	private Context mContext;
	
	final static int CHECK_FAIL = 0;
	final static int CHECK_SUCCESS = 1;
	final static int CHECK_NOUPGRADE = 2;
	final static int CHECK_NETFAIL = 3;
	
	private ApkInfo apkinfo;
	private AlertDialog noticeDialog;    //提示弹出框
	private ProgressDialog progressDialog;
	
	private boolean isAccord;  //是否主动检查软件升级
	private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	private CallBackHandler callBackHandler;
	
	
	public DownloadManager(Context mContext,boolean isAccord){
		this.mContext = mContext;
		this.isAccord = isAccord;
	}
	
	Handler handler = new Handler(){
		public void handleMessage(android.os.Message msg) {
			if(progressDialog!=null){
				progressDialog.dismiss();
			}
			switch(msg.what){
				case CHECK_SUCCESS:{
					showNoticeDialog();
					break;
				}
				case CHECK_NOUPGRADE:{  //不需要更新
					if(isAccord) Toast.makeText(mContext, "当前版本是最新版。", Toast.LENGTH_SHORT).show();
					break;
				}
				case CHECK_NETFAIL:{
					if(isAccord) Toast.makeText(mContext, "网络连接不正常。", Toast.LENGTH_SHORT).show();
					break;
				}
				case CHECK_FAIL:{
					if(isAccord) Toast.makeText(mContext, "从服务器获取更新数据失败。", Toast.LENGTH_SHORT).show();
					break;
				}
			}
		};
	};
	
	/* 检查下载更新 [apk下载入口] */
	public void checkDownload(CallBackHandler cbHandler){
		this.callBackHandler=cbHandler;
		if(isAccord) progressDialog = ProgressDialog.show(mContext, "", "请稍后，正在检查更新...");


		HttpUtil.get(Config.GetVersionInfo, new RequestParams(), new AsyncHttpResponseHandler() {
			@Override
			public void onFailure(Throwable error, String content) {
				super.onFailure(error, content);
			}

			@Override
			public void onSuccess(String content) {
				super.onSuccess(content);

				if (content != null && !content.isEmpty()) {
					try {

						JSONObject obj = new JSONObject(content);
						String apkVersion = obj.getString("apkVersion");
						int apkCode = obj.getInt("apkVerCode");
						String apkSize = obj.getString("apkSize");
						String apkName = obj.getString("apkName");
						String downloadUrl = obj.getString("apkDownloadUrl");
//						String downloadUrl = "http://down.aaaly.com/index.php?dir=feifei&name=app.apk";
						String apkLog = obj.getString("apklog");
						apkinfo = new ApkInfo(downloadUrl, apkVersion, apkSize, apkCode, apkName, apkLog);
						if (apkinfo != null && checkApkVercode()) {  //检查版本号
							alreayCheckTodayUpdate();    //设置今天已经检查过更新
							handler.sendEmptyMessage(CHECK_SUCCESS);
						} else {
							handler.sendEmptyMessage(CHECK_NOUPGRADE);
							if (callBackHandler != null) {
								callBackHandler.onCallBack();
								callBackHandler = null;
							}
						}
					} catch (Exception e) {
						e.printStackTrace();
						handler.sendEmptyMessage(CHECK_FAIL);
					}
				}
			}
		});

		/*apkinfo = new ApkInfo("http://58.57.35.3:8056/appDownload/sto_OA.apk", "1.0.0", "2.33MB", 0, "sto_OA.apk", "1.测试aaaa");
		if (apkinfo != null && checkApkVercode()) {  //检查版本号
			alreayCheckTodayUpdate();    //设置今天已经检查过更新
			handler.sendEmptyMessage(CHECK_SUCCESS);
		} else {
			handler.sendEmptyMessage(CHECK_NOUPGRADE);
			if(callBackHandler!=null){
				callBackHandler.onCallBack();
				callBackHandler=null;
			}
		}*/

	}
	/* 弹出软件更新提示对话框*/
	private void showNoticeDialog(){
		double apkSize=Double.parseDouble(apkinfo.getApkSize());
		double size=apkSize/1024/1024;
		DecimalFormat df=new DecimalFormat("#.##");

		StringBuffer sb = new StringBuffer();
		sb.append("版本号："+apkinfo.getApkVersion()+"\n")
		.append("文件大小："+df.format(size)+"MB\n")
		.append("更新日志：\n"+apkinfo.getApkLog());

		new AlertDialog(this.mContext).builder().setTitle("版本更新")
				.setMsg(sb.toString())
				.setPositiveButton("下载", new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						DownloadCallback downCallback = new DownloadInstall(mContext, apkinfo.getApkName(), apkinfo.getApkVersion(), apkinfo.getApkCode(),callBackHandler);
						DownloadAsyncTask request = new DownloadAsyncTask(downCallback);
						request.execute(apkinfo.getDownloadUrl(), apkinfo.getApkName(), apkinfo.getApkSize());
					}
				}).setNegativeButton("以后再说", new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						if(callBackHandler!=null){
							callBackHandler.onCallBack();
							callBackHandler=null;
						}
					}
				}).show();

//		Builder builder = new Builder(mContext);
//		builder.setTitle("版本更新").setMessage(sb.toString());
//		builder.setPositiveButton("下载", new DialogInterface.OnClickListener(){
//			@Override
//			public void onClick(DialogInterface dialog, int which) {
//
//			}
//		});
//		builder.setNegativeButton("以后再说", new DialogInterface.OnClickListener(){
//			@Override
//			public void onClick(DialogInterface dialog, int which) {
//				dialog.dismiss();
//
//
//			}
//		});
//		noticeDialog = builder.create();
//		noticeDialog.getWindow().setType(WindowManager.LayoutParams.TYPE_SYSTEM_ALERT);   //设置最顶层Alertdialog
//		noticeDialog.show();
	}
	
	/**
	 * 根据日期检查是否需要进行软件升级
	 * @throws Exception 
	 */
	private boolean checkTodayUpdate() {
		SharedPreferences sharedPreference = mContext.getSharedPreferences(UpdateShared.SETTING_UPDATE_APK_INFO, 0);
		String checkDate = sharedPreference.getString(UpdateShared.CHECK_DATE, "");
		String updateDate = sharedPreference.getString(UpdateShared.UPDATE_DATE, "");
//		Log.i("---------------checkDate------------", checkDate);
//		Log.i("---------------updateDate------------", updateDate);
		if("".equals(checkDate) && "".equals(updateDate)){  //刚安装的新版本，设置详细信息
			int verCode = IntentUtil.getCurrentVersionCode(mContext);
			String versionName = IntentUtil.getCurrentVersionName(mContext);
			String dateStr = sdf.format(new Date());
			sharedPreference.edit().putString(UpdateShared.CHECK_DATE, dateStr)
			.putString(UpdateShared.UPDATE_DATE, dateStr)
			.putString(UpdateShared.APK_VERSION, versionName)
			.putInt(UpdateShared.APK_VERCODE, verCode).commit();
			return true;
		}
		try {
			//判断defaultMinUpdateDay天内不检查升级
			if((new Date().getTime()-sdf.parse(updateDate).getTime())/1000/3600/24< Constant.defaultMinUpdateDay){
				return false;
			}else if(checkDate.equalsIgnoreCase(sdf.format(new Date()))){//判断今天是否检查过升级
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	/**
	 * 设置今天已经检查过升级
	 * @return
	 */
	private void alreayCheckTodayUpdate(){
		String date = sdf.format(new Date());
		SharedPreferences sharedPreference = mContext.getSharedPreferences(UpdateShared.SETTING_UPDATE_APK_INFO, 0);
		sharedPreference.edit().putString(UpdateShared.CHECK_DATE, date).commit();
	}
	/**
	 * 检查版本是否需要更新
	 * @return
	 */
	private boolean checkApkVercode(){
		int verCode = IntentUtil.getCurrentVersionCode(mContext);
		if(apkinfo.getApkCode()>verCode){
			return true;
		}else{
			return false;
		}
	}
	
	static interface UpdateShared{
	   String SETTING_UPDATE_APK_INFO = "cbt_upgrade_setting";
	   String UPDATE_DATE = "updatedate";
	   String APK_VERSION = "apkversion";
	   String APK_VERCODE = "apkvercode";
	   String CHECK_DATE = "checkdate";
	}

	public interface CallBackHandler{
		void onCallBack();
	}
}
