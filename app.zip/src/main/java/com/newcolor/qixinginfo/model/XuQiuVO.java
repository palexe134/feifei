package com.newcolor.qixinginfo.model;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Administrator on 2015/10/12.
 */
public class XuQiuVO implements Parcelable {
    private String imgUrl;
    private String title;
    private String content;
    private String telephone;
    private String adress;
    private int star;


    public static final Creator<XuQiuVO> CREATOR = new Creator<XuQiuVO>() {

        @Override
        public XuQiuVO createFromParcel(Parcel source) {
            XuQiuVO appVO = new XuQiuVO();
            appVO.imgUrl = source.readString();
            appVO.title = source.readString();
            appVO.content = source.readString();
            appVO.telephone = source.readString();
            appVO.adress = source.readString();
            appVO.star = source.readInt();
            return appVO;
        }

        @Override
        public XuQiuVO[] newArray(int size) {
            return new XuQiuVO[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int flags) {
        parcel.writeString(imgUrl);
        parcel.writeString(title);
        parcel.writeString(content);
        parcel.writeString(telephone);
        parcel.writeString(adress);
        parcel.writeInt(star);
    }
}
