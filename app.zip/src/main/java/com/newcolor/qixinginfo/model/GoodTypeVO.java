package com.newcolor.qixinginfo.model;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Administrator on 2015/10/12.
 */
public class GoodTypeVO implements Parcelable {
    private int sId;
    private String name;
    private int pId;



    public String getName() {
        if(name!=null) {
            return name;
        }else{
            return "";
        }
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getsId() {
        return sId;
    }

    public void setsId(int sId) {
        this.sId = sId;
    }

    public int getpId() {
        return pId;
    }

    public void setpId(int pId) {
        this.pId = pId;
    }

    public static final Creator<GoodTypeVO> CREATOR = new Creator<GoodTypeVO>() {

        @Override
        public GoodTypeVO createFromParcel(Parcel source) {
            GoodTypeVO appVO = new GoodTypeVO();
            appVO.sId = source.readInt();
            appVO.name = source.readString();
            appVO.pId = source.readInt();
            return appVO;
        }

        @Override
        public GoodTypeVO[] newArray(int size) {
            return new GoodTypeVO[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int flags) {
        parcel.writeInt(sId);
        parcel.writeString(name);
        parcel.writeInt(pId);
    }
}
