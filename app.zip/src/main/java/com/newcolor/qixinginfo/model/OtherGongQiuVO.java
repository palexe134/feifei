package com.newcolor.qixinginfo.model;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;

/**
 * Created by Administrator on 2015/10/27.
 */
public class OtherGongQiuVO implements Parcelable {
    private String id;
    private String title;
    private String price;
    private String num;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public static final Parcelable.Creator<OtherGongQiuVO> CREATOR = new Creator<OtherGongQiuVO>() {

        @Override
        public OtherGongQiuVO createFromParcel(Parcel source) {
            OtherGongQiuVO vo = new OtherGongQiuVO();
            vo.id = source.readString();
            vo.title = source.readString();
            vo.price = source.readString();
            vo.num = source.readString();
            return vo;
        }

        @Override
        public OtherGongQiuVO[] newArray(int size) {
            return new OtherGongQiuVO[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int flags) {
        parcel.writeString(id);
        parcel.writeString(title);
        parcel.writeString(price);
        parcel.writeString(num);
    }
}
