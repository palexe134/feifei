package com.newcolor.qixinginfo.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.activeandroid.annotation.Column;
import com.activeandroid.annotation.Table;

import java.util.ArrayList;

/**
 * Created by Administrator on 2015/10/27.
 */
public class GongQiuInfoVO implements Parcelable {
    private String sId;
    private String userId;
    private String urlArr;
    private String companyName;
    private String address;
    private String phone;
    private String num;
    private String price;
    private String content;
    private String title;
    private String name;
    private String companyDis;
    private int classificationId;
    private String coordinate;
    private int topId;
    private ArrayList<OtherGongQiuVO> otherData;


    public String getsId() {
        return sId;
    }

    public void setsId(String sId) {
        this.sId = sId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getTopId() {
        return topId;
    }

    public void setTopId(int topId) {
        this.topId = topId;
    }

    public int getClassificationId() {
        return classificationId;
    }

    public void setClassificationId(int classificationId) {
        this.classificationId = classificationId;
    }

    public String getCoordinate() {
        return coordinate;
    }

    public void setCoordinate(String coordinate) {
        this.coordinate = coordinate;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String[] getUrlArr() {
        return urlArr==null?new String[0]:urlArr.split(",");
    }

    public void setUrlArr(String urlArr) {
        this.urlArr = urlArr;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getAddress() {
        String[] addressArr=address.split(",");
        address="";
        for (int i=0;i<addressArr.length;i++){
            address+=addressArr[i];
        }
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getCompanyDis() {
        return companyDis;
    }

    public void setCompanyDis(String companyDis) {
        this.companyDis = companyDis;
    }

    public ArrayList<OtherGongQiuVO> getOtherData() {
        return otherData;
    }

    public void setOtherData(ArrayList<OtherGongQiuVO> otherData) {
        this.otherData = otherData;
    }

    public static final Parcelable.Creator<GongQiuInfoVO> CREATOR = new Creator<GongQiuInfoVO>() {

        @Override
        public GongQiuInfoVO createFromParcel(Parcel source) {
            GongQiuInfoVO appVO = new GongQiuInfoVO();
            appVO.sId=source.readString();
            appVO.userId=source.readString();
            appVO.name=source.readString();
            appVO.title=source.readString();
            appVO.classificationId=source.readInt();
            appVO.topId=source.readInt();
            appVO.urlArr = source.readString();
            appVO.companyName = source.readString();
            appVO.address = source.readString();
            appVO.phone = source.readString();
            appVO.num = source.readString();
            appVO.price = source.readString();
            appVO.content = source.readString();
            appVO.companyDis = source.readString();

            appVO.otherData = new ArrayList<OtherGongQiuVO>();
            source.readTypedList(appVO.otherData, OtherGongQiuVO.CREATOR);

            return appVO;
        }

        @Override
        public GongQiuInfoVO[] newArray(int size) {
            return new GongQiuInfoVO[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int flags) {
        parcel.writeString(sId);
        parcel.writeString(userId);
        parcel.writeString(name);
        parcel.writeString(title);
        parcel.writeInt(classificationId);
        parcel.writeInt(topId);
        parcel.writeString(urlArr);
        parcel.writeString(companyName);
        parcel.writeString(address);
        parcel.writeString(phone);
        parcel.writeString(num);
        parcel.writeString(price);
        parcel.writeString(content);
        parcel.writeString(companyDis);

        parcel.writeTypedList(otherData);
    }
}