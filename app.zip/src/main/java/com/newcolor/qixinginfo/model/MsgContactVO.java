package com.newcolor.qixinginfo.model;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Administrator on 2015/10/12.
 */
public class MsgContactVO implements Parcelable {
    private String headImg;
    private String name;
    private String phone;

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getHeadImg() {
        return headImg;
    }

    public void setHeadImg(String headImg) {
        this.headImg = headImg;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public static final Creator<MsgContactVO> CREATOR = new Creator<MsgContactVO>() {

        @Override
        public MsgContactVO createFromParcel(Parcel source) {
            MsgContactVO appVO = new MsgContactVO();
            appVO.headImg = source.readString();
            appVO.name = source.readString();
            appVO.phone = source.readString();
            return appVO;
        }

        @Override
        public MsgContactVO[] newArray(int size) {
            return new MsgContactVO[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int flags) {
        parcel.writeString(headImg);
        parcel.writeString(name);
        parcel.writeString(phone);
    }
}
