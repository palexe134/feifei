package com.newcolor.qixinginfo.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.baidu.mapapi.model.LatLng;

import java.util.ArrayList;

/**
 * Created by Administrator on 2015/10/27.
 */
public class BaiDuMapGongQiuVO extends BaiDuMapGeoVO {

    private String num;
    private String price;


    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public static final Creator<BaiDuMapGongQiuVO> CREATOR = new Creator<BaiDuMapGongQiuVO>() {

        @Override
        public BaiDuMapGongQiuVO createFromParcel(Parcel source) {
            BaiDuMapGongQiuVO appVO = new BaiDuMapGongQiuVO();
            appVO.sId = source.readString();
            appVO.address = source.readString();
            appVO.phone = source.readString();
            appVO.num = source.readString();
            appVO.price = source.readString();
            appVO.content = source.readString();
            appVO.name = source.readString();
            appVO.coordinate = source.readString();
            appVO.type = source.readInt();

            return appVO;
        }

        @Override
        public BaiDuMapGongQiuVO[] newArray(int size) {
            return new BaiDuMapGongQiuVO[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int flags) {
        parcel.writeString(sId);
        parcel.writeString(address);
        parcel.writeString(phone);
        parcel.writeString(num);
        parcel.writeString(price);
        parcel.writeString(content);
        parcel.writeString(name);
        parcel.writeString(coordinate);
        parcel.writeInt(type);
    }
}