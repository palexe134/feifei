package com.newcolor.qixinginfo.model;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Administrator on 2015/10/12.
 */
public class ContactVO implements Parcelable {
    private String id;
    private String phone;
    private String name;
    private String address;
    private String coordinate;
    private int isDefault;


    public String getCoordinate() {
        return coordinate;
    }

    public void setCoordinate(String coordinate) {
        this.coordinate = coordinate;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int isDefault() {
        return isDefault;
    }

    public void setIsDefault(int isDefault) {
        this.isDefault = isDefault;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public String getSureAddress(){
        String[] addressArr=address.split(",");
        String addressStr="";
        for (int i=0;i<addressArr.length;i++){
            addressStr+=addressArr[i];
        }
        return addressStr;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getName() {

        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public static final Creator<ContactVO> CREATOR = new Creator<ContactVO>() {

        @Override
        public ContactVO createFromParcel(Parcel source) {
            ContactVO vo = new ContactVO();
            vo.id=source.readString();
            vo.phone = source.readString();
            vo.name = source.readString();
            vo.address = source.readString();
            vo.isDefault =source.readInt();
            vo.coordinate =source.readString();
            return vo;
        }

        @Override
        public ContactVO[] newArray(int size) {
            return new ContactVO[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int flags) {
        parcel.writeString(id);
        parcel.writeString(phone);
        parcel.writeString(name);
        parcel.writeString(address);
        parcel.writeInt(isDefault);
        parcel.writeString(coordinate);
    }
}
