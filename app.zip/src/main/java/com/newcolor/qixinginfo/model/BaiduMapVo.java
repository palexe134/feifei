package com.newcolor.qixinginfo.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.baidu.mapapi.model.LatLng;

/**
 * Created by Administrator on 2016/1/27.
 */
public class BaiduMapVo implements Parcelable {
    private String coordinate;
    private String companyName;
    private String addrStr;
    private String city;
    private LatLng latLong;
    private int type;
    private String sId;


    public LatLng getLatLong() {
        if(coordinate!=null && !coordinate.isEmpty()){
            String[] coordinateArr=coordinate.split(",");
            if(coordinateArr.length>1) {
                latLong = new LatLng(Float.parseFloat(coordinateArr[1]), Float.parseFloat(coordinateArr[0]));
            }
        }
        return latLong;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getsId() {
        return sId;
    }

    public void setsId(String sId) {
        this.sId = sId;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getAddrStr() {
        return addrStr;
    }

    public void setAddrStr(String addrStr) {
        this.addrStr = addrStr;
    }

    public String getCoordinate() {
        return coordinate;
    }

    public void setCoordinate(String coordinate) {
        this.coordinate = coordinate;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public static final Parcelable.Creator<BaiduMapVo> CREATOR = new Creator<BaiduMapVo>() {

        @Override
        public BaiduMapVo createFromParcel(Parcel source) {
            BaiduMapVo vo = new BaiduMapVo();
            vo.coordinate = source.readString();
            vo.companyName = source.readString();
            vo.addrStr = source.readString();
            vo.sId = source.readString();
            vo.type = source.readInt();
            return vo;
        }

        @Override
        public BaiduMapVo[] newArray(int size) {
            return new BaiduMapVo[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int flags) {
        parcel.writeString(coordinate);
        parcel.writeString(companyName);
        parcel.writeString(addrStr);
        parcel.writeString(sId);
        parcel.writeInt(type);
    }

}