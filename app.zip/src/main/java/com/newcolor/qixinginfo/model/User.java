package com.newcolor.qixinginfo.model;


public class User {

	// ID @Id主键,int类型,数据库建表时此字段会设为自增长
	private int _id;

	private String uId;

	// 登录用户名 length=20数据字段的长度是20
	private String userName;

	// 用户密码
	private String password;


	// 是否为当前登录
	private boolean isLoginUser;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}



	public int get_id() {
		return _id;
	}

	public void set_id(int _id) {
		this._id = _id;
	}

	public void setuId(String uId) {
		this.uId = uId;
	}

	public String getuId() {
		return uId;
	}


	public boolean isLoginUser() {
		return isLoginUser;
	}

	public void setLoginUser(boolean isLoginUser) {
		this.isLoginUser = isLoginUser;
	}

}
