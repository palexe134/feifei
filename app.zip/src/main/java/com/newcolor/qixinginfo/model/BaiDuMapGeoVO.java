package com.newcolor.qixinginfo.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.baidu.mapapi.model.LatLng;

/**
 * Created by Administrator on 2015/10/27.
 */
public class BaiDuMapGeoVO implements Parcelable {

    protected String sId;
    protected String address;
    protected String phone;
    protected String name;
    protected String price;
    protected String title;
    protected String coordinate;
    protected String content;
    protected int type;

    public LatLng getLatLng(){
        LatLng ll=null;
        if(coordinate!=null && !coordinate.isEmpty()){
            String[] coorArr=coordinate.split(",");
            if(coorArr.length>=2){
                ll=new LatLng(Double.parseDouble(coorArr[1]),Double.parseDouble(coorArr[0]));
            }
        }
        return ll;
    }

    public String getsId() {
        return sId;
    }

    public void setsId(String sId) {
        this.sId = sId;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCoordinate() {
        return coordinate;
    }

    public void setCoordinate(String coordinate) {
        this.coordinate = coordinate;
    }


    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getAddress() {
        if(address==null)return "";
        String[] addressArr=address.split(",");
        address="";
        for (int i=0;i<addressArr.length;i++){
            address+=addressArr[i];
        }
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }


    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }




    public static final Creator<BaiDuMapGeoVO> CREATOR = new Creator<BaiDuMapGeoVO>() {

        @Override
        public BaiDuMapGeoVO createFromParcel(Parcel source) {
            BaiDuMapGeoVO appVO = new BaiDuMapGeoVO();
            appVO.sId = source.readString();
            appVO.address = source.readString();
            appVO.phone = source.readString();
            appVO.price = source.readString();
            appVO.name = source.readString();
            appVO.content = source.readString();
            appVO.coordinate = source.readString();
            appVO.type = source.readInt();

            return appVO;
        }

        @Override
        public BaiDuMapGeoVO[] newArray(int size) {
            return new BaiDuMapGeoVO[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int flags) {
        parcel.writeString(sId);
        parcel.writeString(address);
        parcel.writeString(phone);
        parcel.writeString(price);
        parcel.writeString(name);
        parcel.writeString(content);
        parcel.writeString(coordinate);
        parcel.writeInt(type);
    }
}