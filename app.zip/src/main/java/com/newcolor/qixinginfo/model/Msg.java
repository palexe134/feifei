package com.newcolor.qixinginfo.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.activeandroid.Model;
import com.activeandroid.annotation.Column;
import com.activeandroid.annotation.Table;
import com.newcolor.qixinginfo.util.DateUtils;

/**
 * Created by baolei.si on 2015/8/14.
 */
@Table(name = "MsgData")
public class Msg extends Model implements Parcelable {
    @Column(name = "SId", unique = true, onUniqueConflict = Column.ConflictAction.REPLACE)
    private String sId;
    @Column(name = "Type")
    private String type;
    @Column(name = "Title")
    private String title;
    @Column(name = "Content")
    private String content;
    @Column(name = "State")
    private String msgState;
    private String img;
    @Column(name = "MTime")
    private String mTime;
    private int flag;
    private boolean isSelected;
    private boolean isShow;


    public String getsId() {
        return sId;
    }

    public void setsId(String sId) {
        this.sId = sId;
    }

    public String getMsgState() {
        return msgState;
    }

    public void setMsgState(String msgState) {
        this.msgState = msgState;
    }

    public boolean isShow() {
        return isShow;
    }

    public void setIsShow(boolean isShow) {
        this.isShow = isShow;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setIsSelected(boolean isSelected) {
        this.isSelected = isSelected;
    }

    public int getFlag() {
        return flag;
    }

    public void setFlag(int flag) {
        this.flag = flag;
    }

    public String getMTime() {
        return DateUtils.formatYearDateTime(Long.parseLong(mTime)*1000);
    }

    public void setMTime(String mTime) {
        this.mTime = mTime;
    }


    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }


    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public Msg(){

    }

    public static final Creator<Msg> CREATOR = new Creator<Msg>() {

        @Override
        public Msg createFromParcel(Parcel source) {
            Msg msg = new Msg();
            msg.sId=source.readString();
            msg.type = source.readString();
            msg.title = source.readString();
            msg.msgState = source.readString();
            msg.img = source.readString();
            msg.content = source.readString();
            msg.flag = source.readInt();
            msg.mTime=source.readString();
            return msg;
        }

        @Override
        public Msg[] newArray(int size) {
            return new Msg[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int flags) {
        parcel.writeString(sId);
        parcel.writeString(type);
        parcel.writeString(title);
        parcel.writeString(msgState);
        parcel.writeString(img);
        parcel.writeString(content);
        parcel.writeInt(flag);
        parcel.writeString(mTime);
    }
    //    private
}
