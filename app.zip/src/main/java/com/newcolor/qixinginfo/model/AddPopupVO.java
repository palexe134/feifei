package com.newcolor.qixinginfo.model;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Administrator on 2015/10/12.
 */
public class AddPopupVO implements Parcelable {
    private String name;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getIconId() {
        return iconId;
    }

    public void setIconId(int iconId) {
        this.iconId = iconId;
    }

    private int iconId;

    public static final Creator<AddPopupVO> CREATOR = new Creator<AddPopupVO>() {

        @Override
        public AddPopupVO createFromParcel(Parcel source) {
            AddPopupVO appVO = new AddPopupVO();
            appVO.name = source.readString();
            appVO.iconId = source.readInt();
            return appVO;
        }

        @Override
        public AddPopupVO[] newArray(int size) {
            return new AddPopupVO[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int flags) {
        parcel.writeString(name);
        parcel.writeInt(iconId);
    }
}
