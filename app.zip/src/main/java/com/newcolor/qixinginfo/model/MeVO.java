package com.newcolor.qixinginfo.model;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Administrator on 2016/3/10.
 */
public class MeVO implements Parcelable {
    private String name;
    private int iconId;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getIconId() {
        return iconId;
    }

    public void setIconId(int iconId) {
        this.iconId = iconId;
    }

    public static final Parcelable.Creator<MeVO> CREATOR = new Creator<MeVO>() {

        @Override
        public MeVO createFromParcel(Parcel source) {
            MeVO vo = new MeVO();
            vo.name = source.readString();
            vo.iconId = source.readInt();
            return vo;
        }

        @Override
        public MeVO[] newArray(int size) {
            return new MeVO[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int flags) {
        parcel.writeString(name);
        parcel.writeInt(iconId);
    }
}
