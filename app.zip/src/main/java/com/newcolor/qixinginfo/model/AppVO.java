package com.newcolor.qixinginfo.model;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Administrator on 2015/10/12.
 */
public class AppVO implements Parcelable {
    private String iconUrl;
    private String name;
    private boolean isNew;

    public boolean isNew() {
        return isNew;
    }

    public void setIsNew(boolean isNew) {
        this.isNew = isNew;
    }

    public String getIconUrl() {
        return iconUrl;
    }

    public void setIconUrl(String iconUrl) {
        this.iconUrl = iconUrl;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getIconId() {
        return iconId;
    }

    public void setIconId(int iconId) {
        this.iconId = iconId;
    }

    private int iconId;

    public static final Parcelable.Creator<AppVO> CREATOR = new Creator<AppVO>() {

        @Override
        public AppVO createFromParcel(Parcel source) {
            AppVO appVO = new AppVO();
            appVO.iconUrl = source.readString();
            appVO.name = source.readString();
            appVO.iconId = source.readInt();
            return appVO;
        }

        @Override
        public AppVO[] newArray(int size) {
            return new AppVO[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int flags) {
        parcel.writeString(iconUrl);
        parcel.writeString(name);
        parcel.writeInt(iconId);
    }
}
