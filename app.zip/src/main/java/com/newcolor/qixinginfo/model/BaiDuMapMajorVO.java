package com.newcolor.qixinginfo.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.baidu.mapapi.model.LatLng;

/**
 * Created by Administrator on 2015/10/27.
 */
public class BaiDuMapMajorVO extends BaiDuMapGeoVO {
    private String major;

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public static final Creator<BaiDuMapMajorVO> CREATOR = new Creator<BaiDuMapMajorVO>() {

        @Override
        public BaiDuMapMajorVO createFromParcel(Parcel source) {
            BaiDuMapMajorVO appVO = new BaiDuMapMajorVO();
            appVO.sId = source.readString();
            appVO.address = source.readString();
            appVO.phone = source.readString();
            appVO.major = source.readString();
            appVO.name = source.readString();
            appVO.coordinate = source.readString();

            return appVO;
        }

        @Override
        public BaiDuMapMajorVO[] newArray(int size) {
            return new BaiDuMapMajorVO[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int flags) {
        parcel.writeString(sId);
        parcel.writeString(address);
        parcel.writeString(phone);
        parcel.writeString(major);
        parcel.writeString(name);
        parcel.writeString(coordinate);
    }
}