package com.newcolor.qixinginfo.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.activeandroid.Model;
import com.activeandroid.annotation.Column;
import com.activeandroid.annotation.Table;

import java.util.Date;


/**
 * Created by Administrator on 2015/10/12.
 */
@Table(name = "GongQiuData")
public class GongHuoVO extends Model implements Parcelable {
    @Column(name = "SId")
    private String sId;
    @Column(name = "ImgUrl")
    private String imgUrl;
    @Column(name = "Title")
    private String title;
    @Column(name = "Content")
    private String content;
    @Column(name = "Phone")
    private String phone;
    @Column(name = "Address")
    private String address;
    @Column(name = "Star")
    private int star;
    @Column(name = "Type")
    private int type;
    @Column(name = "mTime")
    private long mTime;
    @Column(name = "TopId")
    private int topId;
    @Column(name = "Distance")
    private int distance;
    private String num;
    private String price;

    private boolean isSelected;
    private boolean isShow;

    public int getDistance() {
        return distance;
    }

    public void setDistance(int distance) {
        this.distance = distance;
    }

    public int getTopId() {
        return topId;
    }

    public void setTopId(int topId) {
        this.topId = topId;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setIsSelected(boolean isSelected) {
        this.isSelected = isSelected;
    }

    public boolean isShow() {
        return isShow;
    }

    public void setIsShow(boolean isShow) {
        this.isShow = isShow;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getSId() {
        return sId;
    }

    public void setSId(String sId) {
        this.sId = sId;
    }

    public String getImgUrl() {
        return imgUrl==null?"":imgUrl.split(",")[0];
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }


    public String getAddress() {
        String[] addressArr=address.split(",");
        address="";
        for (int i=0;i<addressArr.length;i++){
            address+=addressArr[i];
        }
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getStar() {
        return star;
    }

    public void setStar(int star) {
        this.star = star;
    }

    public long getmTime() {
        return mTime;
    }

    public void setmTime(long mTime) {
        this.mTime = mTime;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public static final Creator<GongHuoVO> CREATOR = new Creator<GongHuoVO>() {

        @Override
        public GongHuoVO createFromParcel(Parcel source) {
            GongHuoVO appVO = new GongHuoVO();
            appVO.imgUrl = source.readString();
            appVO.title = source.readString();
            appVO.content = source.readString();
            appVO.phone = source.readString();
            appVO.address = source.readString();
            appVO.star = source.readInt();
            appVO.type = source.readInt();
            appVO.mTime = source.readLong();
            appVO.distance = source.readInt();
            appVO.num = source.readString();
            appVO.price = source.readString();
            return appVO;
        }

        @Override
        public GongHuoVO[] newArray(int size) {
            return new GongHuoVO[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int flags) {
        parcel.writeString(imgUrl);
        parcel.writeString(title);
        parcel.writeString(content);
        parcel.writeString(phone);
        parcel.writeString(address);
        parcel.writeInt(star);
        parcel.writeInt(type);
        parcel.writeLong(mTime);
        parcel.writeInt(distance);
        parcel.writeString(num);
        parcel.writeString(price);
    }


}
