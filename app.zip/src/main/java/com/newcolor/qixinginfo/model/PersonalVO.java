package com.newcolor.qixinginfo.model;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Administrator on 2015/10/21.
 */
public class PersonalVO implements Parcelable {
    private String val;
    private String title;
    private int type;

    public String getVal() {
        return val;
    }

    public void setVal(String val) {
        this.val = val;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public static final Parcelable.Creator<PersonalVO> CREATOR = new Creator<PersonalVO>() {

        @Override
        public PersonalVO createFromParcel(Parcel source) {
            PersonalVO appVO = new PersonalVO();
            appVO.title = source.readString();
            appVO.val = source.readString();
            appVO.type = source.readInt();
            return appVO;
        }

        @Override
        public PersonalVO[] newArray(int size) {
            return new PersonalVO[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int flags) {
        parcel.writeString(title);
        parcel.writeString(val);
        parcel.writeInt(type);
    }
}
