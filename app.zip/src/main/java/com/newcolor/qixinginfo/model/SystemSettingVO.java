package com.newcolor.qixinginfo.model;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Administrator on 2015/10/12.
 */
public class SystemSettingVO implements Parcelable {
    private String name;
    private String desc;
    //状态  1：打开  2：关闭
    private int state;
    private int position;

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public int getState() {
        return state;
    }

    public void  setState(int state) {
        this.state = state;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public static final Creator<SystemSettingVO> CREATOR = new Creator<SystemSettingVO>() {

        @Override
        public SystemSettingVO createFromParcel(Parcel source) {
            SystemSettingVO appVO = new SystemSettingVO();
            appVO.name = source.readString();
            appVO.desc = source.readString();
            appVO.state = source.readInt();
            return appVO;
        }

        @Override
        public SystemSettingVO[] newArray(int size) {
            return new SystemSettingVO[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int flags) {
        parcel.writeString(name);
        parcel.writeString(desc);
        parcel.writeInt(state);
    }
}
