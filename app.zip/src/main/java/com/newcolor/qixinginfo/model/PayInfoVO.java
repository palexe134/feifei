package com.newcolor.qixinginfo.model;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Administrator on 2015/10/12.
 */
public class PayInfoVO implements Parcelable {
    private int icon;
    private String payType;
    private String payAccount;
    private String payOwner;

    public int getIcon() {
        return icon;
    }

    public void setIcon(int icon) {
        this.icon = icon;
    }

    public String getPayType() {
        return payType;
    }

    public void setPayType(String payType) {
        this.payType = payType;
    }

    public String getPayAccount() {
        return payAccount;
    }

    public void setPayAccount(String payAccount) {
        this.payAccount = payAccount;
    }

    public String getPayOwner() {
        return payOwner;
    }

    public void setPayOwner(String payOwner) {
        this.payOwner = payOwner;
    }

    public static final Creator<PayInfoVO> CREATOR = new Creator<PayInfoVO>() {

        @Override
        public PayInfoVO createFromParcel(Parcel source) {
            PayInfoVO vo = new PayInfoVO();
            vo.icon=source.readInt();
            vo.payType = source.readString();
            vo.payAccount = source.readString();
            vo.payOwner = source.readString();
            return vo;
        }

        @Override
        public PayInfoVO[] newArray(int size) {
            return new PayInfoVO[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int flags) {
        parcel.writeInt(icon);
        parcel.writeString(payType);
        parcel.writeString(payAccount);
        parcel.writeString(payOwner);
    }
}
