package com.newcolor.qixinginfo.model;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Administrator on 2015/10/12.
 */
public class ZiXunVO implements Parcelable {
    private int id;
    private String title;
    private long addtime;
    private String content;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public long getAddtime() {
        return addtime;
    }

    public void setAddtime(long addtime) {
        this.addtime = addtime;
    }

    public static final Creator<ZiXunVO> CREATOR = new Creator<ZiXunVO>() {

        @Override
        public ZiXunVO createFromParcel(Parcel source) {
            ZiXunVO appVO = new ZiXunVO();
            appVO.id = source.readInt();
            appVO.title = source.readString();
            appVO.content = source.readString();
            appVO.addtime = source.readLong();
            return appVO;
        }

        @Override
        public ZiXunVO[] newArray(int size) {
            return new ZiXunVO[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int flags) {
        parcel.writeInt(id);
        parcel.writeString(title);
        parcel.writeString(content);
        parcel.writeLong(addtime);
    }
}
