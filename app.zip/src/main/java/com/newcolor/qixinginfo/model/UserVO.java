package com.newcolor.qixinginfo.model;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;

/**
 * Created by Administrator on 2015/10/21.
 */
public class UserVO implements Parcelable {
    private String phone;//电话
    private String realName;//真实姓名
    private String name;//姓名
    private String gender;//性别
    private String email;//邮箱
    private String birthday;//生日
    private String address;//地址
    private String componyName;//公司名称
    private String componyWeb;//公司网站
    private String componyCotent;//公司简介
    private String leaveWord;//留言
    private String fax;//传真
    private String landline;//座机
    private String ldCard;//身份证
    private String headImg;// 联系人头像
    private String companyImgs;//公司宣传照片
    private String coordinate;//坐标

    public String getCoordinate() {
        return coordinate;
    }

    public void setCoordinate(String coordinate) {
        this.coordinate = coordinate;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getHeadImg() {
        return headImg;
    }

    public void setHeadImg(String headImg) {
        this.headImg = headImg;
    }

    public String getReal_name() {
        return realName;
    }

    public void setReal_name(String realName) {
        this.realName = realName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCompony_name() {
        return componyName;
    }

    public void setCompony_name(String compony_name) {
        this.componyName = compony_name;
    }

    public String getCompony_web() {
        return componyWeb;
    }

    public void setCompony_web(String compony_web) {
        this.componyWeb = compony_web;
    }

    public String getCompony_cotent() {
        return componyCotent;
    }

    public void setCompony_cotent(String compony_cotent) {
        this.componyCotent = compony_cotent;
    }

    public String getLeave_word() {
        return leaveWord;
    }

    public void setLeave_word(String leave_word) {
        this.leaveWord = leave_word;
    }

    public String getFax() {
        return fax;
    }

    public void setFax(String fax) {
        this.fax = fax;
    }

    public String getLandline() {
        return landline;
    }

    public void setLandline(String landline) {
        this.landline = landline;
    }

    public String getLd_card() {
        return ldCard;
    }

    public void setLd_card(String ld_card) {
        this.ldCard = ld_card;
    }

    public ArrayList<String> getComponyImgsArr() {
        ArrayList<String> arrayList=new ArrayList<String>();

        if(companyImgs!=null&&!companyImgs.equals("")){
            String[] strs=companyImgs.split(",");
            for(String imgStr:strs){
                arrayList.add(imgStr);
            }
        }
        return arrayList;
    }

    public String getCompanyImgs() {
        return companyImgs;
    }

    public void setCompanyImgs(String companyImgs) {
        this.companyImgs = companyImgs;
    }

    public static final Creator<UserVO> CREATOR = new Creator<UserVO>() {

        @Override
        public UserVO createFromParcel(Parcel source) {
            UserVO vo = new UserVO();
            vo.phone = source.readString();
            vo.realName = source.readString();
            vo.name = source.readString();
            vo.gender = source.readString();
            vo.gender = source.readString();
            vo.email = source.readString();
            vo.birthday = source.readString();
            vo.address = source.readString();
            vo.componyName = source.readString();
            vo.componyWeb = source.readString();
            vo.componyCotent = source.readString();
            vo.leaveWord = source.readString();
            vo.fax = source.readString();
            vo.landline = source.readString();
            vo.ldCard = source.readString();
            vo.headImg = source.readString();
            vo.companyImgs=source.readString();
            return vo;
        }

        @Override
        public UserVO[] newArray(int size) {
            return new UserVO[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int flags) {
        parcel.writeString(phone);
        parcel.writeString(realName);
        parcel.writeString(name);
        parcel.writeString(gender);
        parcel.writeString(email);
        parcel.writeString(birthday);
        parcel.writeString(address);
        parcel.writeString(componyName);
        parcel.writeString(componyWeb);
        parcel.writeString(componyCotent);
        parcel.writeString(leaveWord);
        parcel.writeString(fax);
        parcel.writeString(landline);
        parcel.writeString(ldCard);
        parcel.writeString(headImg);
        parcel.writeString(companyImgs);
    }
}
