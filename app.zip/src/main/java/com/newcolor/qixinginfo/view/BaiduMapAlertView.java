package com.newcolor.qixinginfo.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.baidu.location.BDLocation;
import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.model.BaiduMapVo;
import com.newcolor.qixinginfo.util.StrUtil;
import com.newcolor.qixinginfo.util.ToastUtil;

/**
 * 百度地图锚点弹窗
 * Created by Administrator on 2016/1/20.
 */
public class BaiduMapAlertView extends LinearLayout implements View.OnClickListener {
    /**容器布局*/
    private View mContainer;
    private TextView address_TV,nav_TV,company_TV;
    private Context mContext;

    public BaiduMapAlertView(Context context) {
        this(context,null);
    }

    public BaiduMapAlertView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public BaiduMapAlertView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);

        this.init(context, attrs);
        this.initView(context);
    }

    private void initView(Context context){

    }

    /**
     * 初始化
     *
     * @param context context
     * @param attrs attrs
     */
    protected void init(Context context, AttributeSet attrs) {
        this.mContext=context;
        mContainer = createView(context, attrs);
        if (null == mContainer) {
            throw new NullPointerException("Loading view can not be null.");
        }

        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT);
        addView(mContainer, params);


        address_TV= (TextView) this.findViewById(R.id.address_TV);
        nav_TV= (TextView) this.findViewById(R.id.nav_TV);
        company_TV= (TextView) this.findViewById(R.id.company_TV);

        nav_TV.setOnClickListener(this);
    }



    protected View createView(Context context, AttributeSet attrs) {
        View container = LayoutInflater.from(context).inflate(R.layout.view_bai_du_map_alert, null);
        return container;
    }


    public void initData(BaiduMapVo vo){
        address_TV.setText(StrUtil.ToDBC(vo.getAddrStr()));
        company_TV.setText(vo.getCompanyName());
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.nav_TV:
                ToastUtil.showToast(mContext,"功能尚未开放");
                break;
        }
    }
}
