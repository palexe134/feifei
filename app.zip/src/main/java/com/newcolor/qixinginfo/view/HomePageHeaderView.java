package com.newcolor.qixinginfo.view;

import android.content.Context;
import android.content.Intent;
import android.support.v4.view.ViewPager;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;

import com.alibaba.fastjson.JSON;
import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.activity.BaiduMapActivity;
import com.newcolor.qixinginfo.activity.FuturesActivity;
import com.newcolor.qixinginfo.activity.FuturesListActivity;
import com.newcolor.qixinginfo.activity.OpinionActivity;
import com.newcolor.qixinginfo.activity.PayInfoActivity;
import com.newcolor.qixinginfo.activity.QrCodeActivity;
import com.newcolor.qixinginfo.activity.ReleaseGongQiuActivity;
import com.newcolor.qixinginfo.activity.WebFutureActivity;
import com.newcolor.qixinginfo.activity.ZiXunActivity;
import com.newcolor.qixinginfo.activity.ZiXunInfoActivity;
import com.newcolor.qixinginfo.adapter.AppAdapter;
import com.newcolor.qixinginfo.adapter.MenuPagerAdapter;
import com.newcolor.qixinginfo.adapter.ZiXunAdapter;
import com.newcolor.qixinginfo.global.Config;
import com.newcolor.qixinginfo.global.Constant;
import com.newcolor.qixinginfo.http.AsyncHttpResponseHandler;
import com.newcolor.qixinginfo.http.RequestParams;
import com.newcolor.qixinginfo.model.AppVO;
import com.newcolor.qixinginfo.model.ZiXunVO;
import com.newcolor.qixinginfo.ui.cycleviewpager.ADInfo;
import com.newcolor.qixinginfo.ui.cycleviewpager.ImageCycleView;
import com.newcolor.qixinginfo.ui.pullrefresh.LoadingLayout;
import com.newcolor.qixinginfo.util.HttpUtil;
import com.newcolor.qixinginfo.util.ToastUtil;
import com.newcolor.qixinginfo.util.Tools;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * 首页头部view
 *
 * Created by Administrator on 2016/4/1.
 */
public class HomePageHeaderView extends LinearLayout implements
        AdapterView.OnItemClickListener, View.OnClickListener {
    /**用于滑到底部自动加载的Footer*/
    private LoadingLayout mFooterLayout;

    private ImageCycleView mAdView;
    private ArrayList<AppVO> mListItems;
    private ArrayList<ZiXunVO> ziXunVOs;
    private AppAdapter appAdapter;
    private ZiXunAdapter ziXUnAdapter;
    private GridView menu_GV;
    private ImageButton more_IV;
    private ListView zi_xun_LV;
    private ArrayList<ADInfo> infos = new ArrayList<ADInfo>();
    private final String defaultImg="";
    private String[] imageUrls = {};
    private static final int[] menuViewIdArr={R.id.icon_IV, R.id.name_TV};
    private static final int[] ziXunViewIdArr={R.id.title_TV, R.id.time_TV};
    private static final String[] appNameArr={"发布货源","发布需求","分享","钱包","发布二手","废废地图",
            "预约开户","期货行情","二维码","意见反馈"};
    private static final int[] appIconArr={R.mipmap.gong_huo_icon, R.mipmap.xu_qiu_icon, R.mipmap.fen_xiang_icon
            , R.mipmap.pay_info_icon, R.mipmap.er_shou_icon, R.mipmap.bai_du_map_icon, R.mipmap.kai_hu_icon
            , R.mipmap.qi_huo_icon , R.mipmap.qr_code_icon, R.mipmap.opinion_icon};


    LayoutInflater mInflater;
    GridView mGridView = null;
    private ViewPager mViewPager;
    private ArrayList<View> mPageViews;
    private ImageView mImageView;
    private ImageView[] mImageViews;
    private ViewGroup indicatorViewGroup;

    public HomePageHeaderView(Context context) {
        this(context,null);
    }

    public HomePageHeaderView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public HomePageHeaderView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);

        this.createView(context,attrs);
        mViewPager.setAdapter(new MenuPagerAdapter(context,mPageViews));
        mViewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {

            @Override
            public void onPageSelected(int arg0) {
                // TODO Auto-generated method stub
                for (int i = 0; i < mImageViews.length; i++) {
                    if (i == arg0) {
                        mImageViews[i].setBackgroundResource(R.mipmap.icon_point_pre);
                    } else {
                        mImageViews[i].setBackgroundResource(R.mipmap.icon_point);
                    }
                }

            }

            @Override
            public void onPageScrolled(int arg0, float arg1, int arg2) {
                // TODO Auto-generated method stub

            }

            @Override
            public void onPageScrollStateChanged(int arg0) {
                // TODO Auto-generated method stub

            }
        });

        initData();
//        updateDate();
    }

    protected View createView(Context context, AttributeSet attrs) {
        View container = LayoutInflater.from(context).inflate(R.layout.view_home_page, null);
        addView(container);

        more_IV= (ImageButton) container.findViewById(R.id.more_IV);
        more_IV.setOnClickListener(this);

        ziXunVOs=new ArrayList<ZiXunVO>();
        zi_xun_LV= (ListView) container.findViewById(R.id.zi_xun_LV);
        ziXUnAdapter= new ZiXunAdapter(context,ziXunVOs, R.layout.item_list_zi_xun,ziXunViewIdArr);
        zi_xun_LV.setAdapter(ziXUnAdapter);
        zi_xun_LV.setOnItemClickListener(this);

        mAdView = (ImageCycleView) container.findViewById(R.id.ad_view);

        mInflater = LayoutInflater.from(context);

        //初始化ViewPager的内容
        mPageViews = new ArrayList<View>();
        int len= (int) Math.ceil(appNameArr.length / 8d);
        for(int i=0;i<len;i++) {
            ViewGroup viewLayoutGridView = (ViewGroup) mInflater.inflate(R.layout.layout_gridview, null);
            mGridView = (GridView) viewLayoutGridView.findViewById(R.id.mygridview);
            mListItems = new ArrayList<AppVO>();
            for(int j=i*8;j<appNameArr.length;j++){
                if(j>=(i+1)*8){
                    break;
                }
                AppVO vo=new AppVO();
                if(j==4){
                    vo.setIsNew(true);
                }
                vo.setIconId(appIconArr[j]);
                vo.setName(appNameArr[j]);
                mListItems.add(vo);
            }
            appAdapter = new AppAdapter(context, mListItems, R.layout.item_list_app, menuViewIdArr);
            mGridView.setAdapter(appAdapter);
            mGridView.setOnItemClickListener(this);
            mPageViews.add(viewLayoutGridView);
        }
        //初始化底部的圆点视图
        mImageViews = new ImageView[mPageViews.size()];
        mViewPager = (ViewPager) container.findViewById(R.id.myviewpager);
        indicatorViewGroup = (ViewGroup) container.findViewById(R.id.mybottomviewgroup);

        for (int i = 0; i < mImageViews.length; i++) {
            mImageView = new ImageView(context);
            mImageView.setLayoutParams(new LayoutParams(20,20));
            mImageView.setPadding(20, 0, 20, 0);

            if (i == 0) {
                mImageView.setBackgroundResource(R.mipmap.icon_point_pre);
            } else {
                mImageView.setBackgroundResource(R.mipmap.icon_point);
            }

            mImageViews[i] = mImageView;

            //把指示作用的远点图片加入底部的视图中
            indicatorViewGroup.addView(mImageViews[i]);
        }


       /* menu_GV= (GridView) container.findViewById(R.id.menu_GV);
        mListItems = new ArrayList<AppVO>();
        appAdapter = new AppAdapter(context,mListItems, R.layout.item_list_app,menuViewIdArr);
        menu_GV.setAdapter(appAdapter);
        menu_GV.setOnItemClickListener(this);*/
        return container;
    }

    public void initData(){
        infos.clear();
        ziXunVOs.clear();
        this.getHomePageInfo();
        getHomePageZiXunList(0, 5);
    }

    /*public void updateDate(){
        AppVO vo;
        for(int i=0;i<appNameArr.length;i++){
            vo=new AppVO();
            vo.setIconId(appIconArr[i]);
            vo.setName(appNameArr[i]);
            mListItems.add(vo);
        }
        appAdapter.notifyDataSetChanged();
    }*/


    private void getHomePageZiXunList(int size,int count) {
        RequestParams params=new RequestParams();
        params.put("curSize",String.valueOf(size));
        params.put("count",String.valueOf(count));
        HttpUtil.get(Config.getHomePageZiXunList, params, new AsyncHttpResponseHandler() {
            @Override
            public void onFailure(Throwable error, String content) {
                super.onFailure(error, content);
            }

            @Override
            public void onSuccess(String content) {
                super.onSuccess(content);
                ArrayList<ZiXunVO> arrayList = (ArrayList<ZiXunVO>) JSON.parseArray(content, ZiXunVO.class);

                if (arrayList != null) {
                    ziXunVOs.addAll(arrayList);
                }
                ziXUnAdapter.notifyDataSetChanged();
            }
        });
    }



    private void getHomePageInfo(){
        RequestParams params=new RequestParams();
        HttpUtil.get(Config.getHomePageImgs, params, new AsyncHttpResponseHandler() {
            @Override
            public void onFailure(Throwable error, String content) {
                super.onFailure(error, content);
                ToastUtil.showToast(getContext(), content);
            }

            @Override
            public void onSuccess(String content) {
                super.onSuccess(content);
                JSONObject jsonObject = null;
                try {
                    jsonObject = new JSONObject(content);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                if (jsonObject == null) {
                    return;
                }

                try {
                    JSONArray jsArr = (JSONArray) jsonObject.get("HomeImgs");
                    if (jsArr.length() < 1) {
                        addImgInfo(defaultImg, "");
                    } else {
                        for (int i = 0; i < jsArr.length(); i++) {
                            JSONObject jsOb = jsArr.getJSONObject(i);
                            addImgInfo(jsOb.getString("url"), "");
                        }
                    }
                    mAdView.setImageResources(infos, mAdCycleViewListener);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    private void addImgInfo(String url,String content){
        if(url==null||url.isEmpty()){
            return;
        }
        ADInfo info = new ADInfo();
        info.setUrl(url);
        info.setContent(content);
        infos.add(info);
    }


    private ImageCycleView.ImageCycleViewListener mAdCycleViewListener = new ImageCycleView.ImageCycleViewListener() {

        @Override
        public void onImageClick(ADInfo info, int position, View imageView) {
//            Toast.makeText(this, "content->" + info.getContent(), Toast.LENGTH_SHORT).show();
        }

        @Override
        public void displayImage(String imageURL, ImageView imageView) {
            Tools.loadImg(getContext(), imageURL, imageView,
                    Constant.getSimpleDisplayImage(R.mipmap.default_home_page_img),
                    null, R.mipmap.default_home_page_img);// 使用ImageLoader对图片进行加装！
        }
    };


    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        switch (parent.getId()){
            case R.id.zi_xun_LV:
                ListView ziLV= (ListView) parent;
                ZiXunVO ziXunVo= (ZiXunVO) ziLV.getItemAtPosition(position);

                Intent intent =new Intent(getContext(),ZiXunInfoActivity.class);
                intent.putExtra("ziXunVo",ziXunVo);
                getContext().startActivity(intent);
                break;
            case R.id.mygridview:
                GridView listView = (GridView) parent;
                AppVO appVo = (AppVO) listView.getItemAtPosition(position);
                if(appVo.getName().equals("发布货源")){
                    intent=new Intent(this.getContext(), ReleaseGongQiuActivity.class);
                    intent.putExtra("type", ReleaseGongQiuActivity.RELEASE_HUO_YUAN);
                    getContext().startActivity(intent);
                }else if(appVo.getName().equals("发布需求")){
                    intent=new Intent(this.getContext(), ReleaseGongQiuActivity.class);
                    intent.putExtra("type", ReleaseGongQiuActivity.RELEASE_XU_QIU);
                    getContext().startActivity(intent);
                }else if(appVo.getName().equals("发布二手")){
                    intent=new Intent(this.getContext(), ReleaseGongQiuActivity.class);
                    intent.putExtra("type", ReleaseGongQiuActivity.RELEASE_ER_SHOU);
                    getContext().startActivity(intent);
                }else if(appVo.getName().equals("分享")){
                    Tools.showShare(this.getContext(), null, false);
                }else if(appVo.getName().equals("二维码")){
                    intent=new Intent(this.getContext(), QrCodeActivity.class);
                    getContext().startActivity(intent);
                }else if(appVo.getName().equals("钱包")){
                    intent=new Intent(this.getContext(), PayInfoActivity.class);
                    intent.putExtra("type",1);
                    getContext().startActivity(intent);
                }else if(appVo.getName().equals("意见反馈")){
                    intent=new Intent(this.getContext(), OpinionActivity.class);
                    getContext().startActivity(intent);
                }else if(appVo.getName().equals("期货行情")){
                    intent=new Intent(this.getContext(), FuturesListActivity.class);
                    getContext().startActivity(intent);
                }else if(appVo.getName().equals("废废地图")){
                    intent=new Intent(this.getContext(), BaiduMapActivity.class);
                    getContext().startActivity(intent);
                }else if(appVo.getName().equals("预约开户")){
                    intent=new Intent(getContext(), OpinionActivity.class);
                    intent.putExtra("type",1);
                    getContext().startActivity(intent);
                }
                break;
        }

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.more_IV:
                Intent i = new Intent(this.getContext(), ZiXunActivity.class);;
                this.getContext().startActivity(i);
                break;
        }
    }
}
