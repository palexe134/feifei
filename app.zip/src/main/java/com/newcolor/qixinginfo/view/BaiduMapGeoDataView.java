package com.newcolor.qixinginfo.view;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;

import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.adapter.BaiduMapGeoAdapter;
import com.newcolor.qixinginfo.dialog.AlertDialog;
import com.newcolor.qixinginfo.model.BaiDuMapGeoVO;
import com.newcolor.qixinginfo.model.BaiDuMapGongQiuVO;
import com.newcolor.qixinginfo.model.ContactVO;
import com.newcolor.qixinginfo.ui.pullrefresh.PullToRefreshListView;
import com.newcolor.qixinginfo.util.DateUtils;

import java.util.ArrayList;

/**
 * 百度地图下方供求列表窗口
 *
 * Created by Administrator on 2016/1/20.
 */
public class BaiduMapGeoDataView extends LinearLayout implements AdapterView.OnItemClickListener, BaiduMapGeoAdapter.Callback {
    /**容器布局*/
    private View mContainer;
    private Context mContext;
    private int type=1;//1：供货方 2：需求方

    private ListView mListView;
    private PullToRefreshListView mPullListView;
    private BaiduMapGeoAdapter mAdapter;
    private ArrayList<BaiDuMapGeoVO> mListItems;
    private int mCurIndex = 0;
    private CallBack callBack;
    private static final int mLoadDataCount = 20;
    private static final int[] viewIdArr={R.id.title_TV,R.id.content_TV,R.id.address_TV,R.id.phone_IV};

    public BaiduMapGeoDataView(Context context) {
        this(context,null);
    }

    public BaiduMapGeoDataView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public BaiduMapGeoDataView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);

        this.init(context, attrs);
        this.initView(context);
    }

    private void initView(Context context){
        //定义下拉刷新
        mPullListView=(PullToRefreshListView) this.findViewById(R.id.gongQiuPullListView);
        mPullListView.setPullLoadEnabled(false);
        mPullListView.setScrollLoadEnabled(true);

        mCurIndex = 0;
        mListItems = new ArrayList<BaiDuMapGeoVO>();

        mAdapter = new BaiduMapGeoAdapter(context,mListItems,R.layout.item_list_baidu_geo,viewIdArr,this);
        mListView = mPullListView.getRefreshableView();
        mListView.setAdapter(mAdapter);
        mListView.setDividerHeight(10);
        mListView.setOnItemClickListener(this);



//        mPullListView.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener<ListView>() {
//            @Override
//            public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {
//                initData();
//            }
//
//            @Override
//            public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {
//                initData();
//            }
//        });
//        setLastUpdateTime();
    }

    /**
     * 初始化数据
     */
    public void updateData(ArrayList<BaiDuMapGeoVO> list,CallBack callBack){
        this.callBack=callBack;
        mListItems.clear();
        mListItems.addAll(list);

        mAdapter.notifyDataSetChanged();
        mPullListView.onPullDownRefreshComplete();
        mPullListView.onPullUpRefreshComplete();
        mPullListView.setHasMoreData(false);
        setLastUpdateTime();
    }


    private void setLastUpdateTime() {
        String text = DateUtils.formatSimpleDateTime(System.currentTimeMillis());
        mPullListView.setLastUpdatedLabel(text);
    }

    /**
     * 初始化
     *
     * @param context context
     * @param attrs attrs
     */
    protected void init(Context context, AttributeSet attrs) {
        this.mContext=context;
        mContainer = createView(context, attrs);
        if (null == mContainer) {
            throw new NullPointerException("Loading view can not be null.");
        }

        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT);
        addView(mContainer, params);

    }



    protected View createView(Context context, AttributeSet attrs) {
        View container = LayoutInflater.from(context).inflate(R.layout.view_bai_du_map_geo_list, null);
        return container;
    }



    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        ListView listView = (ListView) parent;
        BaiDuMapGeoVO vo = (BaiDuMapGeoVO) listView.getItemAtPosition(position);
        if(this.callBack!=null) {
            this.callBack.onClickItem(vo,position);
        }
    }

    @Override
    public void click(View v) {
        final BaiDuMapGeoVO vo = (BaiDuMapGeoVO) v.getTag();
        switch (v.getId()){
            case R.id.phone_IV:
                new AlertDialog(mContext).builder().setTitle("联系商家")
                        .setMsg(vo.getPhone()+"\n\n废废网竭诚为您服务")
                        .setPositiveButton("确定", new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                phoneHandler(vo);
                            }
                        }).setNegativeButton("取消", new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                    }
                }).show();
                break;
        }
    }


    private void phoneHandler(BaiDuMapGeoVO vo){
        Intent intent = new Intent(Intent.ACTION_CALL);
        Uri data = Uri.parse("tel:" + vo.getPhone());
        intent.setData(data);
        mContext.startActivity(intent);
    }

    /**
     * 自定义接口，当点击下拉列表元素时回调
     * @author Ivan Xu
     * 2014-11-26
     */
    public interface CallBack{
        public void onClickItem(BaiDuMapGeoVO vo,int position);
    }

}
