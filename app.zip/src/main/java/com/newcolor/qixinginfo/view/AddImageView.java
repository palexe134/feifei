package com.newcolor.qixinginfo.view;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.provider.MediaStore;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.LinearLayout;

import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.activity.ReleaseGongQiuActivity;
import com.newcolor.qixinginfo.adapter.ImageAdapter;
import com.newcolor.qixinginfo.dialog.ActionSheetDialog;
import com.newcolor.qixinginfo.dialog.AlertDialog;
import com.newcolor.qixinginfo.global.MyApplication;
import com.newcolor.qixinginfo.upload.HttpMultipartPost;
import com.newcolor.qixinginfo.util.IntentUtil;
import com.newcolor.qixinginfo.util.LogUtil;
import com.newcolor.qixinginfo.util.LoginUtil;
import com.newcolor.qixinginfo.util.PhotoUtil;
import com.newcolor.qixinginfo.util.ToastUtil;
import com.newcolor.qixinginfo.util.Tools;

import java.io.File;
import java.util.ArrayList;

/**
 * 添加图片view
 *
 * Created by Administrator on 2016/1/20.
 */
public class AddImageView extends LinearLayout implements ImageAdapter.Callback, AdapterView.OnItemClickListener{
    /**容器布局*/
    private View mContainer;
    private Activity mContext;
    private MyApplication application;
    private GridView addImgGV;
    private ImageAdapter mAdapter;
    private static final int[] viewIdArr={R.id.icon_IV,R.id.delet_TV};
    private String[] photoData={"拍照","从相册选择"};
    private ActionSheetDialog headSD;
    public static final String defaultUrl="assets://defaultRes/ic_add_img.png";

    //照相机拍照得到的图片
    private File mTempPhotoFile;
    private byte[] contact_icon;
    private HttpMultipartPost post;
    private ArrayList<String> urlArr;
    public Uri imageUri;
    //1:发布供求添加图片    2:个人信息添加公司图片
    private int type;

    public static final int ADD_IMG=2;

    public AddImageView(Context context) {
        this(context, null);
    }

    public AddImageView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public AddImageView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);

        this.init(context, attrs);
    }

    /**
     * 初始化
     *
     * @param context context
     * @param attrs attrs
     */
    protected void init(Context context, AttributeSet attrs) {
        mContext= (Activity) context;
        application= (MyApplication) mContext.getApplication();
        mContainer = createView(context, attrs);
        if (null == mContainer) {
            throw new NullPointerException("Loading view can not be null.");
        }

        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT);
        addView(mContainer, params);

    }


    public void initView(ArrayList<String> urlArr){
        this.urlArr=urlArr;
        addImgGV= (GridView) this.findViewById(R.id.add_Img_GV);

        mAdapter = new ImageAdapter(mContext,urlArr,R.layout.item_list_img,viewIdArr,this);
        addImgGV.setAdapter(mAdapter);
        addImgGV.setOnItemClickListener(this);


        this.initData();

    }


    protected View createView(Context context, AttributeSet attrs) {
        View container = LayoutInflater.from(context).inflate(R.layout.activity_add_image, null);
        return container;
    }

    private void initData(){
        if(!urlArr.equals(defaultUrl) && urlArr.size()<3) {
            urlArr.add(defaultUrl);
        }
        mAdapter.notifyDataSetChanged();
    }

    ActionSheetDialog.OnSheetItemClickListener photoSheetItemClick=new ActionSheetDialog.OnSheetItemClickListener() {
        @Override
        public void onClick(int which) {
            if(which==1){
                imageUri= PhotoUtil.getTempUri();
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);//action is capture
                intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
                mContext.startActivityForResult(intent, ReleaseGongQiuActivity.TAKE_CAMERA_PICTURE);//or TAKE_SMALL_PICTURE
            }else{
                imageUri=Uri.parse(PhotoUtil.IMAGE_FILE_LOCATION);//The Uri to store the big bitmap
                doPickPhotoFromGallery(ReleaseGongQiuActivity.TAKE_BIG_PICTURE);        // 从图库中去选取图片
            }
        }
    };

    private void doPickPhotoFromGallery(int requestCode){
        Intent intent;
        switch (requestCode) {
            case ReleaseGongQiuActivity.TAKE_BIG_PICTURE:
                intent = PhotoUtil.cropBigImage(imageUri, 640, 480,4,3);
                mContext.startActivityForResult(intent, ReleaseGongQiuActivity.CROP_BIG_PICTURE);
                break;
            case ReleaseGongQiuActivity.TAKE_SMALL_PICTURE:
                intent = PhotoUtil.cropSmallImage(320, 240,4,3);
                mContext.startActivityForResult(intent, ReleaseGongQiuActivity.CROP_SMALL_PICTURE);
                break;
        }
    }

    private void comHandler(){
        for(String str:urlArr){
            if(str==defaultUrl){
                urlArr.remove(defaultUrl);
            }
        }

        if(type==1) {
            Intent intent = new Intent(mContext, ReleaseGongQiuActivity.class);
            intent.putStringArrayListExtra("urlArr", urlArr);
            mContext.setResult(ADD_IMG, intent);
        }else if(type==2){
            int i=0;
            StringBuffer companyImgsStr=new StringBuffer();
            for(String str:urlArr){
                if(i<urlArr.size()-1) {
                    companyImgsStr.append(str + ",");
                }else{
                    companyImgsStr.append(str);
                }

                i++;
            }
            application.getCurUserVo().setCompanyImgs(companyImgsStr.toString());
        }
    }

    /**
     * 获取默认图标
     * @return
     */
    private Bitmap getDefaultIcon() {
        Resources res = getResources();
        Bitmap bmp = BitmapFactory.decodeResource(res, R.mipmap.defaulthead);
        return bmp;
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

    }

    /**
     * 设置图片为联系人头像
     */
    public void setPhotoToView(Bitmap bitmap) {
        if(bitmap==null)return;
        contact_icon = PhotoUtil.getBitmapByte(mContext, bitmap);
        long size= Tools.getBitmapsize(bitmap);
        bitmap.recycle();

        if(!IntentUtil.getNetType(mContext).equals(IntentUtil.Type._WIFI)){
            new AlertDialog(mContext).builder().setTitle("流量提示")
                    .setMsg("继续上传将产生  "+ ((int)(size/1024*100))/100+"KB流量,确定要上传吗？")
                    .setPositiveButton("确定", new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            uploadHander();
                        }
                    }).setNegativeButton("取消", new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                }
            }).show();
        }else{
            this.uploadHander();
        }

    }


    /*上传操作*/
    private void uploadHander(){
        post = new HttpMultipartPost(mContext, contact_icon, PhotoUtil.getPhotoFileName(), new HttpMultipartPost.Callback() {
            @Override
            public void onCom(String url) {
                if(urlArr.size()>=3){
                    urlArr.remove(defaultUrl);
                    urlArr.add(url);
                }else {
                    urlArr.add(urlArr.size() - 1, url);
                }

                mAdapter.notifyDataSetChanged();
            }
        });
        post.execute();
    }


    @Override
    public void click(View v) {
        int position=0;
        try{
            position=Integer.parseInt(v.getTag().toString());
        }
        catch (NumberFormatException e){}

        switch (v.getId()){
            case R.id.icon_IV:
                if(application.getUserId(mContext).equals("-1")){
                    LoginUtil.gotoLogin(mContext);
                    return;
                }

                if(urlArr.size()>=4){
                    ToastUtil.showToast(mContext, "最多只能上传3张图片");
                    return;
                }
                if(position==this.urlArr.size()-1){
                    headSD=new ActionSheetDialog(mContext);
                    headSD.builder();
                    headSD.setCancelable(false);
                    headSD.setCanceledOnTouchOutside(false);
                    for(int i=0;i<photoData.length;i++){
                        headSD.addSheetItem(photoData[i], ActionSheetDialog.SheetItemColor.Blue,photoSheetItemClick);
                    }
                    headSD.show();
                }
                break;
            case R.id.delet_TV:
                if(urlArr.size()-1>=position) {
                    urlArr.remove(position);
                    mAdapter.notifyDataSetChanged();
                }
                if(!urlArr.contains(defaultUrl)){
                    urlArr.add(defaultUrl);
                }
                break;
        }

    }


    public void onActivityResult(int requestCode, int resultCode, Intent data){
        switch (requestCode) {
            case ReleaseGongQiuActivity.TAKE_CAMERA_PICTURE:
                Intent intent = PhotoUtil.cropImageUri(imageUri, 640, 480, 4, 3);
                mContext.startActivityForResult(intent, ReleaseGongQiuActivity.CROP_BIG_PICTURE);
                break;
            case ReleaseGongQiuActivity.CROP_BIG_PICTURE://from crop_big_picture
                if (imageUri != null) {
                    Bitmap bitmap = PhotoUtil.decodeUriAsBitmap(imageUri, mContext);
                    setPhotoToView(bitmap);
                }
                break;
            case ReleaseGongQiuActivity.CROP_SMALL_PICTURE:
                if (data != null) {
                    Bitmap bitmap = data.getParcelableExtra("data");
                    setPhotoToView(bitmap);
                } else {
                    //LogUtil.d(mContext, "CROP_SMALL_PICTURE: data = " + data);
                }
                break;
        }
    }


}
