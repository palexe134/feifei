package com.newcolor.qixinginfo.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.baidu.location.BDLocation;
import com.baidu.location.BDLocationListener;
import com.baidu.location.LocationClient;
import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.util.BaiduMapUtil;

/**
 *
 * Created by Administrator on 2016/2/13.
 */
public class SiteUpdateLayout extends LinearLayout implements View.OnClickListener {
    /**进度条*/
    private ProgressBar mProgressBar;
    /** 显示的文本 */
    private TextView mHintView;
    /** 刷新按钮 */
    private ImageView flush_IV;
    /**容器布局*/
    private View mContainer;
    private LocationClient locationClient;
    private Context mContext;
    public BDLocation curLocation;
    private Callback curCallback;

    public SiteUpdateLayout(Context context) {
        super(context);
        init(context);
    }

    /**
     * 构造方法
     *
     * @param context context
     * @param attrs attrs
     */
    public SiteUpdateLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }


    /**
     * 初始化
     *
     * @param context context
     */
    private void init(Context context) {
        this.mContext=context;

        mContainer = createLoadingView(context);
        if (null == mContainer) {
            throw new NullPointerException("Loading view can not be null.");
        }

        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT);
        addView(mContainer, params);

        mProgressBar = (ProgressBar) findViewById(R.id.pull_to_load_footer_progressbar);
        mHintView = (TextView) findViewById(R.id.txt_address);
        flush_IV = (ImageView) findViewById(R.id.flush_IV);
        flush_IV.setOnClickListener(this);

    }


    protected View createLoadingView(Context context) {
        View container = LayoutInflater.from(context).inflate(R.layout.view_site, null);
        return container;
    }

    public void setLastUpdatedLabel(CharSequence label) {
        // 如果最后更新的时间的文本是空的话，隐藏前面的标题
//        mHeaderTimeViewTitle.setVisibility(TextUtils.isEmpty(label) ? View.INVISIBLE : View.VISIBLE);
//        mHeaderTimeView.setText(label);
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.flush_IV:
                mProgressBar.setVisibility(VISIBLE);
                flush_IV.setVisibility(INVISIBLE);
                this.startPosition(curCallback);
                break;
        }
    }


    public void startPosition(Callback callback){
        this.curCallback=callback;
        if(locationClient==null) {
            locationClient = new LocationClient(this.mContext);
            locationClient.registerLocationListener(myListener);
            locationClient.setLocOption(BaiduMapUtil.getDefaultLocationOption());   //设置定位参数
        }
        if (!locationClient.isStarted()) {
            locationClient.start(); // 开始定位
        }
        locationClient.requestLocation();
    }

    public BDLocationListener myListener=new BDLocationListener() {
        @Override
        public void onReceiveLocation(BDLocation location) {
            if(location==null){
                return;
            }
            curLocation=location;
            locationClient.stop();
//            LatLng ll=new LatLng(location.getLatitude(),
//                    location.getLongitude());
            if(curCallback!=null){
                curCallback.onLocationCom(location);
            }

            mProgressBar.setVisibility(INVISIBLE);
            flush_IV.setVisibility(VISIBLE);

            mHintView.setText(location.getAddrStr());
        }
    };


    /**
     * 自定义接口，用于回调按钮点击事件到Activity
     * @author Ivan Xu
     * 2014-11-26
     */
    public interface Callback {
        public void onLocationCom(BDLocation location);
    }

}
