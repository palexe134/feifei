package com.newcolor.qixinginfo.dialog;

import android.app.Dialog;
import android.app.DialogFragment;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.View;
import android.widget.TimePicker;

import com.newcolor.qixinginfo.adapter.GongQiuAdapter;
import com.newcolor.qixinginfo.util.LogUtil;

import java.util.Calendar;

/**
 * 日期选择器
 *
 * Created by Administrator on 2015/11/13.
 */
public class TimePickerFragment extends DialogFragment implements
        TimePickerDialog.OnTimeSetListener {

    public Callback callback;


    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        final Calendar calendar = Calendar.getInstance();
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);

//        return new TimePickerDialog(getActivity(), this, hour, minute,
//                DateFormat.is24HourFormat(getActivity()));
        return new TimePickerDialog(getActivity(), this, hour, minute,
                true);
    }

    @Override
    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
        //处理设置的时间，这里我们作为示例，在日志中输出我们选择的时间
        LogUtil.d("onTimeSet", "hourOfDay: " + hourOfDay + "Minute: " + minute);
        if(callback!=null){
            callback.onCom(hourOfDay,minute);
        }
    }




    /**
     * 自定义接口，用于回调按钮点击事件到Activity
     * @author Ivan Xu
     * 2014-11-26
     */
    public interface Callback {
        public void onCom(int hourOfDay, int minute);
    }
}
