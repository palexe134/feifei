package com.newcolor.qixinginfo.dialog;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.BitmapDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.PopupWindow;

import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.activity.ReleaseGongQiuActivity;
import com.newcolor.qixinginfo.adapter.AddPopupAdapter;
import com.newcolor.qixinginfo.global.Config;
import com.newcolor.qixinginfo.global.MyApplication;
import com.newcolor.qixinginfo.http.AsyncHttpResponseHandler;
import com.newcolor.qixinginfo.http.RequestParams;
import com.newcolor.qixinginfo.model.AddPopupVO;
import com.newcolor.qixinginfo.model.GongQiuInfoVO;
import com.newcolor.qixinginfo.util.HttpUtil;
import com.newcolor.qixinginfo.util.LoginUtil;
import com.newcolor.qixinginfo.util.ProtocolUtil;
import com.newcolor.qixinginfo.util.ToastUtil;
import com.newcolor.qixinginfo.util.Tools;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * 浮窗
 *
 * Created by Administrator on 2016/3/4.
 */
public class AddPopWindow extends PopupWindow implements AdapterView.OnItemClickListener {
    private View conentView;
    private ListView data_LV;
    private ArrayList<AddPopupVO> dataList;
    private AddPopupAdapter mAdapter;
    private Context mContext;
    private MyApplication application;
    private String curId;
    private GongQiuInfoVO curVo;
    private int type;
    private String myUserId;
    private int[] viewIdArr={R.id.icon_IV,R.id.name_TV};

    public AddPopWindow(final Activity context,String id,int type,GongQiuInfoVO vo) {

        mContext=context;
        application = (MyApplication)context.getApplication();
        myUserId=application.getUserId(context);
        this.curId=id;
        this.type=type;
        this.curVo=vo;

        LayoutInflater layoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        conentView = layoutInflater.inflate(R.layout.add_popup_dialog, null);

        dataList=new ArrayList<AddPopupVO>();
        mAdapter=new AddPopupAdapter(context,dataList,R.layout.item_list_add_popup,viewIdArr);

        data_LV= (ListView) conentView.findViewById(R.id.data_LV);
        data_LV.setAdapter(mAdapter);
        data_LV.setOnItemClickListener(this);

        setContentView(conentView);
        setWidth(Tools.dp2px(mContext, 120));
        setHeight(ViewGroup.LayoutParams.WRAP_CONTENT);
        this.setFocusable(true);
        this.setOutsideTouchable(true);
        setBackgroundDrawable(new BitmapDrawable());

//        this.update();
        this.setAnimationStyle(R.style.AnimationPreview);
        this.initData();
    }

    private void initData(){
        AddPopupVO vo;
        if(curVo.getUserId()!=myUserId) {
            vo=new AddPopupVO();
            vo.setIconId(R.mipmap.ic_shou_cang);
            vo.setName("关注");
            dataList.add(vo);
        }

        vo=new AddPopupVO();
        vo.setIconId(R.mipmap.ic_fen_xiang);
        vo.setName("分享");
        dataList.add(vo);

        if(curVo.getUserId()==myUserId) {
            vo = new AddPopupVO();
            vo.setIconId(R.mipmap.ic_change);
            vo.setName("修改");
            dataList.add(vo);
        }

        if(curVo.getUserId()==myUserId) {
            vo = new AddPopupVO();
            vo.setIconId(R.mipmap.ic_refresh);
            vo.setName("重新发布");
            dataList.add(vo);
        }

        mAdapter.notifyDataSetChanged();
    }

    /**
     * 显示popupWindow
     *
     * @param parent
     */
    public void showPopupWindow(View parent) {
        if (!this.isShowing()) {
            this.showAsDropDown(parent);
        } else {
            this.dismiss();
        }
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        switch (position){
            case 0:
                //ToastUtil.showToast(mContext,"关注");
                ProtocolUtil.foucsHandler(mContext,application,type,curId);
                break;
            case 1:
                String content=curVo.getContent()+"\n"+curVo.getPhone()+"\n"+curVo.getAddress();
                //ToastUtil.showToast(mContext,"分享");
                Tools.shareGongQiu(mContext, null, curVo.getTitle(), content);
                break;
            case 2:
                Intent intent=new Intent(mContext, ReleaseGongQiuActivity.class);
                intent.putExtra("type",type);
                intent.putExtra("infoVo", curVo);
                mContext.startActivity(intent);
                break;
            case 3:
                this.refreshHandler();
                break;

        }
        AddPopWindow.this.dismiss();
    }


    private void refreshHandler(){
        RequestParams params=new RequestParams();
        params.put("id", curVo.getsId());
        params.put("type", String.valueOf(type));

        HttpUtil.get(Config.refreshGongQiu, params, new AsyncHttpResponseHandler() {
            @Override
            public void onFailure(Throwable error, String content) {
                super.onFailure(error, content);
                ToastUtil.showToast(mContext, content);
            }

            @Override
            public void onSuccess(String content) {
                super.onSuccess(content);

                JSONObject jsonObject = null;
                try {
                    jsonObject = new JSONObject(content);
                    byte isSuc = Byte.parseByte(jsonObject.getString("isSuc"));
                    if (isSuc == 0) {
                        String msg = jsonObject.getString("msg");
                        ToastUtil.showToast(mContext, msg);
                    } else {
                        ToastUtil.showToast(mContext, "重新刷新成功");
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
    }



}