package com.newcolor.qixinginfo.bug;

import java.io.PrintWriter;
import java.io.StringWriter;



import android.content.Context;
import android.os.Build;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

import com.newcolor.qixinginfo.global.Constant;
import com.newcolor.qixinginfo.global.MyApplication;
import com.newcolor.qixinginfo.util.IntentUtil;
import com.newcolor.qixinginfo.util.LogUtil;
import com.newcolor.qixinginfo.util.SharedUtil;
import com.newcolor.qixinginfo.util.ToastUtil;

public class CrashHandler implements Thread.UncaughtExceptionHandler {
	 private final static String TAG = "UncaughtExceptionHandler";  
	    private Thread.UncaughtExceptionHandler mDefaultHandler;  
	    private static CrashHandler mInstance;  
	    private Context mContext;  
	    private CrashHandler() {  
	    }  
	  
	    /** 获取CrashHandler实例 ,单例模式 */  
	    public static CrashHandler getInstance() {  
	        if (mInstance == null)  
	            mInstance = new CrashHandler();  
	        return mInstance;  
	    }  
	  
	    @Override  
	    public void uncaughtException(Thread thread, Throwable throwable) {  
	        if (!handleException(throwable) && mDefaultHandler != null) {    
	            // 如果用户没有处理则让系统默认的异常处理器来处理    
	            mDefaultHandler.uncaughtException(thread, throwable);    
	        } else {    
	            // Sleep一会后结束程序    
	            // 来让线程停止一会是为了显示Toast信息给用户，然后Kill程序    
	            try {    
	                Thread.sleep(3000);    
	            } catch (InterruptedException e) {    
	                LogUtil.e(TAG, "Error : "+ e);
	            }    
	            android.os.Process.killProcess(android.os.Process.myPid());    
	            System.exit(10);    
	        }    
	    }  
	      
	    private boolean handleException(final Throwable ex) {    
	        if (ex == null) {    
	            return true;    
	        }    
	        // 使用Toast来显示异常信息    
	        new Thread() {    
	            @Override    
	            public void run() {    
	                // Toast 显示需要出现在一个线程的消息队列中    
	                Looper.prepare();    
	                
	                StringWriter sw = new StringWriter();
	                PrintWriter pw = new PrintWriter(sw);
	                ex.printStackTrace(pw);

	                StringBuilder sb = new StringBuilder();

					sb.append("用户ID： ");
					sb.append(SharedUtil.getString(mContext, "userId")+"\n") ;
					sb.append("电话号码： ");
					String pNumber= SharedUtil.getString(mContext,Constant.USERNAMECOOKIE);
					String aa="";
					if(pNumber!=null) {
						int i=0;
						for (char c:pNumber.toCharArray()){
							aa+=c;
							if(i==2||i==6){
								aa+="_";
							}
						}
					}

					sb.append( aa + "\n");
	                sb.append("Android 版本：  ");
	                sb.append(Build.VERSION.SDK_INT + "\n");
	                sb.append("手机型号： ");
	                sb.append(Build.MODEL + "\n");
					sb.append("App版本号： ");
					sb.append(IntentUtil.getCurrentVersionCode(mContext) + "\n");
					sb.append("App版本名称： ");
					sb.append(IntentUtil.getCurrentVersionName(mContext) + "\n");
					sb.append("当前系统的版本号： ");
					sb.append("Product Model: " + android.os.Build.MODEL + ","
							+ android.os.Build.VERSION.SDK + ","
							+ android.os.Build.VERSION.RELEASE + "\n");

					sb.append(sw.toString());


	                
	              //使用之前记得将三个jar文件添加进去。Right Click Project- add External Jars
	                try {   
	                	//发送方的邮箱名及密码。
	                    GMailSender sender = new GMailSender("739550439@qq.com", "sibaolei123"); 
	                    sender.sendMail("七星资讯BUG",    //主题
	                    		sb.toString(),    //正文
	                            "739550439@qq.com",  //发送人  
	                            "739550439@qq.com"); //收件人,不一定非得gmail其他邮箱比如163，qq邮箱都行。
	                } catch (Exception e) {    
	                    Log.e("SendMail", e.getMessage(), e);   
	                }

					ToastUtil.showToast(mContext,"程序出现问题，错误已经发送给客服，正在为您处理，给您带来的不便敬请原谅！");
	                Looper.loop();
	            }    
	        }.start();    
	        return true;    
	    }    
	      
	    public void init(Context context) {    
	        mContext = context;    
	        mDefaultHandler = Thread.getDefaultUncaughtExceptionHandler();    
	        Thread.setDefaultUncaughtExceptionHandler(this);    
	    }  
}
