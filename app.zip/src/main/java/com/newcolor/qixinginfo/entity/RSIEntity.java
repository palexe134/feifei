package com.newcolor.qixinginfo.entity;

import java.util.List;


/**
 * @author nanjingbiao
 * 
 */
public class RSIEntity {
	public RSIEntity(List<OHLCEntity> OHLCData) {

	}
}
