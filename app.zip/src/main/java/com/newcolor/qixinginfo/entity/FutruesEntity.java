package com.newcolor.qixinginfo.entity;

import android.os.Parcel;
import android.os.Parcelable;

public class FutruesEntity implements Parcelable {
	private String name;// 期货名称
	private String prefix;// 期货代码前缀
	private String code;// 期货代码
	private double price;// 当前价格
	private double buyPrice;// 买价
	private double sellPrice;// 卖价
	private double jiePrice;// 结算
	private double zuoJie;// 昨结算
	private double open;// 开盘
	private double high;// 最高
	private double low;// 最低
	private int buyCount;// 买量
	private int sellCount;// 卖量
	private int chiCang;// 持仓量
	private int chengJiao;// 成交
	private double changeAmount;// 涨跌额
	private double changeRate;// 涨跌幅

	public FutruesEntity() {
		super();
	}

	public FutruesEntity(String name, String code, double price, double changeAmount,
			double changeRate) {
		super();
		this.name = name;
		this.code = code;
		this.price = price;
		this.changeAmount = changeAmount;
		this.changeRate = changeRate;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public double getChangeAmount() {
		return changeAmount;
	}

	public void setChangeAmount(double changeAmount) {
		this.changeAmount = changeAmount;
	}

	public double getChangeRate() {
		return changeRate;
	}

	public void setChangeRate(double changeRate) {
		this.changeRate = changeRate;
	}

	public String getPrefix() {
		return prefix;
	}

	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}

	public double getBuyPrice() {
		return buyPrice;
	}

	public void setBuyPrice(double buyPrice) {
		this.buyPrice = buyPrice;
	}

	public double getSellPrice() {
		return sellPrice;
	}

	public void setSellPrice(double sellPrice) {
		this.sellPrice = sellPrice;
	}

	public double getJiePrice() {
		return jiePrice;
	}

	public void setJiePrice(double jiePrice) {
		this.jiePrice = jiePrice;
	}

	public double getZuoJie() {
		return zuoJie;
	}

	public void setZuoJie(double zuoJie) {
		this.zuoJie = zuoJie;
	}

	public double getOpen() {
		return open;
	}

	public void setOpen(double open) {
		this.open = open;
	}

	public int getBuyCount() {
		return buyCount;
	}

	public void setBuyCount(int buyCount) {
		this.buyCount = buyCount;
	}

	public int getSellCount() {
		return sellCount;
	}

	public void setSellCount(int sellCount) {
		this.sellCount = sellCount;
	}

	public int getChiCang() {
		return chiCang;
	}

	public void setChiCang(int chiCang) {
		this.chiCang = chiCang;
	}

	public int getChengJiao() {
		return chengJiao;
	}

	public void setChengJiao(int chengJiao) {
		this.chengJiao = chengJiao;
	}

	public double getHigh() {
		return high;
	}

	public void setHigh(double high) {
		this.high = high;
	}

	public double getLow() {
		return low;
	}

	public void setLow(double low) {
		this.low = low;
	}

	public static final Parcelable.Creator<FutruesEntity> CREATOR = new Creator<FutruesEntity>() {

		@Override
		public FutruesEntity createFromParcel(Parcel source) {
			FutruesEntity vo = new FutruesEntity();
			vo.name = source.readString();
			vo.prefix = source.readString();
			vo.code = source.readString();
			vo.price = source.readDouble();
			vo.buyPrice = source.readDouble();
			vo.sellPrice = source.readDouble();
			vo.jiePrice = source.readDouble();
			vo.zuoJie = source.readDouble();
			vo.open = source.readDouble();
			vo.high = source.readDouble();
			vo.low = source.readDouble();
			vo.buyCount = source.readInt();
			vo.sellCount = source.readInt();
			vo.chiCang = source.readInt();
			vo.chengJiao = source.readInt();
			vo.changeAmount = source.readDouble();
			vo.changeRate = source.readDouble();
			return vo;
		}

		@Override
		public FutruesEntity[] newArray(int size) {
			return new FutruesEntity[size];
		}
	};

	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel parcel, int flags) {
		parcel.writeString(name);
		parcel.writeString(prefix);
		parcel.writeString(code);
		parcel.writeDouble(price);
		parcel.writeDouble(buyPrice);
		parcel.writeDouble(sellPrice);
		parcel.writeDouble(jiePrice);
		parcel.writeDouble(zuoJie);
		parcel.writeDouble(open);
		parcel.writeDouble(high);
		parcel.writeDouble(low);
		parcel.writeInt(buyCount);
		parcel.writeInt(sellCount);
		parcel.writeInt(chiCang);
		parcel.writeInt(chengJiao);
		parcel.writeDouble(changeAmount);
		parcel.writeDouble(changeRate);
	}

}
