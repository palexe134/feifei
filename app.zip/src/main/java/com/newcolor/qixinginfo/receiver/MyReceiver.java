package com.newcolor.qixinginfo.receiver;

import android.app.KeyguardManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Message;
import android.util.Log;

import com.newcolor.qixinginfo.activity.AlarmHandlerActivity;
import com.newcolor.qixinginfo.activity.MainActivity;
import com.newcolor.qixinginfo.activity.MsgActivity;
import com.newcolor.qixinginfo.fragment.SubscribeFragment;
import com.newcolor.qixinginfo.model.Msg;

import org.json.JSONException;
import org.json.JSONObject;

import cn.jpush.android.api.JPushInterface;

/**
 * 自定义接收器  Jpush接收器
 * 
 * 如果不定义这个 Receiver，则：
 * 1) 默认用户会打开主界面
 * 2) 接收不到自定义消息
 */
public class MyReceiver extends BroadcastReceiver {


	private static final String TAG = "JPush";

	@Override
	public void onReceive(Context context, Intent intent) {
        Bundle bundle = intent.getExtras();
		Log.d(TAG, "[MyReceiver] onReceive - " + intent.getAction() + ", extras: " + printBundle(bundle));
		
        if (JPushInterface.ACTION_REGISTRATION_ID.equals(intent.getAction())) {
            String regId = bundle.getString(JPushInterface.EXTRA_REGISTRATION_ID);
            Log.d(TAG, "[MyReceiver] 接收Registration Id : " + regId);
            //send the Registration Id to your server...
                        
        } else if (JPushInterface.ACTION_MESSAGE_RECEIVED.equals(intent.getAction())) {
        	Log.d(TAG, "[MyReceiver] 接收到推送下来的自定义消息: " + bundle.getString(JPushInterface.EXTRA_MESSAGE));
        	processCustomMessage(context, bundle);
        
        } else if (JPushInterface.ACTION_NOTIFICATION_RECEIVED.equals(intent.getAction())) {
            Log.d(TAG, "[MyReceiver] 接收到推送下来的通知");
            int notifactionId = bundle.getInt(JPushInterface.EXTRA_NOTIFICATION_ID);
            Log.d(TAG, "[MyReceiver] 接收到推送下来的通知的ID: " + notifactionId);
        	
        } else if (JPushInterface.ACTION_NOTIFICATION_OPENED.equals(intent.getAction())) {
            Log.d(TAG, "[MyReceiver] 用户点击打开了通知");
        	//打开自定义的Activity
//			ActivityManager am = (ActivityManager) context.getSystemService(Activity.ACTIVITY_SERVICE);
//			ComponentName cn = am.getRunningTasks(1).get(0).topActivity;
//			if(cn.getClassName().equals(MainActivity.class.getName())){
//				Intent rIntent = new Intent(MainActivity.ACTION_1);
//				rIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//				rIntent.putExtra("index", 2);
//				context.sendBroadcast(rIntent);
//			}else {
//				Intent i = new Intent(context, MainActivity.class);
//				i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
//				i.putExtra("index", 2);
//				context.startActivity(i);
//			}
			Intent i;
			Msg msg=this.getMsgByBundle(bundle);
			if(msg.getType().equals("1")) {
//				i = new Intent(context, SubscribeActivity.class);
//				i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//				context.startActivity(i);
				i = new Intent(context, MainActivity.class);
				i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				i.putExtra("index",2);
				context.startActivity(i);

			}else{
				i = new Intent(context, MsgActivity.class);
				i.putExtra("msg",msg);
				i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
				context.startActivity(i);
			}

//			Bundle mBundle = new Bundle();
//			mBundle.putParcelable("msg", this.getMsgByBundle(bundle));
//			i.putExtras(mBundle);
//        	//i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//        	i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP );
//        	context.startActivity(i);
        	
        } else if (JPushInterface.ACTION_RICHPUSH_CALLBACK.equals(intent.getAction())) {
            Log.d(TAG, "[MyReceiver] 用户收到到RICH PUSH CALLBACK: " + bundle.getString(JPushInterface.EXTRA_EXTRA));
            //在这里根据 JPushInterface.EXTRA_EXTRA 的内容处理代码，比如打开新的Activity， 打开一个网页等..
        	
        } else if(JPushInterface.ACTION_CONNECTION_CHANGE.equals(intent.getAction())) {
        	boolean connected = intent.getBooleanExtra(JPushInterface.EXTRA_CONNECTION_CHANGE, false);
        	Log.w(TAG, "[MyReceiver]" + intent.getAction() +" connected state change to "+connected);
        } else {
        	Log.d(TAG, "[MyReceiver] Unhandled intent - " + intent.getAction());
        }
	}


	private Msg getMsgByBundle(Bundle bundle){
		Msg msg=new Msg();

		msg.setTitle(bundle.getString(JPushInterface.EXTRA_NOTIFICATION_TITLE));
		msg.setContent(bundle.getString(JPushInterface.EXTRA_MESSAGE));
		String extras = bundle.getString(JPushInterface.EXTRA_EXTRA);
		if(extras!=null && !extras.isEmpty()) {
			try {
				JSONObject jsonObject = new JSONObject(extras);
				msg.setsId(jsonObject.getString("msgId"));
				msg.setMsgState(jsonObject.getString("msgState"));
				msg.setType(jsonObject.getString("type"));
				msg.setMTime(jsonObject.getString("time"));
			} catch (JSONException e) {

			}
		}
		return msg;
	}

	// 打印所有的 intent extra 数据
	private static String printBundle(Bundle bundle) {
		StringBuilder sb = new StringBuilder();
		for (String key : bundle.keySet()) {
			if (key.equals(JPushInterface.EXTRA_NOTIFICATION_ID)) {
				sb.append("\nkey:" + key + ", value:" + bundle.getInt(key));
			}else if(key.equals(JPushInterface.EXTRA_CONNECTION_CHANGE)){
				sb.append("\nkey:" + key + ", value:" + bundle.getBoolean(key));
			} 
			else {
				sb.append("\nkey:" + key + ", value:" + bundle.getString(key));
			}
		}
		return sb.toString();
	}
	
	//send msg to MainActivity
	private void processCustomMessage(Context context, Bundle bundle) {
		KeyguardManager km = (KeyguardManager) context.getSystemService(Context.KEYGUARD_SERVICE);
		if (km.inKeyguardRestrictedInputMode()) {
			Intent alarmIntent = new Intent(context, AlarmHandlerActivity.class);
			alarmIntent.putExtra("msg",this.getMsgByBundle(bundle));
			alarmIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			context.startActivity(alarmIntent);
		}

		if(SubscribeFragment.handler!=null) {
			Message message = new Message();
			message.what = 1;
			Bundle bundle1 = new Bundle();
			bundle1.putParcelable("msg", this.getMsgByBundle(bundle));
			message.setData(bundle1);
			SubscribeFragment.handler.sendMessage(message);
		}
	}
}
