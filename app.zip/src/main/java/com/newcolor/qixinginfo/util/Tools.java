package com.newcolor.qixinginfo.util;

import android.app.Notification;
import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.provider.ContactsContract;
import android.util.TypedValue;
import android.view.View;
import android.widget.ImageView;
import android.provider.ContactsContract.CommonDataKinds.Phone;

import com.newcolor.qixinginfo.R;
import com.newcolor.qixinginfo.dialog.AlertDialog;
import com.newcolor.qixinginfo.global.Constant;
import com.newcolor.qixinginfo.model.ContactVO;
import com.newcolor.qixinginfo.model.LoadImgVO;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import cn.jpush.android.api.BasicPushNotificationBuilder;
import cn.jpush.android.api.JPushInterface;
import cn.sharesdk.framework.Platform;
import cn.sharesdk.onekeyshare.OnekeyShare;
import cn.sharesdk.onekeyshare.ShareContentCustomizeCallback;
import cn.sharesdk.wechat.favorite.WechatFavorite;
import cn.sharesdk.wechat.friends.Wechat;
import cn.sharesdk.wechat.moments.WechatMoments;

/**
 * 常用工具
 * Created by Administrator on 2015/11/27.
 */
public class Tools {
    private static final String qqShareURL="http://fusion.qq.com/cgi-bin/qzapps/unified_jump?appid=11940227&from=singlemessage&isTimeline=false&actionFlag=0&params=pname%3Dcom.newcolor.qixinginfo%26versioncode%3D240%26channelid%3D%26actionflag%3D0&isappinstalled=1";

    /**
     * 演示调用ShareSDK执行分享
     *
     * @param context
     * @param platformToShare  指定直接分享平台名称（一旦设置了平台名称，则九宫格将不会显示）
     * @param showContentEdit  是否显示编辑页
     */
    public static void showShare(final Context context, String platformToShare, boolean showContentEdit) {
//        OnekeyShare oks = new OnekeyShare();
//        oks.setSilent(!showContentEdit);
//        if (platformToShare != null) {
//            oks.setPlatform(platformToShare);
//        }
//        //ShareSDK快捷分享提供两个界面第一个是九宫格 CLASSIC  第二个是SKYBLUE
//        oks.setTheme(OnekeyShareTheme.CLASSIC);
//        // 令编辑页面显示为Dialog模式
//        oks.setDialogMode();
//        // 在自动授权时可以禁用SSO方式
//        oks.disableSSOWhenAuthorize();
//        //oks.setAddress("12345678901"); //分享短信的号码和邮件的地址
//        oks.setTitle("废废网");
////        oks.setTitleUrl("http://mob.com");
//        oks.setText("在废废网实现三级分销，只要你成功推荐安装就有钱赚，快点加入吧！");
//        //oks.setImagePath("/sdcard/test-pic.jpg");  //分享sdcard目录下的图片
////        oks.setImageUrl("http://f1.sharesdk.cn/imgs/2014/02/26/owWpLZo_638x960.jpg");
//        oks.setUrl("http://www.mob.com"); //微信不绕过审核分享链接
//        //oks.setFilePath("/sdcard/test-pic.jpg");  //filePath是待分享应用程序的本地路劲，仅在微信（易信）好友和Dropbox中使用，否则可以不提供
//        oks.setComment("分享"); //我对这条分享的评论，仅在人人网和QQ空间使用，否则可以不提供
//        oks.setSite("废废网");  //QZone分享完之后返回应用时提示框上显示的名称
//        oks.setSiteUrl("http://mob.com");//QZone分享参数
//        oks.setVenueName("废废网");
//        oks.setVenueDescription("This is a beautiful place!");
//        oks.setShareFromQQAuthSupport(false);
//        // 启动分享
//        oks.show(context);

        OnekeyShare oks  =  new OnekeyShare() ;

        // 分享时Notification的图标和文字
//        oks.setNotification (R. drawable. ic_launcher,
//                getContext ( ). getString (R. string. app_name ) ) ;
        // address是接收人地址，仅在信息和邮件使用
        oks. setAddress("") ;
        // title标题，印象笔记、邮箱、信息、微信、人人网和QQ空间使用
        oks. setTitle("废废网") ;
        // titleUrl是标题的网络链接，仅在人人网和QQ空间使用
        oks. setTitleUrl(qqShareURL) ;
        // text是分享文本，所有平台都需要这个字段
        oks. setText("<a href="+qqShareURL+">"+ R.string.share_txt+"</a>") ;
        // imagePath是图片的本地路径，Linked-In以外的平台都支持此参数
//        oks. setImagePath (MainActivity. TEST_IMAGE ) ;
        // imageUrl是图片的网络路径，新浪微博、人人网、QQ空间、
        // 微信的两个平台、Linked-In支持此字段
//        oks. setImageUrl ( "http://img.aaaly.cn/app/cli_100px.png" );
        // url仅在微信（包括好友和朋友圈）中使用
        oks. setUrl (qqShareURL) ;
        // appPath是待分享应用程序的本地路劲，仅在微信中使用
//        oks. setAppPath (MainActivity. TEST_IMAGE ) ;
        // comment是我对这条分享的评论，仅在人人网和QQ空间使用
//        oks. setComment () ;
        // site是分享此内容的网站名称，仅在QQ空间使用
        oks. setSite("废废网") ;
        // siteUrl是分享此内容的网站地址，仅在QQ空间使用
        oks. setSiteUrl (qqShareURL) ;
        // venueName是分享社区名称，仅在Foursquare使用
//        oks. setVenueName ( "Southeast in China" ) ;
        // venueDescription是分享社区描述，仅在Foursquare使用
//        oks. setVenueDescription ( "This is a beautiful place!" ) ;
        // latitude是维度数据，仅在新浪微博、腾讯微博和Foursquare使用
        oks. setLatitude(23.122619f ) ;
        // longitude是经度数据，仅在新浪微博、腾讯微博和Foursquare使用
        oks. setLongitude(113.372338f ) ;
        // 是否直接分享（true则直接分享）
        oks. setSilent (true ) ;
        // 指定分享平台，和slient一起使用可以直接分享到指定的平台
        if  (platformToShare  !=  null )  {
            oks. setPlatform (platformToShare ) ;
        }
        // 去除注释可通过OneKeyShareCallback来捕获快捷分享的处理结果
        // oks.setCallback(new OneKeyShareCallback());
        //通过OneKeyShareCallback来修改不同平台分享的内容
        oks. setShareContentCustomizeCallback(new ShareContentCustomizeCallback() {
            @Override
            public void onShare(Platform platform, Platform.ShareParams paramsToShare) {
                if(Wechat.NAME.equals(platform.getName())|| WechatMoments.NAME.equals(platform.getName())|| WechatFavorite.NAME.equals(platform.getName())||platform.getName().equals("QQ"))  {
                    String text  = "<a href="+qqShareURL+">"+  context.getResources().getString(R.string.share_txt)+"</a>" ;
                    paramsToShare.setText(text ) ;
                }else{
                    String text  = "<a href=\"http://down.aaaly.com/h.html\">"+ context.getResources().getString(R.string.share_txt)+"</a>" ;
                    paramsToShare.setText(text ) ;
                }
            }
        }) ;

        oks. show(context) ;

    }

    public static void shareGongQiu(final Context context, String platformToShare,final String title, final String content) {
        OnekeyShare oks  =  new OnekeyShare() ;
        oks. setAddress("") ;
        oks. setTitle(title) ;
        oks. setTitleUrl(qqShareURL) ;
        oks. setText(content+"<a href="+qqShareURL+">点击安装废废APP</a>") ;
        oks. setUrl (qqShareURL) ;
        oks. setSite("废废网") ;
        oks. setSiteUrl (qqShareURL) ;
        oks. setLatitude(23.122619f ) ;
        oks. setLongitude(113.372338f ) ;
        oks. setSilent (true ) ;
        if  (platformToShare  !=  null )  {
            oks. setPlatform (platformToShare ) ;
        }
        oks. setShareContentCustomizeCallback(new ShareContentCustomizeCallback() {
            @Override
            public void onShare(Platform platform, Platform.ShareParams paramsToShare) {
                if(Wechat.NAME.equals(platform.getName())|| WechatMoments.NAME.equals(platform.getName())|| WechatFavorite.NAME.equals(platform.getName())||platform.getName().equals("QQ"))  {
                    String text  = content ;
                    paramsToShare.setText(text ) ;
                }else{
                    String text  = title+"\n"+content+"\n<a href=\"http://down.aaaly.com/h.html\">点击安装废废APP</a>" ;
                    paramsToShare.setText(text ) ;
                }
            }
        }) ;

        oks. show(context) ;
    }


    /*节约流量  0:默认  1:一直节省流量  2：一直继续加载 */
    public static int saveFlow=0;
    private static boolean isShowSaveFlow=false;
    private static ArrayList<LoadImgVO> loadImgArr=new ArrayList<LoadImgVO>();

    /*加载图片*/
    public static void loadImg(Context mContext,final String uri, final ImageView imageView, final DisplayImageOptions options,
                               final ImageLoadingListener listener,final int defaultImg){
        if(isShowSaveFlow){
            LoadImgVO vo=new LoadImgVO();
            vo.setmContext(mContext);
            vo.setUri(uri);
            vo.setImageView(imageView);
            vo.setOptions(options);
            vo.setListener(listener);
            vo.setDefaultImg(defaultImg);
            loadImgArr.add(vo);
            return;
        }

        if(IntentUtil.isConnect(mContext)){
            if(!IntentUtil.getNetType(mContext).equals(IntentUtil.Type._WIFI)){
                if(saveFlow==0){
                    new AlertDialog(mContext).builder().setTitle("流量提示")
                            .setMsg("你使用的不是wiffi,加载图片将产生大量流量，是否要取消图片显示？")
                            .setPositiveButton("继续加载", new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    ImageLoader.getInstance().displayImage(uri, imageView, options, listener);
                                    saveFlow=2;
                                    isShowSaveFlow=false;
                                    delayLoadImg();
                                }
                            }).setNegativeButton("节省流量", new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            imageView.setImageResource(defaultImg);
                            saveFlow=1;
                            isShowSaveFlow=false;
                        }
                    }).show();
                    isShowSaveFlow=true;
                }else if(saveFlow==2){
                    ImageLoader.getInstance().displayImage(uri, imageView, options, listener);
                }else if(saveFlow==1){
                    imageView.setImageResource(defaultImg);
                }
            }else{
                ImageLoader.getInstance().displayImage(uri, imageView, options, listener);
            }
        }else{
            imageView.setImageResource(defaultImg);
        }

    }



    private static void delayLoadImg(){
        for(LoadImgVO vo:loadImgArr){
            loadImg(vo.getmContext(), vo.getUri(), vo.getImageView(), vo.getOptions(), vo.getListener(), vo.getDefaultImg());
        }
        loadImgArr.clear();
    }



    public static long getBitmapsize(Bitmap bitmap){

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR1) {
            return bitmap.getByteCount();
        }
        // Pre HC-MR1
        return bitmap.getRowBytes() * bitmap.getHeight();

    }


    /*初始化设置信息*/
    public static void settingHandler(Context mContext){
        if (SharedUtil.getInt(mContext, "isGetMsgNotification") == 1) {
            JPushInterface.setPushTime(mContext, null, 0, 23);
        } else {
            JPushInterface.clearAllNotifications(mContext);
            JPushInterface.setPushTime(mContext, new HashSet<Integer>(), 0, 23);
        }

        if (SharedUtil.getInt(mContext, "isShowNotification") == 1) {
            JPushInterface.resumePush(mContext.getApplicationContext());
        } else {
            JPushInterface.stopPush(mContext.getApplicationContext());
        }



        JPushInterface.setSilenceTime(mContext, SharedUtil.getInt(mContext, "startHours"), SharedUtil.getInt(mContext, "startminutes"), SharedUtil.getInt(mContext, "endHours"), SharedUtil.getInt(mContext, "endminutes"));


        BasicPushNotificationBuilder builder = new BasicPushNotificationBuilder(mContext);
        builder.statusBarDrawable = R.mipmap.ic_launcher;
        if(SharedUtil.getInt(mContext, "isNotificationSound")==1){
            builder.notificationDefaults |= Notification.DEFAULT_SOUND;
        }else if(SharedUtil.getInt(mContext, "isNotificationVibrate")==1){
            builder.notificationDefaults |= Notification.DEFAULT_VIBRATE;
        }
        JPushInterface.setDefaultPushNotificationBuilder(builder);
    }

    public static int dp2px(Context mContext ,int dp) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp,
                mContext.getResources().getDisplayMetrics());
    }

    // ----------------得到本地联系人信息-------------------------------------
    public static List<ContactVO> getLocalContactsInfos(Context context){
        List<ContactVO>localList=new ArrayList<ContactVO>();

        ContentResolver cr = context.getContentResolver();
        String str[] = {Phone.CONTACT_ID, Phone.DISPLAY_NAME, Phone.NUMBER};
        try {
            Cursor cur = cr.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, str, null,null, null);

            if (cur != null) {
                while (cur.moveToNext()) {
                    ContactVO vo = new ContactVO();
                    vo.setPhone(cur.getString(cur
                            .getColumnIndex(Phone.NUMBER)));// 得到手机号码
                    vo.setName(cur.getString(cur
                            .getColumnIndex(Phone.DISPLAY_NAME)));
                    vo.setId(String.valueOf(cur.getLong(cur
                            .getColumnIndex(Phone.CONTACT_ID))));
                    localList.add(vo);

                }
            }
            cur.close();
        }catch (Exception e){
            ToastUtil.showToast(context,"请允许访问通讯录，她会帮你建立圈子，添加好友。");
        }

        return localList;

    }


}


