package com.newcolor.qixinginfo.util;

import com.activeandroid.ActiveAndroid;
import com.activeandroid.annotation.Column;
import com.activeandroid.query.Delete;
import com.activeandroid.query.Select;
import com.activeandroid.query.Update;
import com.activeandroid.util.SQLiteUtils;
import com.newcolor.qixinginfo.model.GongHuoVO;
import com.newcolor.qixinginfo.model.Msg;

import java.sql.SQLClientInfoException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * 本地数据库操作相关
 * Created by Administrator on 2015/11/6.
 */
public class DBUtil {

    /*根据类型获取本地数据库该类型的供求列表*/
    public static List<GongHuoVO> getGongQiuList(int type) {
        return new Select()
                .from(GongHuoVO.class)
                .where("type = ?", type)
                .execute();
    }


    /*更新供求列表本地数据*/
    public static void updateGongQiuData(GongHuoVO vo){
//        SQLiteUtils.execSql("");
//        new Update(GongHuoVO.class)
//            .set("ImgUrl=?," + "Title=?,"
//            + "Content=?,"+ "Phone=?,"+ "Address=?,"+ "Star=?,"+ "Type=?",).where("SId=?",vo.getSId()).execute();


    }


    public static void deletGongQiuByType(int type){
        try {
            new Delete().from(GongHuoVO.class).where("Type=?",type).execute();
        }catch (Exception e){

        }
    }

    public static void deletGongQiuByLimit(){
        SQLiteUtils.execSql("delete from GongQiuData where (select count(id) from GongQiuData)> 2 and id in (select id from GongQiuData order by Time desc limit (select count(id) from GongQiuData) offset 2 )");
    }




    public static void deletMsgByType(int type){
        //new Delete().from(Msg.class).where("Type=? AND MTime",type).execute();
        SQLiteUtils.execSql("delete from MsgData where (select count(SId) from MsgData where Type="+type+")>1000 and SId in (select SId from MsgData where Type="+type+"  order by MTime desc limit (select count(SId) from MsgData where Type="+type+" ) offset 1000)");
    }

    /*根据类型获取本地数据库该类型的供求列表*/
    public static List<Msg> getMsgList(int type,int index,int count) {
        return new Select()
                .from(Msg.class)
                .where("type = ? order by MTime DESC limit ?,?", type, index * count, count)
                .execute();
    }

    public static void deletMsgs(List<Msg> selectArr){
        ActiveAndroid.beginTransaction();
        try {
            for (Msg vo:selectArr){
                vo.delete();
            }
            ActiveAndroid.setTransactionSuccessful();
        }
        finally {
            ActiveAndroid.endTransaction();
        }
    }


    private static String[] getArguments(List<Object> mSetArguments) {
        int setSize = mSetArguments.size();
        String[] args = new String[setSize];

        int i;
        for(i = 0; i < setSize; ++i) {
            args[i] = mSetArguments.get(i).toString();
        }

        return args;
    }
}
