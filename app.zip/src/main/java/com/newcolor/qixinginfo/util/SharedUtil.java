package com.newcolor.qixinginfo.util;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

import com.newcolor.qixinginfo.global.Constant;


//TODO: Auto-generated Javadoc

/**
* © 2012 amsoft.cn
* 名称：SharedUtil.java
* 描述：保存到 SharedPreferences 的数据.    
*
* @author 司宝垒
* @version v1.0
* @date：2014-10-09 下午11:52:13
*/
public class SharedUtil {

	private static final String SHARED_PATH = Constant.sharePath;
	private static final String CONFIG = Constant.config;

	public static SharedPreferences getDefaultSharedPreferences(Context context) {
		return context.getSharedPreferences(SHARED_PATH, Context.MODE_PRIVATE);
	}
	
	public static void putInt(Context context,String key, int value) {
		SharedPreferences sharedPreferences = getDefaultSharedPreferences(context);
		Editor edit = sharedPreferences.edit();
		edit.putInt(key, value);
		edit.commit();
	}

	public static int getInt(Context context,String key) {
		SharedPreferences sharedPreferences = getDefaultSharedPreferences(context);
		return sharedPreferences.getInt(key, -1);
	}
	
	public static void putString(Context context,String key, String value) {
		SharedPreferences sharedPreferences = getDefaultSharedPreferences(context);
		Editor edit = sharedPreferences.edit();
		edit.putString(key, value);
		edit.commit();
	}

	public static String getString(Context context,String key) {
		SharedPreferences sharedPreferences = getDefaultSharedPreferences(context);
		return sharedPreferences.getString(key,null);
	}
	
	public static void putBoolean(Context context,String key, boolean value) {
		SharedPreferences sharedPreferences = getDefaultSharedPreferences(context);
		Editor edit = sharedPreferences.edit();
		edit.putBoolean(key, value);
		edit.commit();
	}

	public static boolean getBoolean(Context context,String key,boolean defValue) {
		SharedPreferences sharedPreferences = getDefaultSharedPreferences(context);
		return sharedPreferences.getBoolean(key,defValue);
	}

	/**
	 * 清空上次登录参数
	 */
	public static void clearLoginParams(Context context) {
		Editor editor = getDefaultSharedPreferences(context).edit();
		editor.clear();
		editor.commit();
	}


	public static void putConfigString(Context context,String key, String value){
		SharedPreferences sharedPreferences = context.getSharedPreferences(CONFIG,Context.MODE_PRIVATE);
		Editor edit = sharedPreferences.edit();
		edit.putString(key, value);
		edit.commit();
	}

	public static String getConfigString(Context context,String key) {
		SharedPreferences sharedPreferences = context.getSharedPreferences(CONFIG, Context.MODE_PRIVATE);
		return sharedPreferences.getString(key,null);
	}



	public static void putConfigBoolean(Context context,String key, boolean value){
		SharedPreferences sharedPreferences = context.getSharedPreferences(CONFIG,Context.MODE_PRIVATE);
		Editor edit = sharedPreferences.edit();
		edit.putBoolean(key, value);
		edit.commit();
	}

	public static boolean getConfigBoolean(Context context,String key,boolean defValue) {
		SharedPreferences sharedPreferences = context.getSharedPreferences(CONFIG, Context.MODE_PRIVATE);
		return sharedPreferences.getBoolean(key,defValue);
	}

}
