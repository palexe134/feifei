package com.newcolor.qixinginfo.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * 日期相关
 * Created by baolei.si on 2015/8/10.
 */
public class DateUtils {
    private static SimpleDateFormat mDateFormat = new SimpleDateFormat("MM-dd HH:mm");
    private static SimpleDateFormat mYearDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");

    public static String formatSimpleDateTime(long time) {
        if (0 == time) {
            return "";
        }

        return mDateFormat.format(new Date(time));
    }


    public static String formatYearDateTime(long time) {
        if (0 == time) {
            return "";
        }

        return mYearDateFormat.format(new Date(time));
    }


    public static String getCurYearMonthDay(){
        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
        String date=sdf.format(new Date());
        return date;
    }

    public static String getCurDateByStyle(String style){
        SimpleDateFormat sdf=new SimpleDateFormat(style);
        String date=sdf.format(new Date());
        return date;
    }

    // �ַ�����������ת����date����
    public static Date strToDate(String style, String date) {
        SimpleDateFormat formatter = new SimpleDateFormat(style);
        try {
            return formatter.parse(date);
        } catch (ParseException e) {
            e.printStackTrace();
            return new Date();
        }
    }

    public static String dateToStr(String style, Date date) {
        SimpleDateFormat formatter = new SimpleDateFormat(style);
        return formatter.format(date);
    }

    public static String clanderTodatetime(Calendar localCalendar,String style){
        SimpleDateFormat sdf = new SimpleDateFormat(style);
        String dateStr = sdf.format(localCalendar.getTime());

        return dateStr;
    }


    /*早上：6-11点
        凌晨：0-5 和 24点
        晚上：18-23点
        下午：13-17点
        中午：12点
        */
    public static String getShiChenName(int hourOfDay){
        String name="";
        if(hourOfDay>=6 && hourOfDay<=11){
            name="早上";
        }else if((hourOfDay>=0 && hourOfDay<=5)||hourOfDay==24){
            name="凌晨";
        }else if(hourOfDay>=18 && hourOfDay<=23){
            name="晚上";
        }else if(hourOfDay>=13 && hourOfDay<=17){
            name="下午";
        }else if(hourOfDay==12){
            name="中午";
        }
        return name;
    }

}
