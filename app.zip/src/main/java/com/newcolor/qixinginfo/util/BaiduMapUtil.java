package com.newcolor.qixinginfo.util;

import android.content.Context;

import com.alibaba.fastjson.JSON;
import com.baidu.location.LocationClientOption;
import com.baidu.mapapi.model.LatLng;
import com.baidu.mapapi.utils.DistanceUtil;
import com.newcolor.qixinginfo.global.Config;
import com.newcolor.qixinginfo.http.AsyncHttpResponseHandler;
import com.newcolor.qixinginfo.http.RequestParams;
import com.newcolor.qixinginfo.model.BaiDuMapGongQiuVO;
import com.newcolor.qixinginfo.model.BaiDuMapMajorVO;
import com.newcolor.qixinginfo.model.BaiduMapVo;

import java.util.ArrayList;

/**
 * 百度地图处理方法
 * Created by Administrator on 2016/1/17.
 */
public class BaiduMapUtil {
    public static final int[] SCALE = { 1, 20, 50, 100, 200, 500, 1000, 2000,
            5000, 10000, 20000, 25000, 50000, 100000, 200000, 500000, 1000000,
            2000000, 5000000 };

    /*获取默认设置*/
    public static LocationClientOption getDefaultLocationOption(){
        LocationClientOption option = new LocationClientOption();
        option.setLocationMode(LocationClientOption.LocationMode.Hight_Accuracy);//可选，默认高精度，设置定位模式，高精度，低功耗，仅设备
        option.setCoorType("bd09ll");//可选，默认gcj02，设置返回的定位结果坐标系
        int span=0;
        option.setScanSpan(span);//可选，默认0，即仅定位一次，设置发起定位请求的间隔需要大于等于1000ms才是有效的
        option.setIsNeedAddress(true);//可选，设置是否需要地址信息，默认不需要
        option.setOpenGps(true);//可选，默认false,设置是否使用gps
        option.setLocationNotify(true);//可选，默认false，设置是否当gps有效时按照1S1次频率输出GPS结果
        option.setIsNeedLocationDescribe(true);//可选，默认false，设置是否需要位置语义化结果，可以在BDLocation.getLocationDescribe里得到，结果类似于“在北京天安门附近”
        option.setIsNeedLocationPoiList(true);//可选，默认false，设置是否需要POI结果，可以在BDLocation.getPoiList里得到
        option.setIgnoreKillProcess(false);//可选，默认true，定位SDK内部是一个SERVICE，并放到了独立进程，设置是否在stop的时候杀死这个进程，默认不杀死
        option.SetIgnoreCacheException(false);//可选，默认false，设置是否收集CRASH信息，默认收集
        option.setEnableSimulateGps(false);//可选，默认false，设置是否需要过滤gps仿真结果，默认需要
        option.setPriority(LocationClientOption.GpsFirst);

        return option;
    }

    public static void getNearByRecycle(final Context context,BaiduMapVo vo,
                                        final NearByMajorCallBack callBack,
                                        String tags,String filter,int curSize,int count){
        RequestParams params=new RequestParams();
        params.put("location",vo.getCoordinate());
        params.put("type",String.valueOf(vo.getType()));
        params.put("tags",tags);
        params.put("district","临沂市");
        params.put("filter",filter);
        params.put("curSize",String.valueOf(curSize));
        params.put("count",String.valueOf(count));

        HttpUtil.get(Config.getNearByRecycle, params, new AsyncHttpResponseHandler() {
            @Override
            public void onFailure(Throwable error, String content) {
                super.onFailure(error, content);
                ToastUtil.showToast(context, content);
            }

            @Override
            public void onSuccess(String content) {
                super.onSuccess(content);
                ArrayList<BaiDuMapMajorVO> arrayList = (ArrayList<BaiDuMapMajorVO>) JSON.parseArray(content, BaiDuMapMajorVO.class);

                callBack.onCom(arrayList);
            }
        });

    }

    public static void getNearbyGongQiu(final Context context,BaiduMapVo vo, final NearByGongQiuCallBack callBack){
        getNearbyGongQiu(context, vo, callBack, "", "");
    }

    public static void getNearbyGongQiu(final Context context,BaiduMapVo vo,
            final NearByGongQiuCallBack callBack,String tags,String filter
            ,int curSize,int count){
        RequestParams params=new RequestParams();
        params.put("location",vo.getCoordinate());
        params.put("type",String.valueOf(vo.getType()));
        params.put("tags",tags);
        params.put("filter",filter);
        params.put("curSize",String.valueOf(curSize));
        params.put("count",String.valueOf(count));

        HttpUtil.get(Config.getNearbyGongQiu, params, new AsyncHttpResponseHandler() {
            @Override
            public void onFailure(Throwable error, String content) {
                super.onFailure(error, content);
                ToastUtil.showToast(context, content);
            }

            @Override
            public void onSuccess(String content) {
                super.onSuccess(content);
                ArrayList<BaiDuMapGongQiuVO> arrayList = (ArrayList<BaiDuMapGongQiuVO>) JSON.parseArray(content, BaiDuMapGongQiuVO.class);

                callBack.onCom(arrayList);
            }
        });
    }

    public static void getNearbyGongQiu(final Context context,BaiduMapVo vo,
            final NearByGongQiuCallBack callBack,String tags,String filter){
        getNearbyGongQiu(context, vo, callBack, tags, filter, 0, 20);
    }


    /*获取百度地图缩放等级*/
    public static int getZoomlevel(LatLng fromGeopoint, LatLng toGeopoint){
        int zoomLevel=15;
        //通过getDistance函数得出两点间的真实距离
        double distance = DistanceUtil.getDistance(fromGeopoint, toGeopoint);
        if(distance<=SCALE[9]){
            return zoomLevel;
        }else if(distance>=SCALE[SCALE.length-1]){
            return 1;
        }
        //真实距离和数组中相近的两个值循环比较，以小值为准，得出规定好的比例尺数值赋值给dis
        for (int j = 1; j < SCALE.length; j++) {
            if (SCALE[j - 1] <= distance && distance < SCALE[j]) {
                zoomLevel=SCALE.length-j+4;
                break;
            }
        }
        return zoomLevel;
    }

    public interface NearByGongQiuCallBack{
        public void onCom(ArrayList<BaiDuMapGongQiuVO> arrayList);
    }


    public interface NearByMajorCallBack{
        public void onCom(ArrayList<BaiDuMapMajorVO> arrayList);
    }


}
