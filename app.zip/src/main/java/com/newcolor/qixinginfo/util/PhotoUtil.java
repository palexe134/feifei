package com.newcolor.qixinginfo.util;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;

import com.newcolor.qixinginfo.global.Constant;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 图片处理相关
 * Created by Administrator on 2015/10/30.
 */
public class PhotoUtil {

    public static final String IMAGE_FILE_LOCATION = "file:///sdcard/temp.jpg";//temp file
    /**
     * 为新拍摄的图片的文件命名
     * @return
     */
    @SuppressLint("SimpleDateFormat")
    public static String getPhotoFileName() {
        Date time = new Date(System.currentTimeMillis());
        DateFormat dateFormat = new SimpleDateFormat("'IMG'_yyyyMMdd_HHmmss");
        return dateFormat.format(time) + ".jpg";
    }


    /**
     * 将头像转换成byte[]以便能将图片存到数据库里
     * @param bitmap
     * @return
     */
    public static byte[] getBitmapByte(Context context,Bitmap bitmap) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 40, out);
        try {
            out.flush();
            out.close();
        } catch (IOException e) {
            e.printStackTrace();
            LogUtil.e(context.getClass(),"转换字节异常");
        }
        return out.toByteArray();
    }


    public static Intent cropImageUri(Uri uri, int outputX, int outputY,int aspectX,int aspectY){
        Intent intent = new Intent("com.android.camera.action.CROP");
        intent.setDataAndType(uri, "image/*");
        intent.putExtra("crop", "true");
        intent.putExtra("aspectX", aspectX);
        intent.putExtra("aspectY", aspectY);
        intent.putExtra("outputX", outputX);
        intent.putExtra("outputY", outputY);
        intent.putExtra("scale", true);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, uri);
        intent.putExtra("return-data", false);
        intent.putExtra("outputFormat", Bitmap.CompressFormat.JPEG.toString());
        intent.putExtra("noFaceDetection", true); // no face detection
        return intent;
    }

    public static Intent cropSmallImage(int outputX, int outputY,int aspectX,int aspectY){
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT, null);
        intent.setType("image/*");
        intent.putExtra("crop", "true");
        intent.putExtra("aspectX", aspectX);
        intent.putExtra("aspectY", aspectY);
        intent.putExtra("outputX", outputX);
        intent.putExtra("outputY", outputY);
        intent.putExtra("scale", true);
        intent.putExtra("return-data", true);
        intent.putExtra("outputFormat", Bitmap.CompressFormat.JPEG.toString());
        intent.putExtra("noFaceDetection", true); // no face detection
        return intent;
    }

    public static Intent cropBigImage(Uri uri,int outputX, int outputY,int aspectX,int aspectY){
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT, null);
        intent.setType("image/*");
        intent.putExtra("crop", "true");
        intent.putExtra("aspectX", aspectX);
        intent.putExtra("aspectY", aspectY);
        intent.putExtra("outputX", outputX);
        intent.putExtra("outputY", outputY);
        intent.putExtra("scale", true);
        intent.putExtra("return-data", false);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, uri);
        intent.putExtra("outputFormat", Bitmap.CompressFormat.JPEG.toString());
        intent.putExtra("noFaceDetection", true); // no face detection
        return intent;
    }


    public static Bitmap decodeUriAsBitmap(Uri uri,Context context){
        Bitmap bitmap = null;
        try {
            bitmap = BitmapFactory.decodeStream(context.getContentResolver().openInputStream(uri));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return null;
        }
        return bitmap;
    }

    public static Uri getTempUri() {
        return Uri.fromFile(getTempFile());
    }

    private static File getTempFile() {
        if (isSDCARDMounted()) {

            File f = new File(Constant.PHOTO_DIR,getPhotoFileName());
            try {
                f.createNewFile();
            } catch (IOException e) {
                System.out.print("创建文件失败:"+e);
            }
            return f;
        } else {
            return null;
        }
    }

    private static boolean isSDCARDMounted() {
        String status = Environment.getExternalStorageState();

        if (status.equals(Environment.MEDIA_MOUNTED))
            return true;
        return false;
    }



}
