package com.newcolor.qixinginfo.util;

import android.content.Context;
import android.view.View;

import com.newcolor.qixinginfo.dialog.ActionSheetDialog;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * 地址管理相关工具类
 * Created by Administrator on 2015/10/22.
 */
public class AdressUtil {
    /**
     * 把全国的省市区的信息以json的格式保存，解析完成后赋值为null
     */
    private JSONObject mJsonObj;
    /**
     * 所有省
     */
    private String[] mProvinceDatas;
    private String[] areas;
    private String[] cities;
    /**
     * key - 省 value - 市s
     */
    private  Map<String, String[]> mCitisDatasMap = new HashMap<String, String[]>();
    /**
     * key - 市 values - 区s
     */
    private  Map<String, String[]> mAreaDatasMap = new HashMap<String, String[]>();
    /**
     * 当前省的名称
     */
    private String mCurrentProviceName;
    /**
     * 当前市的名称
     */
    private String mCurrentCityName;
    /**
     * 当前区的名称
     */
    private String mCurrentAreaName ="";

    private ActionSheetDialog proviceSD;
    private ActionSheetDialog citisSD;
    private ActionSheetDialog areaSD;

    private boolean isSelecting=false;
    private Callback callback;
    private Context context;

    private static AdressUtil instance;
    public static AdressUtil getInstance(Context context){
        if(instance==null){
            instance=new AdressUtil(context);
        }
        instance.context=context;
        return instance;
    }

    public AdressUtil(Context context){
        this.context=context;
        initJsonData();
        initDatas();
    }

    public void destroy(){
        if(proviceSD!=null){
            proviceSD.dismiss();
        }
        if(citisSD!=null){
            citisSD.dismiss();
        }
        if(areaSD!=null){
            areaSD.dismiss();
        }
        this.isSelecting=false;
    }

    public String[] getProvinceDatas(){
        return mProvinceDatas;
    }

    public Map<String, String[]> getCitisDatasMap(){
        return mCitisDatasMap;
    }

    public Map<String, String[]> getAreaDatasMap(){
        return mAreaDatasMap;
    }

    /**
     * 从assert文件夹中读取省市区的json文件，然后转化为json对象
     */
    private void initJsonData()
    {
        try
        {
            StringBuffer sb = new StringBuffer();
            InputStream is = context.getAssets().open("city.json");
            int len = -1;
            byte[] buf = new byte[1024];
            while ((len = is.read(buf)) != -1)
            {
                sb.append(new String(buf, 0, len, "utf-8"));
            }
            is.close();
            mJsonObj = new JSONObject(sb.toString());
        } catch (IOException e)
        {
            e.printStackTrace();
        } catch (JSONException e)
        {
            e.printStackTrace();
        }
    }

    /**
     * 解析整个Json对象，完成后释放Json对象的内存
     */
    private void initDatas()
    {
        try
        {
            JSONArray jsonArray = mJsonObj.getJSONArray("citylist");
            mProvinceDatas = new String[jsonArray.length()];
            for (int i = 0; i < jsonArray.length(); i++)
            {
                JSONObject jsonP = jsonArray.getJSONObject(i);// 每个省的json对象
                String province = jsonP.getString("p");// 省名字

                mProvinceDatas[i] = province;

                JSONArray jsonCs = null;
                try
                {
                    /**
                     * Throws JSONException if the mapping doesn't exist or is
                     * not a JSONArray.
                     */
                    jsonCs = jsonP.getJSONArray("c");
                } catch (Exception e1)
                {
                    continue;
                }
                String[] mCitiesDatas = new String[jsonCs.length()];
                for (int j = 0; j < jsonCs.length(); j++)
                {
                    JSONObject jsonCity = jsonCs.getJSONObject(j);
                    String city = jsonCity.getString("n");// 市名字
                    mCitiesDatas[j] = city;
                    JSONArray jsonAreas = null;
                    try
                    {
                        /**
                         * Throws JSONException if the mapping doesn't exist or
                         * is not a JSONArray.
                         */
                        jsonAreas = jsonCity.getJSONArray("a");
                    } catch (Exception e)
                    {
                        continue;
                    }

                    String[] mAreasDatas = new String[jsonAreas.length()];// 当前市的所有区
                    for (int k = 0; k < jsonAreas.length(); k++)
                    {
                        String area = jsonAreas.getJSONObject(k).getString("s");// 区域的名称
                        mAreasDatas[k] = area;
                    }
                    mAreaDatasMap.put(city, mAreasDatas);
                }

                mCitisDatasMap.put(province, mCitiesDatas);
            }

        } catch (JSONException e)
        {
            e.printStackTrace();
        }
        mJsonObj = null;
    }


    public void chooseAddress(Callback callback){
        if(isSelecting){
            return;
        }
        this.callback=callback;
        mCurrentProviceName="";
        mCurrentCityName="";
        mCurrentAreaName="";

        proviceSD=new ActionSheetDialog(context);
        proviceSD.builder(cancleListener);
        proviceSD.setCancelable(false);
        proviceSD.setCanceledOnTouchOutside(false);
        for(int i=0;i<mProvinceDatas.length;i++){
            proviceSD.addSheetItem(mProvinceDatas[i], ActionSheetDialog.SheetItemColor.Blue, proviceSheetItemClick);
        }
        isSelecting=true;
        proviceSD.show();
    }



    ActionSheetDialog.OnSheetItemClickListener proviceSheetItemClick=new ActionSheetDialog.OnSheetItemClickListener() {
        @Override
        public void onClick(int which) {
            mCurrentProviceName=mProvinceDatas[which-1];
            cities = mCitisDatasMap.get(mCurrentProviceName);
            if (cities == null)
            {
                cities = new String[] { "" };
            }
            citisSD=new ActionSheetDialog(context);
            citisSD.builder(cancleListener);
            citisSD.setCancelable(false);
            citisSD.setCanceledOnTouchOutside(false);
            for(int i=0;i<cities.length;i++){
                citisSD.addSheetItem(cities[i], ActionSheetDialog.SheetItemColor.Blue,citySheetItemClick);
            }
            citisSD.show();
        }
    };

    ActionSheetDialog.OnSheetItemClickListener citySheetItemClick=new ActionSheetDialog.OnSheetItemClickListener() {
        @Override
        public void onClick(int which) {
            mCurrentCityName=cities[which-1];
            areas= mAreaDatasMap.get(mCurrentCityName);
            if (areas == null)
            {
//                areas = new String[] { "" };
                if(callback!=null) {
                    isSelecting=false;
                    callback.onCom(mCurrentProviceName,mCurrentCityName,mCurrentAreaName);
//                    address_TV.setText(mCurrentProviceName + mCurrentCityName + mCurrentAreaName);
                }
                return;
            }
            areaSD=new ActionSheetDialog(context);
            areaSD.builder(cancleListener);
            areaSD.setCancelable(false);
            areaSD.setCanceledOnTouchOutside(false);
            for(int i=0;i<areas.length;i++){
                areaSD.addSheetItem(areas[i], ActionSheetDialog.SheetItemColor.Blue,areaSheetItemClick);
            }
            areaSD.show();
        }
    };

    ActionSheetDialog.OnSheetItemClickListener areaSheetItemClick=new ActionSheetDialog.OnSheetItemClickListener() {
        @Override
        public void onClick(int which) {
            mCurrentAreaName=areas[which-1];

            isSelecting=false;
            if(callback!=null) {
                callback.onCom(mCurrentProviceName,mCurrentCityName,mCurrentAreaName);
//                    address_TV.setText(mCurrentProviceName + mCurrentCityName + mCurrentAreaName);
            }
        }
    };

    private ActionSheetDialog.OnCancleClickListener cancleListener= new ActionSheetDialog.OnCancleClickListener() {
        @Override
        public void onCacle() {
            isSelecting=false;
        }
    };

    /**
     * 自定义接口，用于回调按钮点击事件到Activity
     * @author Ivan Xu
     * 2014-11-26
     */
    public interface Callback {
        public void onCom(String proviceName,String cityName,String areaName);
    }

}
