package com.newcolor.qixinginfo.util;

import android.content.Context;

import com.alibaba.fastjson.JSON;
import com.newcolor.qixinginfo.dialog.ActionSheetDialog;
import com.newcolor.qixinginfo.global.Config;
import com.newcolor.qixinginfo.http.AsyncHttpResponseHandler;
import com.newcolor.qixinginfo.http.RequestParams;
import com.newcolor.qixinginfo.model.GoodTypeVO;

import java.util.ArrayList;

/**
 * 物品类型选择器
 *
 * Created by Administrator on 2015/10/22.
 */
public class ChooseTypeUtil {
    private ActionSheetDialog typeSD1;
    private ActionSheetDialog typeSD2;
    private ActionSheetDialog typeSD3;
    private int rootId=0;

    private ArrayList<GoodTypeVO> type1Arr;
    private ArrayList<GoodTypeVO> type2Arr;
    private ArrayList<GoodTypeVO> type3Arr;

    private boolean isSelecting=false;
    private Callback callback;
    private Context context;


    private static ChooseTypeUtil instance;
    public static ChooseTypeUtil getInstance(Context context){
        if(instance==null){
            instance=new ChooseTypeUtil(context);
        }
        instance.context=context;
        return instance;
    }

    public ChooseTypeUtil(Context context){
        this.context=context;
        //initDatas();
    }

    public void destroy(){
        if(typeSD1!=null){
            typeSD1.dismiss();
        }
        if(typeSD2!=null){
            typeSD2.dismiss();
        }
        if(typeSD3!=null){
            typeSD3.dismiss();
        }
        this.isSelecting=false;
    }


    public void getClassificationVo(int id,final Callback mCallback){
        RequestParams params=new RequestParams();
        params.put("id", String.valueOf(id));

        HttpUtil.get(Config.getClassificationVo, params, new AsyncHttpResponseHandler() {
            @Override
            public void onFailure(Throwable error, String content) {
                super.onFailure(error, content);
            }

            @Override
            public void onSuccess(String content) {
                super.onSuccess(content);

                GoodTypeVO vo = JSON.parseObject(content, GoodTypeVO.class);
                mCallback.onCom(vo);

            }
        });
    }

    /**
     * 解析整个Json对象，完成后释放Json对象的内存
     */
    public void showDatas(Callback callback){
        this.callback=callback;
        rootId=0;
        this.getDataByRootId(new GetDataCallback() {
            @Override
            public void onCom(ArrayList<GoodTypeVO> arr) {
                chooseType1(arr);
            }
        });
    }

    private void getDataByRootId(final GetDataCallback callback){
        RequestParams params=new RequestParams();
        params.put("rootId", String.valueOf(rootId));

        HttpUtil.get(Config.getClassification, params, new AsyncHttpResponseHandler() {
            @Override
            public void onFailure(Throwable error, String content) {
                super.onFailure(error, content);
            }

            @Override
            public void onSuccess(String content) {
                super.onSuccess(content);

                ArrayList<GoodTypeVO> arrayList = (ArrayList<GoodTypeVO>) JSON.parseArray(content, GoodTypeVO.class);
                callback.onCom(arrayList);

            }
        });
    }


    public void chooseType1(ArrayList<GoodTypeVO> arrayList){
        type1Arr=arrayList;
        if(isSelecting){
            return;
        }
        typeSD1=new ActionSheetDialog(context);
        typeSD1.builder(cancleListener);
        typeSD1.setCancelable(false);
        typeSD1.setCanceledOnTouchOutside(false);
        for(int i=0;i<arrayList.size();i++){
            typeSD1.addSheetItem(arrayList.get(i).getName(), ActionSheetDialog.SheetItemColor.Blue, type1SheetItemClick);
        }
        isSelecting=true;
        typeSD1.show();
    }



    ActionSheetDialog.OnSheetItemClickListener type1SheetItemClick=new ActionSheetDialog.OnSheetItemClickListener() {
        @Override
        public void onClick(int which) {
            final GoodTypeVO vo= type1Arr.get(which - 1);
            rootId=vo.getsId();
            getDataByRootId(new GetDataCallback() {
                @Override
                public void onCom(ArrayList<GoodTypeVO> arr) {
                    chooseType2(arr,vo);
                }
            });

        }
    };

    public void chooseType2(ArrayList<GoodTypeVO> arrayList,GoodTypeVO vo){
        type2Arr=arrayList;
        if (type2Arr == null){
            if(callback!=null) {
                isSelecting=false;
                callback.onCom(vo);
//                    address_TV.setText(mCurrentProviceName + mCurrentCityName + mCurrentAreaName);
            }
            return;
        }
        typeSD2=new ActionSheetDialog(context);
        typeSD2.builder(cancleListener);
        typeSD2.setCancelable(false);
        typeSD2.setCanceledOnTouchOutside(false);
        for(int i=0;i<arrayList.size();i++){
            typeSD2.addSheetItem(arrayList.get(i).getName(), ActionSheetDialog.SheetItemColor.Blue, type2SheetItemClick);
        }
        isSelecting=true;
        typeSD2.show();
    }

    ActionSheetDialog.OnSheetItemClickListener type2SheetItemClick=new ActionSheetDialog.OnSheetItemClickListener() {
        @Override
        public void onClick(int which) {
            final GoodTypeVO vo= type2Arr.get(which - 1);
            rootId=vo.getsId();
            getDataByRootId(new GetDataCallback() {
                @Override
                public void onCom(ArrayList<GoodTypeVO> arr) {
                    chooseType3(arr,vo);
                }
            });
        }
    };

    public void chooseType3(ArrayList<GoodTypeVO> arrayList,GoodTypeVO vo){
        type3Arr=arrayList;
        isSelecting=false;
        if (type3Arr == null){
            if(callback!=null) {
                callback.onCom(vo);
//                    address_TV.setText(mCurrentProviceName + mCurrentCityName + mCurrentAreaName);
            }
            return;
        }

        typeSD3=new ActionSheetDialog(context);
        typeSD3.builder(cancleListener);
        typeSD3.setCancelable(false);
        typeSD3.setCanceledOnTouchOutside(false);
        for(int i=0;i<arrayList.size();i++){
            typeSD3.addSheetItem(arrayList.get(i).getName(), ActionSheetDialog.SheetItemColor.Blue, type3SheetItemClick);
        }
        isSelecting=true;
        typeSD3.show();

    }


    ActionSheetDialog.OnSheetItemClickListener type3SheetItemClick=new ActionSheetDialog.OnSheetItemClickListener() {
        @Override
        public void onClick(int which) {
            GoodTypeVO vo= type3Arr.get(which - 1);

            isSelecting=false;
            if(callback!=null) {
                callback.onCom(vo);
//                    address_TV.setText(mCurrentProviceName + mCurrentCityName + mCurrentAreaName);
            }
        }
    };

    private ActionSheetDialog.OnCancleClickListener cancleListener= new ActionSheetDialog.OnCancleClickListener() {
        @Override
        public void onCacle() {
            isSelecting=false;
        }
    };



    /**
     * 自定义接口，用于回调按钮点击事件到Activity
     * @author Ivan Xu
     * 2014-11-26
     */
    public interface Callback {
        public void onCom(GoodTypeVO vo);
    }


    /**
     * 自定义接口，用于回调按钮点击事件到Activity
     * @author Ivan Xu
     * 2014-11-26
     */
    public interface GetDataCallback {
        public void onCom(ArrayList<GoodTypeVO> arr);
    }

}
