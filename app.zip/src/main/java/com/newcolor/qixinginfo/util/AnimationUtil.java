package com.newcolor.qixinginfo.util;

import android.content.Context;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.RotateAnimation;
import android.view.animation.TranslateAnimation;

/**
 * 动画工具类
 * Created by Administrator on 2016/3/2.
 */
public class AnimationUtil {

    public static void to(View view,Context mContext,float fromXDelta, float toXDelta, float fromYDelta, float toYDelta,int duration,int resID){
        //方式一通过代码的方式定义位移动画

        Animation translateAnimation=new TranslateAnimation(fromXDelta, toXDelta, fromYDelta, toYDelta);

        translateAnimation.setDuration(duration);//设置动画持续时间为3秒

        translateAnimation.setInterpolator(mContext, resID);//设置动画插入器

        translateAnimation.setFillAfter(true);//设置动画结束后保持当前的位置（即不返回到动画开始前的位置）

        view.startAnimation(translateAnimation);
    }

    public static void rotate(View view,Context mContext,float fromDegrees, float toDegrees,int duration,int resID, float pivotX, float pivotY){
        //方式一通过代码的方式定义位移动画

        Animation rotateAnimation=new RotateAnimation(fromDegrees,toDegrees,Animation.RELATIVE_TO_SELF, pivotX,Animation.RELATIVE_TO_SELF,pivotY);

        rotateAnimation.setDuration(duration);//设置动画持续时间为3秒

        rotateAnimation.setInterpolator(mContext, resID);//设置动画插入器

        rotateAnimation.setFillAfter(true);//设置动画结束后保持当前的位置（即不返回到动画开始前的位置）

        view.startAnimation(rotateAnimation);
    }
}
