package com.newcolor.qixinginfo.util;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.view.View;

import com.newcolor.qixinginfo.activity.LoginActivity;
import com.newcolor.qixinginfo.dialog.AlertDialog;
import com.newcolor.qixinginfo.global.Config;
import com.newcolor.qixinginfo.global.Constant;
import com.newcolor.qixinginfo.global.MyApplication;
import com.newcolor.qixinginfo.http.AsyncHttpResponseHandler;
import com.newcolor.qixinginfo.http.RequestParams;
import com.newcolor.qixinginfo.upload.HttpMultipartPost;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.Set;

import cn.jpush.android.api.JPushInterface;
import cn.jpush.android.api.TagAliasCallback;

/**
 * 登录相关
 *
 * Created by Administrator on 2015/11/5.
 */
public class LoginUtil {
    private static boolean isLogin=false;
    private static boolean isLogining=false;

    public static boolean gotoLogin(final Context context){
        if(!IntentUtil.isConnect(context)){
            ToastUtil.showToast(context,"网络未连接，请检查网络");
            return false;
        }
        return gotoLogin(context,true,null);
    }

    public static boolean gotoLogin(final Context context,final boolean isForce,final Callback callback){
        String mStr_name=SharedUtil.getString(context,Constant.USERNAMECOOKIE);
        String mStr_pwd=SharedUtil.getString(context,Constant.USERPASSWORDCOOKIE);
        if(mStr_name!=null && mStr_pwd!=null && !mStr_name.isEmpty()&&!mStr_pwd.isEmpty()){
            return gotoLogin(context,SharedUtil.getString(context,Constant.USERNAMECOOKIE)
                    ,SharedUtil.getString(context,Constant.USERPASSWORDCOOKIE),null);
        }else if(!isForce){
            if(callback!=null) {
                callback.onCom();
            }
            return false;
        }

        Intent intent=new Intent(context, LoginActivity.class);
        context.startActivity(intent);
        return false;
    }

    public static boolean gotoLogin(final Context context, final String account, final String passWord,final Callback callback){
        if(isLogining)return false;
        isLogining=true;

//        File sdCard = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS);
//        sdCard = new File(sdCard, "/MyFiles/feifeiToken");
//        sdCard.delete();

        String tokenStr="";
//        if(FileUtil.isExternalStorageWritable()){
//            try {
//                tokenStr=FileUtil.loadData(context,"feifeiToken", Environment.MEDIA_MOUNTED);
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        }else{
//            try {
//                tokenStr=FileUtil.readFiles(context,"feifeiToken");
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//        }
        tokenStr=SharedUtil.getConfigString(context, Constant.TOKEN);

        RequestParams params=new RequestParams();
        params.put("account",account);
        params.put("passWord",passWord);
        params.put("token",tokenStr);
        params.put("wlanMac",IntentUtil.getWlanMAC(context));
        params.put("versionName", IntentUtil.getCurrentVersionName(context));
        params.put("versionCode",String.valueOf(IntentUtil.getCurrentVersionCode(context)));

        HttpUtil.get(Config.userLogin, params, new AsyncHttpResponseHandler() {
            @Override
            public void onFailure(Throwable error, String content) {
                super.onFailure(error, content);
                isLogining = false;
            }

            @Override
            public void onSuccess(String content) {
                super.onSuccess(content);
                isLogining = false;

                JSONObject jsonObject = null;
                try {
                    jsonObject = new JSONObject(content);
                    byte isSuc = Byte.parseByte(jsonObject.getString("isSuc"));
                    if (isSuc == 0) {
                        String msg = jsonObject.getString("msg");
                        ToastUtil.showToast(context, msg);
                        isLogin = false;
                    } else if (isSuc == 2) {
                        new AlertDialog(context).builder().setTitle("联系客服")
                                .setMsg("您的账号在别的设备上登陆，请注意安全，及时联系废废客服\n\n13345086668")
                                .setPositiveButton("确定", new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        phoneHandler(context);
                                    }
                                }).setNegativeButton("取消", new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                            }
                        }).show();
                        isLogin = false;
                    } else {
                        MyApplication.getInstance().setUserId(jsonObject.getString("userId"));

                        SharedUtil.putString(context, Constant.USERNAMECOOKIE, account);
                        SharedUtil.putString(context, Constant.USERPASSWORDCOOKIE, passWord);

                        String tokenStr = jsonObject.getString("token");
                        SharedUtil.putConfigString(context,Constant.TOKEN,tokenStr);

//                        if (FileUtil.isExternalStorageWritable()) {
//                            try {
//                                FileUtil.saveData(context, "feifeiToken", tokenStr, Environment.MEDIA_MOUNTED);
//                            } catch (IOException e) {
//                                e.printStackTrace();
//                            }
//                        } else {
//                            try {
//                                FileUtil.writeFiles(context, "feifeiToken", tokenStr, Context.MODE_PRIVATE);
//                            } catch (Exception e) {
//                                e.printStackTrace();
//                            }
//                        }

                        if (callback != null) {
                            callback.onCom();
                        }
                        isLogin = true;
                        ToastUtil.showToast(context, "登录成功");
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
        return isLogin;
    }

    private static void phoneHandler(Context context){
        Intent intent = new Intent(Intent.ACTION_CALL);
        Uri data = Uri.parse("tel:" + "13345086668");
        intent.setData(data);
        context.startActivity(intent);
    }

    /**
     * 自定义接口，用于回调按钮点击事件到Activity
     * @author Ivan Xu
     * 2014-11-26
     */
    public interface Callback {
        public void onCom();
    }
}
