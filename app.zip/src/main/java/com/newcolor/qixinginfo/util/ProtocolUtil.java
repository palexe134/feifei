package com.newcolor.qixinginfo.util;

import android.content.Context;

import com.newcolor.qixinginfo.entity.FutruesEntity;
import com.newcolor.qixinginfo.global.Config;
import com.newcolor.qixinginfo.global.MyApplication;
import com.newcolor.qixinginfo.http.AsyncHttpResponseHandler;
import com.newcolor.qixinginfo.http.RequestParams;

import org.json.JSONException;
import org.json.JSONObject;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 协议相关
 *
 * Created by Administrator on 2016/3/24.
 */
public class ProtocolUtil {
    public static void getFutruesEntityList(String url, final CallBack callBack){
        HttpUtil.getOther(url, new AsyncHttpResponseHandler() {
            @Override
            public void onFailure(Throwable error, String content) {
                super.onFailure(error, content);
            }

            @Override
            public void onSuccess(String content) {
                super.onSuccess(content);
                if(content==null||content.isEmpty())return;

                ArrayList mListItems=new ArrayList();

                FutruesEntity vo = null;
                String[] contentArr=content.split(";");
                for(String str:contentArr){
                    if(str.indexOf("_hf_")>0) {
                        vo=decodeFutrues(str,1);
                    }else{
                        vo=decodeFutrues(str,2);
                    }
                    if(vo!=null) {
                        mListItems.add(vo);
                    }
                }

                if(callBack!=null) {
                    callBack.onListCom(mListItems);
                }
            }
        });
    }

    public static void getFutruesEntity(String url, final CallBack callBack){
        HttpUtil.getOther(url, new AsyncHttpResponseHandler() {
            @Override
            public void onFailure(Throwable error, String content) {
                super.onFailure(error, content);
            }

            @Override
            public void onSuccess(String content) {
                super.onSuccess(content);
                ArrayList mListItems=new ArrayList();

                FutruesEntity vo = null;
                if(content.indexOf("_hf_")>0) {
                    vo=decodeFutrues(content,1);
                }else{
                    vo=decodeFutrues(content,2);
                }

                if(callBack!=null) {
                    callBack.onVoCom(vo);
                }
            }
        });
    }

    /*
	* 1.type 1:LME  2:上海期货*/
    public static FutruesEntity decodeFutrues(String str,int type){
        List<String> list = new ArrayList<String>();
        String[] temp = str.split(",");
        //hq_str_sz000001=
        //hq_str_PB0=
        //hq_str_hf_NID=
        Pattern pattern;
        if(type==1) {
            pattern= Pattern.compile("(hq_str_hf_=?)(\\S*)=\"(.*)$");
        }else{
            pattern = Pattern.compile("(hq_str_=?)(\\S*)=\"(.*)$");
        }
        Matcher matcher = pattern.matcher(temp[0]);
        if(matcher.find())
        {
            list.add(matcher.group(1));
            list.add(matcher.group(2));
            list.add(matcher.group(3));
        }
        for(int i=1; i<temp.length; i++) {
            list.add(temp[i]);
        }
        if(list.size()<=5)return null;
        FutruesEntity vo=new FutruesEntity();
        if(type==1) {
            vo.setCode(list.get(1));
            vo.setPrefix("hf_");
            vo.setName(list.get(15).replace("\"",""));
            vo.setPrice(Double.valueOf(list.get(2)));
            vo.setChangeAmount(Double.valueOf(list.get(2)) - Double.valueOf(list.get(10)));
            vo.setChangeRate(Double.valueOf(list.get(3)));
            vo.setBuyPrice(Double.valueOf(list.get(4)));
            vo.setSellPrice(Double.valueOf(list.get(5)));
            vo.setHigh(Double.valueOf(list.get(6)));
            vo.setLow(Double.valueOf(list.get(7)));
            vo.setOpen(Double.valueOf(list.get(9)));
            vo.setBuyCount(Integer.parseInt(list.get(12)));
            vo.setSellCount(Integer.parseInt(list.get(13)));
            vo.setJiePrice(-1);
            vo.setZuoJie(Double.valueOf(list.get(10)));
            vo.setChiCang(Integer.parseInt(list.get(11)));
            vo.setChengJiao(-1);
        }else{

            vo.setCode(list.get(1));
            vo.setPrefix("");
            vo.setName(list.get(2));
            vo.setOpen(Double.valueOf(list.get(4)));
            vo.setHigh(Double.valueOf(list.get(5)));
            vo.setLow(Double.valueOf(list.get(6)));
            vo.setBuyPrice(Double.valueOf(list.get(8)));
            vo.setSellPrice(Double.valueOf(list.get(9)));
            vo.setPrice(Double.valueOf(list.get(10)));
            vo.setJiePrice(Double.valueOf(list.get(11)));
            vo.setZuoJie(Double.valueOf(list.get(12)));
            vo.setBuyCount(Integer.parseInt(list.get(13)));
            vo.setSellCount(Integer.parseInt(list.get(14)));
            vo.setChiCang(Integer.parseInt(list.get(15)));
            vo.setChengJiao(Integer.parseInt(list.get(16)));
            vo.setChangeAmount(Double.valueOf(list.get(10)) - Double.valueOf(list.get(7)));

            BigDecimal bd=new BigDecimal(vo.getChangeAmount()/vo.getZuoJie()*100);
            vo.setChangeRate(Double.parseDouble(bd.setScale(2, BigDecimal.ROUND_HALF_UP).toString()));
        }
       return vo;
    }


    /*关注供求消息*/
    public static void foucsHandler(final Context mContext,MyApplication application,int type,String id){
        if(application.getUserId(mContext).equals("-1")){
            LoginUtil.gotoLogin(mContext);
            return;
        }

        RequestParams params=new RequestParams();
        params.put("userId",application.getUserId(mContext));
        params.put("type",String.valueOf(type));
        params.put("id", id);

        HttpUtil.get(Config.AddMyAttention, params, new AsyncHttpResponseHandler() {
            @Override
            public void onFailure(Throwable error, String content) {
                super.onFailure(error, content);
                ToastUtil.showToast(mContext, content);
            }

            @Override
            public void onSuccess(String content) {
                super.onSuccess(content);

                JSONObject jsonObject = null;
                try {
                    jsonObject = new JSONObject(content);
                    byte isSuc = Byte.parseByte(jsonObject.getString("isSuc"));
                    if (isSuc == 0) {
                        String msg = jsonObject.getString("msg");
                        ToastUtil.showToast(mContext, msg);
                    } else {
                        ToastUtil.showToast(mContext, "关注成功");
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
    }


    public interface CallBack{
        public void onListCom(ArrayList list);
        public void onVoCom(FutruesEntity vo);
    }


}
