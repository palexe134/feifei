package com.newcolor.qixinginfo.util;

import android.content.Context;
import android.os.Environment;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;

/**
 * 文件处理相关
 *
 * Created by Administrator on 2015/12/28.
 */
public class FileUtil {
    /**
     * 保存文件内容
     *
     * @param c
     * @param fileName
     *            文件名称
     * @param content
     *            内容
     */
    public static void writeFiles(Context c, String fileName, String content, int mode)
            throws Exception {
        // 打开文件获取输出流，文件不存在则自动创建
        FileOutputStream fos = c.openFileOutput(fileName, mode);
        fos.write(content.getBytes());
        fos.close();
    }

    /**
     * 读取文件内容
     *
     * @param c
     * @param fileName
     *            文件名称
     * @return 返回文件内容
     */
    public static  String readFiles(Context c, String fileName) throws Exception {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        FileInputStream fis = c.openFileInput(fileName);
        byte[] buffer = new byte[1024];
        int len = 0;
        while ((len = fis.read(buffer)) != -1) {
            baos.write(buffer, 0, len);
        }
        String content = baos.toString();
        fis.close();
        baos.close();
        return content;
    }


    public static void saveData(Context c, String fileName, String content,String type) throws IOException {

        File sdCard = Environment.getExternalStoragePublicDirectory(type);

        // 查看LogCat,获取的sd卡的绝对路径为 /storage/sdcard
        sdCard = new File(sdCard, "/MyFiles");
        sdCard.mkdirs();// 创建MyFiles目录(可创建多级目录)
        sdCard = new File(sdCard, fileName);
        FileOutputStream out = new FileOutputStream(sdCard);
        Writer writer = new OutputStreamWriter(out);
        try {
            writer.write(content);
        } finally {
            writer.close();
        }
    }

    public static String loadData(Context c, String fileName,String type) throws FileNotFoundException, IOException {
        BufferedReader reader = null;
        StringBuilder data = new StringBuilder();
        try {
            File sdCard = Environment.getExternalStoragePublicDirectory(type);
            sdCard = new File(sdCard, "/MyFiles/" + fileName);
            if (!sdCard.exists()){
                return "-1";
            }
            FileInputStream in = new FileInputStream(sdCard);
            reader = new BufferedReader(new InputStreamReader(in));
            String line = new String();
            while ((line = reader.readLine()) != null) {
                data.append(line);
            }
            return data.toString();
        } catch (FileNotFoundException e) {
            reader.close();
            return "-1";
        } finally {

        }
    }

    /* Checks if external storage is available for read and write */
    public static boolean isExternalStorageWritable() {
        String state = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(state)) {
            return true;
        }
        return false;
    }
}
