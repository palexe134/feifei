package com.newcolor.qixinginfo.util;

import android.content.Context;

import com.newcolor.qixinginfo.global.Config;
import com.newcolor.qixinginfo.global.Constant;
import com.newcolor.qixinginfo.http.AsyncHttpResponseHandler;
import com.newcolor.qixinginfo.http.RequestParams;
import com.newcolor.qixinginfo.model.UserVO;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * 通用协议
 *
 * Created by Administrator on 2016/1/17.
 */
public class DealUtil {

    /*保存用户基本数据*/
    public static void savePersonalInfo(final Context context,UserVO userVO,String userId){
        RequestParams params=new RequestParams();
        params.put("userId", userId);
        params.put("Phone",userVO.getPhone());
        params.put("realName",userVO.getReal_name());
        params.put("name",userVO.getName());
        params.put("gender",userVO.getGender());
        params.put("email",userVO.getEmail());
        params.put("birthday",userVO.getBirthday());
        params.put("address",userVO.getAddress());
        params.put("componyName",userVO.getCompony_name());
        params.put("componyWeb",userVO.getCompony_web());
        params.put("componyCotent",userVO.getCompony_cotent());
        params.put("leaveWord",userVO.getLeave_word());
        params.put("fax",userVO.getFax());
        params.put("landline",userVO.getLandline());
        params.put("ldCard",userVO.getLd_card());
        params.put("headImg",userVO.getHeadImg());
        params.put("coordinate",userVO.getCoordinate());

        params.put("companyImgs",userVO.getCompanyImgs());
        HttpUtil.get(Config.EditorMeInfo, params, new AsyncHttpResponseHandler() {
            @Override
            public void onFailure(Throwable error, String content) {
                super.onFailure(error, content);
                ToastUtil.showToast(context, content);
            }

            @Override
            public void onSuccess(String content) {
                super.onSuccess(content);

                JSONObject jsonObject = null;
                try {
                    jsonObject = new JSONObject(content);
                    byte isSuc = Byte.parseByte(jsonObject.getString("isSuc"));
                    if (isSuc == 0) {
                        String msg = jsonObject.getString("msg");
                        ToastUtil.showToast(context, msg);
                    } else {
                        ToastUtil.showToast(context, "已保存");
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        });
    }


    /*保存用户基本数据*/
    public static void savePhoneContacts(final Context context,String userId,String cStr){
        RequestParams params=new RequestParams();
        params.put("userId", userId);
        params.put("cStr", cStr);

        HttpUtil.post(Config.savePhoneContacts, params, new AsyncHttpResponseHandler() {
            @Override
            public void onFailure(Throwable error, String content) {
                super.onFailure(error, content);
                ToastUtil.showToast(context, content);
            }

            @Override
            public void onSuccess(String content) {
                super.onSuccess(content);
                SharedUtil.putBoolean(context, Constant.ISSAVEPHONECONTACT, true);

                JSONObject jsonObject = null;
                try {
                    jsonObject = new JSONObject(content);
                    byte isSuc = Byte.parseByte(jsonObject.getString("isSuc"));
                    if (isSuc == 0) {
//                        String msg = jsonObject.getString("msg");
//                        ToastUtil.showToast(context, msg);
                    } else {
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        });
    }

}
